import { acceptSegment, decimalValue, expectedOutput, isSolvedCard, matchesOutput } from '../lib/puzzle';
import { isSongDraw } from '../lib/draw';

/** Business progress is independent from navigation, animation and optional discoveries. */
export type View = 'overview' | 'puzzle' | 'music' | 'lock' | 'gift';
export type Bit = 0 | 1;
export type BitDraft = [Bit | null, Bit | null, Bit | null, Bit | null];
export type CardId = 'A' | 'B';
export type CardProgress = {
  output: BitDraft;
  stage: 'bits' | 'decimal' | 'solved';
  decimalInput: string;
  segment: string | null;
};
export type Progress = {
  version: 1;
  cards: { A: CardProgress; B: CardProgress };
  puzzleSolved: boolean;
  bridgeSeen: boolean;
  giftUnlocked: boolean;
  lastDraw: { songId: number; drawId: string; drawnAt: string } | null;
};

export function createInitialProgress(): Progress {
  const emptyCard = (): CardProgress => ({
    output: [null, null, null, null],
    stage: 'bits',
    decimalInput: '',
    segment: null,
  });
  return {
    version: 1,
    cards: { A: emptyCard(), B: emptyCard() },
    puzzleSolved: false,
    bridgeSeen: false,
    giftUnlocked: false,
    lastDraw: null,
  };
}

export type ProgressAction =
  | { type: 'set-bit'; card: CardId; index: number; value: Bit }
  | { type: 'check-bits'; card: CardId }
  | { type: 'set-decimal'; card: CardId; value: string }
  | { type: 'solve-card'; card: CardId }
  | { type: 'assist-card'; card: CardId }
  | { type: 'seen-bridge' }
  | { type: 'record-draw'; draw: NonNullable<Progress['lastDraw']> };

function withCard(state: Progress, id: CardId, card: CardProgress): Progress {
  const cards = { ...state.cards, [id]: card };
  const puzzleSolved = isSolvedCard('A', cards.A) && isSolvedCard('B', cards.B);
  return { ...state, cards, puzzleSolved, bridgeSeen: puzzleSolved && state.bridgeSeen };
}

export function progressReducer(state: Progress, action: ProgressAction): Progress {
  if (action.type === 'record-draw') {
    if (!isSongDraw(action.draw) || state.lastDraw?.drawId === action.draw.drawId) return state;
    const { songId, drawId, drawnAt } = action.draw;
    return { ...state, lastDraw: { songId, drawId, drawnAt } };
  }
  if (action.type === 'seen-bridge') {
    if (!isSolvedCard('A', state.cards.A) || !isSolvedCard('B', state.cards.B) || state.bridgeSeen) return state;
    return { ...state, puzzleSolved: true, bridgeSeen: true };
  }
  const id = action.card;
  if (id !== 'A' && id !== 'B') return state;
  if (id === 'B' && !isSolvedCard('A', state.cards.A)) return state;
  const card = state.cards[id];
  if (card.stage === 'solved') return state;

  switch (action.type) {
    case 'set-bit': {
      if (card.stage !== 'bits' || !Number.isInteger(action.index) || action.index < 0 || action.index > 3
        || (action.value !== 0 && action.value !== 1) || card.output[action.index] === action.value) return state;
      const output: BitDraft = [...card.output];
      output[action.index] = action.value;
      return withCard(state, id, { ...card, output });
    }
    case 'check-bits':
      if (card.stage !== 'bits' || !matchesOutput(id, card.output)) return state;
      return withCard(state, id, { ...card, stage: 'decimal', decimalInput: '', segment: null });
    case 'set-decimal':
      if (card.stage !== 'decimal' || typeof action.value !== 'string' || card.decimalInput === action.value) return state;
      return withCard(state, id, { ...card, decimalInput: action.value });
    case 'solve-card': {
      if (card.stage !== 'decimal' || !matchesOutput(id, card.output)) return state;
      const segment = acceptSegment(card.decimalInput, decimalValue(id));
      if (segment === null) return state;
      return withCard(state, id, { ...card, stage: 'solved', segment });
    }
    case 'assist-card':
      return withCard(state, id, {
        output: expectedOutput(id), stage: 'solved',
        decimalInput: String(decimalValue(id)),
        segment: acceptSegment(String(decimalValue(id)), decimalValue(id)),
      });
    default: return state;
  }
}

/** No URL or visual interaction unlocks a gift. */
export function viewFromHash(hash: string, giftUnlocked = false): View {
  switch (hash.replace(/^#/, '')) {
    case 'puzzle': return 'puzzle';
    case 'music': return 'music';
    case 'lock': return 'lock';
    case 'gift': return giftUnlocked ? 'gift' : 'lock';
    default: return 'overview';
  }
}
