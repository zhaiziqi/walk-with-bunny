import { archComposition } from './hollowArch';

type Point = { x: number; y: number };
export type ChimeListeningState = {
  actor: Point; time: number; speed: number; quiet: number; windLean: number;
  engaged: boolean; approachDistance: number; approachSide: number; playedVisit: boolean;
  discovered: boolean; replaySerial: number; responseAge: number; responseStrength: number; responseSide: number;
  noteSerial: number; notePlayed: boolean;
};
export type ChimeListeningRef = { current: ChimeListeningState | null };
const clamp = (n: number) => Math.max(0, Math.min(1, n));
const smooth = (n: number) => { const p = clamp(n); return p * p * (3 - 2 * p); };
const distance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y);
const responseDuration = 8.5;
const bellDelay = .24;
const bellFrequency = 4.3;
export const chimeFirstCrossing = bellDelay + Math.PI / bellFrequency;

export function createChimeListening(actor: Point, discovered = false, replaySerial = -1): ChimeListeningState {
  return { actor: { ...actor }, time: 0, speed: 0, quiet: 0, windLean: 0, engaged: false,
    approachDistance: 0, approachSide: 1, playedVisit: false, discovered, replaySerial,
    responseAge: -1, responseStrength: 1, responseSide: 1, noteSerial: 0, notePlayed: true };
}

/** The visitor's passage lifts the paper first. The heavier bell answers late, then
 * both settle. A map arrival is not a passage; a motionless stay never repeats it. */
export function advanceChimeListening(state: ChimeListeningState, actor: Point, delta: number, options: {
  paused?: boolean; speed?: number; replaySerial?: number; windLean?: number;
} = {}): ChimeListeningState {
  if (options.paused || !Number.isFinite(delta) || delta <= 0 || !Number.isFinite(actor.x) || !Number.isFinite(actor.y)) return state;
  const step = distance(actor, state.actor), discontinuity = step > 80;
  if (delta > .25 && !discontinuity) return { ...state, actor: { ...actor } };
  const dt = Math.min(delta, .05), near = distance(actor, archComposition);
  const engaged = !discontinuity && near < (state.engaged ? 440 : 380);
  const serial = options.replaySerial ?? state.replaySerial;
  const manual = !discontinuity && near < 340 && serial !== state.replaySerial;
  const measuredSpeed = discontinuity ? 0 : Math.max(0, Number.isFinite(options.speed) ? options.speed! : step / delta);
  const speed = state.speed + (measuredSpeed - state.speed) * (1 - Math.exp(-dt / .18));
  const quiet = engaged && speed < 20 ? state.quiet + dt : 0;
  // A few pixels of pointer jitter are insufficient. Count actual ground travel,
  // resetting it after leaving or a relocation so opening the map cannot greet us.
  const approachDistance = engaged ? Math.min(500, (state.engaged ? state.approachDistance : 0) + step) : 0;
  let approachSide = state.approachSide;
  if (engaged && !state.engaged) approachSide = actor.x < archComposition.x ? -1 : 1;
  let playedVisit = engaged && state.playedVisit;
  let { responseAge, responseStrength, responseSide, noteSerial, notePlayed, discovered } = state;
  if (discontinuity) { responseAge = -1; notePlayed = true; }
  const active = responseAge >= 0 && responseAge < responseDuration;
  const listening = near < 300 && quiet >= .5 && approachDistance >= 20;
  const passing = near < 145 && speed > 20 && approachDistance >= 55;
  if (!active && engaged && ((!playedVisit && (listening || passing)) || manual)) {
    responseAge = 0; responseStrength = discovered ? .64 : 1;
    responseSide = approachSide;
    discovered = true; playedVisit = true; notePlayed = false;
  } else if (responseAge >= 0) responseAge = Math.min(responseDuration, responseAge + dt);
  // Exactly one optional note at the first return through the bell's resting axis.
  // Bounded session IDs avoid unbounded world-event history on many revisits.
  if (!notePlayed && responseAge >= chimeFirstCrossing) {
    noteSerial = Math.min(64, noteSerial + 1); notePlayed = true;
  }
  return { actor: { ...actor }, time: state.time + dt, speed, quiet,
    windLean: Number.isFinite(options.windLean) ? options.windLean! : state.windLean, engaged,
    approachDistance, approachSide, playedVisit, discovered, replaySerial: serial,
    responseAge, responseStrength, responseSide, noteSerial, notePlayed };
}

/** Remounting at the same place preserves the exact snapshot and sound phase.
 * Relocating cancels an unseen response, consumes no note, and requires real travel. */
export function resumeChimeListening(state: ChimeListeningState, actor: Point): ChimeListeningState {
  if (distance(state.actor, actor) <= 80) return { ...state, actor: { ...actor } };
  return { ...state, actor: { ...actor }, speed: 0, quiet: 0, engaged: false,
    approachDistance: 0, playedVisit: false, responseAge: -1, notePlayed: true };
}

/** Angles are in billboard coordinates. The paper angle is relative to a hinge
 * under the bell, not a second rotation about the fixed suspension point. */
export function chimeListeningPose(state: ChimeListeningState, windLean = state.windLean) {
  const age = state.responseAge, active = age >= 0 && age < responseDuration;
  const release = active ? 1 - smooth((age - 6.5) / 2) : 0;
  const force = state.responseSide * state.responseStrength * release;
  const t = Math.max(0, age - bellDelay);
  const bellResponse = force * .19 * Math.sin(t * bellFrequency) * Math.exp(-t * .62) * smooth(t / .2);
  const paperResponse = force * .65 * Math.sin(Math.max(0, age) * 3.65) * Math.exp(-Math.max(0, age) * .57) * smooth(age / .16);
  return {
    bellAngle: windLean * .055 + Math.sin(state.time * .61) * .012 + bellResponse,
    paperAngle: windLean * .035 + Math.sin(state.time * .83 + .4) * .018 + paperResponse,
    responseAge: age < 0 ? 100 : age, active,
  };
}

export function inspectChimeListening(state: ChimeListeningState) {
  const pose = chimeListeningPose(state);
  return { engaged: state.engaged, quiet: +state.quiet.toFixed(2), travel: +state.approachDistance.toFixed(1),
    responseAge: +state.responseAge.toFixed(2), responseStrength: state.responseStrength, side: state.responseSide,
    bellAngle: +pose.bellAngle.toFixed(3), paperAngle: +pose.paperAngle.toFixed(3), noteSerial: state.noteSerial };
}
