import { useCallback, useEffect, useRef, useState } from 'react';
import { progressReducer } from './experience';
import type { ProgressAction } from './experience';
import { loadProgress, saveProgress } from '../lib/storage';
import type { StorageStatus } from '../lib/storage';

/** Business state loads before navigation and remains usable if saving is unavailable. */
export function useProgress() {
  const [initial] = useState(loadProgress);
  const [progress, setProgress] = useState(initial.progress);
  const current = useRef(initial.progress);
  const [storageStatus, setStorageStatus] = useState<StorageStatus>(initial.storageStatus);
  // Every accepted command saves before returning to its caller. Animation can
  // then start without relying on React's next commit or an animation callback.
  const dispatch = useCallback((action: ProgressAction) => {
    const next = progressReducer(current.current, action);
    if (next === current.current) return;
    current.current = next;
    const saved = saveProgress(next);
    setProgress(next);
    setStorageStatus(saved ? 'saved' : 'memory');
  }, []);
  useEffect(() => {
    // Normalize loaded records once. Read the ref, not the initial snapshot,
    // so a late mount effect cannot overwrite a command issued before it ran.
    setStorageStatus(saveProgress(current.current) ? 'saved' : 'memory');
  }, []);
  return { progress, dispatch, storageStatus };
}
