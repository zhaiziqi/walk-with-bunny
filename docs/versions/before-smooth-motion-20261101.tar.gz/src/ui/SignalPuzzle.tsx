import { useEffect, useRef, useState } from 'react';
import type { Dispatch, FormEvent } from 'react';
import { content } from '../config/content';
import { acceptSegment, decimalValue, expectedOutput, matchesOutput, outputComplete } from '../lib/puzzle';
import type { Bit, BitDraft, CardId, Progress, ProgressAction } from '../state/experience';
import '../styles/puzzle.css';

type Props = {
  progress: Progress;
  dispatch: Dispatch<ProgressAction>;
  storageStatus: 'saved' | 'memory';
  onReturn: () => void;
  onMusic: () => void;
};

function LightRow({ output, label }: { output: BitDraft; label: string }) {
  return <div className="puzzle-light-row" role="group" aria-label={label}>
    {output.map((bit, index) => <div className={`puzzle-read-light ${bit === 1 ? 'is-lit' : ''}`} key={index}
      role="group"
      aria-label={`Position ${index + 1}: ${bit ?? 'unanswered'}, weight ${content.puzzle.weights[index]}, ${bit === 1 ? 'on' : 'off'}`}>
      <span className="puzzle-light-digit">{bit ?? '—'}</span>
      <span className="puzzle-weight">{content.puzzle.weights[index]}</span>
    </div>)}
  </div>;
}

function StorageNote({ status }: { status: Props['storageStatus'] }) {
  return <p className={`puzzle-storage ${status === 'memory' ? 'is-temporary' : ''}`} role={status === 'memory' ? 'status' : undefined}>
    {status === 'memory' ? 'Your progress will stay with you while this page is open.' : 'Your progress is saved on this browser.'}
  </p>;
}

/** The landscape stays in place; these four deliberate choices are the whole foreground task. */
export function SignalPuzzle({ progress, dispatch, storageStatus, onReturn, onMusic }: Props) {
  const [activeCard, setActiveCard] = useState<CardId>(() => progress.cards.A.stage === 'solved' ? 'B' : 'A');
  const [hint, setHint] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [bridgeOpen, setBridgeOpen] = useState(progress.bridgeSeen);
  const stepTitle = useRef<HTMLHeadingElement>(null);
  const decimalInput = useRef<HTMLInputElement>(null);
  const mounted = useRef(false);
  const previousHint = useRef(0);
  const cardId = activeCard === 'B' && progress.cards.A.stage !== 'solved' ? 'A' : activeCard;
  const card = progress.cards[cardId];
  const signal = content.puzzle.signals.find(item => item.id === cardId)!;
  const stageIdentity = `${cardId}:${card.stage}:${progress.puzzleSolved}`;

  useEffect(() => {
    setFeedback(''); setHint(0);
    stepTitle.current?.closest<HTMLElement>('[role="dialog"]')?.scrollTo({ top: 0, behavior: 'instant' });
    if (mounted.current) {
      if (card.stage === 'decimal' && !progress.puzzleSolved) decimalInput.current?.focus({ preventScroll: true });
      else stepTitle.current?.focus({ preventScroll: true });
    }
    mounted.current = true;
  }, [stageIdentity, card.stage, progress.puzzleSolved]);

  useEffect(() => {
    // The worked example replaces the form, including the button that opened it.
    if (hint === 3 || previousHint.current === 3) {
      stepTitle.current?.closest<HTMLElement>('[role="dialog"]')?.scrollTo({ top: 0, behavior: 'instant' });
      stepTitle.current?.focus({ preventScroll: true });
    }
    previousHint.current = hint;
  }, [hint]);

  const checkBits = (event: FormEvent) => {
    event.preventDefault();
    if (!outputComplete(card.output)) { setFeedback('A few lights are still waiting. Choose 0 or 1 in each column.'); return; }
    if (!matchesOutput(cardId, card.output)) { setFeedback('Some positions do not match yet. Compare them from left to right once more.'); return; }
    dispatch({ type: 'check-bits', card: cardId });
  };
  const checkDecimal = (event: FormEvent) => {
    event.preventDefault();
    if (acceptSegment(card.decimalInput, decimalValue(cardId)) === null) {
      setFeedback(card.decimalInput.trim() ? 'Add only the numbers beneath the lights that are on, then try again.' : 'What do the glowing lights add up to? Enter a number first.');
      decimalInput.current?.focus({ preventScroll: true }); return;
    }
    dispatch({ type: 'solve-card', card: cardId });
  };
  const completeHelp = () => dispatch({ type: 'assist-card', card: cardId });
  const complete = progress.puzzleSolved;
  const showWorked = hint === 3 && card.stage !== 'solved';
  const correctOutput = showWorked ? expectedOutput(cardId) : null;
  const sum = correctOutput?.flatMap((bit, index) => bit === 1 ? [content.puzzle.weights[index]] : []).join(' + ');

  return <div className="signal-puzzle" data-puzzle-card={cardId} data-puzzle-stage={complete ? 'complete' : card.stage}>
    <ol className="puzzle-progress" aria-label="Signal progress">
      {(['A', 'B'] as const).map(id => <li key={id} className={progress.cards[id].stage === 'solved' ? 'is-complete' : cardId === id ? 'is-current' : ''}
        aria-current={!complete && cardId === id ? 'step' : undefined}>
        <span>Signal {id}</span><span>{progress.cards[id].stage === 'solved' ? progress.cards[id].segment : cardId === id ? 'Reading' : 'Next'}</span>
      </li>)}
    </ol>

    {complete ? <div className="puzzle-complete">
      <h2 ref={stepTitle} tabIndex={-1}>{content.puzzle.keyCardTitle}</h2>
      <div className="puzzle-code-card" aria-label={`Your four-digit code is ${content.puzzle.code}`}>
        <span className="puzzle-code-label">YOUR CODE</span>
        <strong>{content.puzzle.code}</strong>
        <span className="puzzle-code-parts">{progress.cards.A.segment}<span aria-hidden="true"> · </span>{progress.cards.B.segment}</span>
      </div>
      <p className="puzzle-copy">{content.puzzle.keyCardBody}</p>
      <p className="puzzle-small">That quiet comparison is called XOR.</p>
      <button className="puzzle-primary" onClick={onReturn}>Keep it · Return to the garden <span aria-hidden="true">↗</span></button>
      <div className="puzzle-bridge">
        <button className="puzzle-text-button" aria-expanded={bridgeOpen} aria-controls="puzzle-bridge-detail" onClick={() => {
          setBridgeOpen(value => !value);
          if (!bridgeOpen) dispatch({ type: 'seen-bridge' });
        }}>One more small connection <span aria-hidden="true">{bridgeOpen ? '−' : '+'}</span></button>
        {bridgeOpen && <div id="puzzle-bridge-detail" className="puzzle-bridge-detail">
          <span className="puzzle-small">The decoder key, read as a number</span>
          <LightRow output={[...content.puzzle.key].map(bit => Number(bit) as Bit) as BitDraft} label="Decoder key and its weights"/>
          <p className="puzzle-bridge-sum">8 + 1 = 9</p>
          <p className="puzzle-copy">Nine pieces are waiting in the music garden.</p>
          <button className="puzzle-text-button" onClick={onMusic}>{content.puzzle.transitionLabel} <span aria-hidden="true">→</span></button>
        </div>}
      </div>
    </div> : card.stage === 'solved' ? <div className="puzzle-part-complete">
      <h2 ref={stepTitle} tabIndex={-1}>The first part is yours.</h2>
      <div className="puzzle-segment" aria-label={`Signal A complete: ${card.segment}`}><span>Signal A</span><strong>{card.segment}</strong></div>
      <p className="puzzle-copy">Keep it beside you. One signal remains.</p>
      <button className="puzzle-primary" onClick={() => { setActiveCard('B'); setFeedback(''); setHint(0); }}>Read the next signal <span aria-hidden="true">→</span></button>
    </div> : <>
      <h2 ref={stepTitle} tabIndex={-1}>{showWorked ? 'Read it together.' : card.stage === 'bits' ? 'Find the four lights.' : 'A number in the light.'}</h2>
      {showWorked && correctOutput ? <section className="puzzle-worked" aria-label={`Worked example for Signal ${cardId}`}>
        <p className="puzzle-copy">Compare each pair. Matching digits give 0; different digits give 1.</p>
        <div className="puzzle-comparison" aria-label={`Signal ${cardId} compared with the decoder key`}>
          <span className="puzzle-grid-label">Decoder</span>{[...content.puzzle.key].map((bit, i) => <span className="puzzle-source-bit" key={`key-${i}`}>{bit}</span>)}
          <span className="puzzle-grid-label">Signal {cardId}</span>{[...signal.bits].map((bit, i) => <span className="puzzle-source-bit" key={`signal-${i}`}>{bit}</span>)}
          <span className="puzzle-grid-label">Result</span>{correctOutput.map((bit, i) => <span className={`puzzle-source-bit result ${bit === 1 ? 'is-lit' : ''}`} key={`result-${i}`}>{bit}</span>)}
        </div>
        <LightRow output={correctOutput} label="Correct output and its weights"/>
        <p className="puzzle-worked-sum">{sum} = {decimalValue(cardId)}</p>
        <p className="puzzle-small">Kept as two digits: {String(decimalValue(cardId)).padStart(content.puzzle.segmentDigits, '0')}.</p>
        <button className="puzzle-primary" onClick={completeHelp}>I understand · Keep this part <span aria-hidden="true">→</span></button>
        <button className="puzzle-text-button" onClick={() => setHint(2)}>Back to my answer</button>
      </section> : card.stage === 'bits' ? <form onSubmit={checkBits} noValidate>
        <p className="puzzle-copy puzzle-rule">Same digits → 0. Different digits → 1.<br/><span>0 is off. 1 is on.</span></p>
        <div className="puzzle-comparison">
          <span className="puzzle-grid-label">Decoder</span>{[...content.puzzle.key].map((bit, i) => <span className="puzzle-source-bit" key={`key-${i}`}>{bit}</span>)}
          <span className="puzzle-grid-label">Signal {cardId}</span>{[...signal.bits].map((bit, i) => <span className="puzzle-source-bit" key={`signal-${i}`}>{bit}</span>)}
          <span className="puzzle-grid-label puzzle-result-label">Your lights</span>{card.output.map((bit, i) => <fieldset className="puzzle-bit-choice" key={i}>
            <legend className="puzzle-sr-only">Signal {cardId}, output position {i + 1}</legend>
            <span className={`puzzle-draft-value ${bit === null ? 'is-empty' : bit === 1 ? 'is-lit' : ''}`} aria-hidden="true">{bit === null ? '—' : bit}</span>
            {([0, 1] as const).map(value => <label className="puzzle-option" key={value}>
              <input type="radio" name={`signal-${cardId}-position-${i}`} value={value} checked={bit === value}
                aria-label={`Signal ${cardId}, position ${i + 1}: ${value} (${value ? 'on' : 'off'})`}
                onChange={() => { dispatch({ type: 'set-bit', card: cardId, index: i, value }); setFeedback(''); }}/>
              <span>{value}<i aria-hidden="true" className={value ? 'light-on' : 'light-off'}/></span>
            </label>)}
          </fieldset>)}
        </div>
        <p className={`puzzle-feedback ${feedback ? 'has-message' : ''}`} role="status">{feedback || (!outputComplete(card.output) ? 'Choose 0 or 1 in each column.' : 'All four lights are ready to check.')}</p>
        <button className="puzzle-primary" type="submit" disabled={!outputComplete(card.output)}>Check these lights <span aria-hidden="true">→</span></button>
      </form> : <form onSubmit={checkDecimal} noValidate>
        <p className="puzzle-copy">Add only the numbers beneath the glowing lights.</p>
        <LightRow output={card.output} label={`Signal ${cardId}: verified lights and weights`}/>
        <label className="puzzle-number-label" htmlFor={`decimal-${cardId}`}>What number do they make?</label>
        <div className="puzzle-number-entry">
          <input id={`decimal-${cardId}`} ref={decimalInput} type="text" inputMode="numeric" autoComplete="off" maxLength={2}
            value={card.decimalInput} aria-describedby="puzzle-number-note puzzle-answer-feedback" aria-invalid={feedback ? true : undefined}
            onChange={event => { dispatch({ type: 'set-decimal', card: cardId, value: event.target.value }); setFeedback(''); }}/>
          <span id="puzzle-number-note">We will keep it<br/>as two digits.</span>
        </div>
        <p className={`puzzle-feedback ${feedback ? 'has-message' : ''}`} id="puzzle-answer-feedback" role="status">{feedback || '\u00a0'}</p>
        <button className="puzzle-primary" type="submit">Keep this number <span aria-hidden="true">→</span></button>
      </form>}
      {!showWorked && <section className="puzzle-hints" aria-label="Optional help">
        {hint === 0 ? <button className="puzzle-text-button" aria-expanded={false} onClick={() => setHint(1)}>{content.puzzle.hintLabel} <span aria-hidden="true">+</span></button> : <>
          <div className="puzzle-hint-heading"><span>A little hint</span><button className="puzzle-close-hint" onClick={() => setHint(0)} aria-label="Close hint">×</button></div>
          {hint === 1 ? <>
            <p className="puzzle-copy">{card.stage === 'bits' ? 'Start at the leftmost position. Are the decoder digit and the signal digit the same?' : 'Each light has a number beneath it. Count that number only when the light above it is on.'}</p>
            <button className="puzzle-text-button" onClick={() => setHint(2)}>Show me one comparison <span aria-hidden="true">→</span></button>
          </> : <>
            <p className="puzzle-copy">{card.stage === 'bits' ? 'On the left, 1 meets 1. They match, so that light is 0. Read the other positions the same way.' : 'The leftmost light is off, so leave 8 out. Read the remaining lights from left to right.'}</p>
            <div className="puzzle-truth-note" aria-label="Comparison rules">0 with 0 → 0 <span>1 with 1 → 0</span><br/>0 with 1 → 1 <span>1 with 0 → 1</span></div>
            <button className="puzzle-text-button" onClick={() => setHint(3)}>{content.puzzle.assistLabel} <span aria-hidden="true">→</span></button>
          </>}
        </>}
      </section>}
    </>}
    <footer className="puzzle-footer">
      {!complete && <button className="puzzle-text-button" onClick={onReturn}>Wander on <span aria-hidden="true">↗</span></button>}
      <StorageNote status={storageStatus}/>
    </footer>
  </div>;
}
