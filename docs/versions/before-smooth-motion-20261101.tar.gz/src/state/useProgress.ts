import { useEffect, useReducer, useState } from 'react';
import { progressReducer } from './experience';
import { loadProgress, saveProgress } from '../lib/storage';
import type { StorageStatus } from '../lib/storage';

/** Business state loads before navigation and remains usable if saving is unavailable. */
export function useProgress() {
  const [initial] = useState(loadProgress);
  const [progress, dispatch] = useReducer(progressReducer, initial.progress);
  const [storageStatus, setStorageStatus] = useState<StorageStatus>(initial.storageStatus);
  useEffect(() => {
    setStorageStatus(saveProgress(progress) ? 'saved' : 'memory');
  }, [progress]);
  return { progress, dispatch, storageStatus };
}
