import { content } from '../config/content';
import type { Bit, BitDraft, CardId, CardProgress } from '../state/experience';

export type CompleteBits = [Bit, Bit, Bit, Bit];

/** Answers come from the configured signal and key, never from a displayed hint. */
export function expectedOutput(card: CardId): CompleteBits {
  const signal = content.puzzle.signals.find(item => item.id === card)!;
  return [...signal.bits].map((bit, index) => bit === content.puzzle.key[index] ? 0 : 1) as CompleteBits;
}

export function outputComplete(output: readonly (Bit | null)[]): output is CompleteBits {
  return output.length === 4 && [0, 1, 2, 3].every(index => output[index] === 0 || output[index] === 1);
}

export function matchesOutput(card: CardId, output: BitDraft): boolean {
  const answer = expectedOutput(card);
  return outputComplete(output) && answer.every((bit, index) => output[index] === bit);
}

export function decimalValue(card: CardId): number {
  return expectedOutput(card).reduce<number>((sum, bit, index) => sum + bit * content.puzzle.weights[index], 0);
}

export function acceptSegment(input: string, expected: number): string | null {
  if (typeof input !== 'string') return null;
  const text = input.trim();
  if (!/^\d{1,2}$/.test(text) || Number(text) !== expected) return null;
  return String(expected).padStart(content.puzzle.segmentDigits, '0');
}

/** A completion flag alone cannot award a key, including after restoring storage. */
export function isSolvedCard(card: CardId, progress: CardProgress): boolean {
  const segment = acceptSegment(progress.decimalInput, decimalValue(card));
  return progress.stage === 'solved' && matchesOutput(card, progress.output)
    && segment !== null && progress.segment === segment;
}
