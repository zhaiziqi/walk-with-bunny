import { content } from '../config/content';
import { createInitialProgress } from '../state/experience';
import type { BitDraft, CardId, CardProgress, Progress } from '../state/experience';
import { acceptSegment, decimalValue, isSolvedCard, matchesOutput } from './puzzle';

export const STORAGE_KEY = `birthday-gift:${content.puzzle.code}:v1`;
export type StorageStatus = 'saved' | 'memory';
export type ProgressStorage = Pick<Storage, 'getItem' | 'setItem'>;
export type LoadedProgress = { progress: Progress; storageStatus: StorageStatus };

function record(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function restoredCard(id: CardId, raw: unknown): CardProgress {
  const empty = createInitialProgress().cards[id];
  if (!record(raw)) return empty;
  if (!Array.isArray(raw.output) || raw.output.length !== 4
    || ![0, 1, 2, 3].every(index => {
      const bit = (raw.output as unknown[])[index];
      return bit === null || bit === 0 || bit === 1;
    })) return empty;
  const output = [...raw.output] as BitDraft;
  const draft: CardProgress = { ...empty, output };
  if ((raw.stage !== 'decimal' && raw.stage !== 'solved') || !matchesOutput(id, output)) return draft;
  const decimalInput = typeof raw.decimalInput === 'string' && raw.decimalInput.length <= 64 ? raw.decimalInput : '';
  const segment = acceptSegment(decimalInput, decimalValue(id));
  if (raw.stage === 'solved' && segment !== null && raw.segment === segment) {
    return { output, decimalInput, segment, stage: 'solved' };
  }
  // Valid bits survive a damaged result, but the decimal result still needs confirmation.
  return { output, decimalInput, segment: null, stage: 'decimal' };
}

function restoredDraw(raw: unknown): Progress['lastDraw'] {
  if (!record(raw) || typeof raw.songId !== 'number' || !Number.isInteger(raw.songId)
    || !content.music.songs.some(song => song.id === raw.songId)
    || typeof raw.drawId !== 'string' || !raw.drawId.trim() || raw.drawId.length > 256
    || typeof raw.drawnAt !== 'string' || raw.drawnAt.length > 40
    || !/^\d{4}-\d{2}-\d{2}T/.test(raw.drawnAt) || !Number.isFinite(Date.parse(raw.drawnAt))) return null;
  return { songId: raw.songId, drawId: raw.drawId, drawnAt: raw.drawnAt };
}

/** Select known business fields; route, camera and animation fields never enter storage. */
export function normalizeProgress(raw: unknown): Progress {
  const initial = createInitialProgress();
  if (!record(raw) || raw.version !== 1) return initial;
  const sourceCards = record(raw.cards) ? raw.cards : {};
  const A = restoredCard('A', sourceCards.A);
  const B = isSolvedCard('A', A) ? restoredCard('B', sourceCards.B) : initial.cards.B;
  const puzzleSolved = isSolvedCard('A', A) && isSolvedCard('B', B);
  return {
    version: 1, cards: { A, B }, puzzleSolved,
    bridgeSeen: puzzleSolved && raw.bridgeSeen === true,
    giftUnlocked: raw.giftUnlocked === true,
    lastDraw: restoredDraw(raw.lastDraw),
  };
}

function browserStorage(): ProgressStorage | null {
  try { return typeof window === 'undefined' ? null : window.localStorage; }
  catch { return null; }
}

/** Reading and even accessing localStorage can fail in restricted browser contexts. */
export function loadProgress(storage: ProgressStorage | null = browserStorage()): LoadedProgress {
  if (!storage) return { progress: createInitialProgress(), storageStatus: 'memory' };
  try {
    const raw = storage.getItem(STORAGE_KEY);
    if (!raw) return { progress: createInitialProgress(), storageStatus: 'saved' };
    try { return { progress: normalizeProgress(JSON.parse(raw)), storageStatus: 'saved' }; }
    catch { return { progress: createInitialProgress(), storageStatus: 'saved' }; }
  } catch {
    return { progress: createInitialProgress(), storageStatus: 'memory' };
  }
}

export function saveProgress(progress: Progress, storage: ProgressStorage | null = browserStorage()): boolean {
  if (!storage) return false;
  try { storage.setItem(STORAGE_KEY, JSON.stringify(normalizeProgress(progress))); return true; }
  catch { return false; }
}
