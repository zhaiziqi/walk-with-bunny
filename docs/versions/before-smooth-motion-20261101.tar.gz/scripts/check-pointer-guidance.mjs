import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { advancePointerTarget, emptyPointerGuide, movePointerGuide, pointerGuideStrength, POINTER_ENTRY_TRAVEL, POINTER_GRACE_MS, POINTER_REST_MS } from '../src/scene/pointerGuidance.ts';
import { advanceMeadow, steerMeadow, followMeadowCamera, groundVelocity, MEADOW_SPEED } from '../src/scene/meadowMotion.ts';

let failures = 0;
const check = (name, run) => { try { run(); console.log(`PASS: ${name}`); } catch (error) { failures++; console.error(`FAIL: ${name}: ${error.message}`); } };
const input = (point, extra = {}) => ({ point, movementX: 4, movementY: 0, pointerType: 'mouse', buttons: 0, enabled: true, entered: true, blocked: false, ...extra });
// A first coordinate only establishes a baseline (including after an overlay).
const armedGuide = (point, now = 100) => {
  const baseline = movePointerGuide(emptyPointerGuide(), input({ x: point.x - 2, y: point.y }), now - 16);
  return movePointerGuide(baseline, input(point), now);
};

check('a panel, UI target, pressed mouse or touch cannot arm hover guidance', () => {
  for (const extra of [{ enabled: false }, { blocked: true }, { buttons: 1 }, { buttons: 2 }, { pointerType: 'touch' }]) {
    const state = movePointerGuide(emptyPointerGuide(), input({ x: 500, y: 250 }, extra), 100);
    assert.equal(state.target, null);
    assert.equal(pointerGuideStrength(state, 110), 0);
  }
});
check('zero movementX/Y still guides from changing client coordinates', () => {
  const extra = { movementX: 0, movementY: 0 };
  let state = movePointerGuide(emptyPointerGuide(), input({ x: 500, y: 250 }, extra), 100);
  assert.equal(state.target, null);
  assert.deepEqual(state.sample, { x: 500, y: 250 });
  state = movePointerGuide(state, input({ x: 504, y: 253 }, extra), 116);
  assert.deepEqual(state.target, { x: 504, y: 253 });
  assert.equal(pointerGuideStrength(state, 116), 1);
});
check('the invitation starts after deliberate client travel without any mouse press', () => {
  const extra = { entered: false, movementX: 0, movementY: 0 };
  let state = movePointerGuide(emptyPointerGuide(), input({ x: 500, y: 250 }, extra), 100);
  assert.equal(state.target, null);
  state = movePointerGuide(state, input({ x: 505, y: 250 }, extra), 116);
  assert.equal(state.target, null);
  state = movePointerGuide(state, input({ x: 500 + POINTER_ENTRY_TRAVEL, y: 250 }, extra), 132);
  assert.deepEqual(state.target, { x: 500 + POINTER_ENTRY_TRAVEL, y: 250 });
  assert.equal(pointerGuideStrength(state, 132), 1);
  // An asynchronous entered-state render must not interrupt the newly armed walk.
  state = movePointerGuide(state, input({ x: 530, y: 260 }, extra), 148);
  assert.equal(pointerGuideStrength(state, 148), 1);
});
check('one event or repeated layout coordinates cannot dismiss the invitation', () => {
  let state = movePointerGuide(emptyPointerGuide(), input({ x: 500, y: 250 }, { entered: false, movementX: 100 }), 100);
  assert.equal(state.target, null);
  for (let now = 116; now < 1000; now += 16) state = movePointerGuide(state, input({ x: 500, y: 250 }, { entered: false, movementX: 0 }), now);
  assert.equal(state.target, null);
});
check('fresh coordinate travel guides immediately after the baseline, without pressing', () => {
  const state = armedGuide({ x: 500, y: 250 });
  assert.deepEqual(state.target, { x: 500, y: 250 });
  assert.equal(pointerGuideStrength(state, 100), 1);
});
check('entering or restoring the surface without motion does not start a walk', () => {
  const state = movePointerGuide(emptyPointerGuide(), input({ x: 500, y: 250 }, { movementX: 0, movementY: 0 }), 100);
  assert.equal(state.target, null);
});
check('same-position events and tiny noise never refresh the expiry', () => {
  const state = armedGuide({ x: 500, y: 250 });
  const same = movePointerGuide(state, input({ x: 500, y: 250 }), 290);
  const noise = movePointerGuide(same, input({ x: 500.2, y: 250.1 }), 300);
  assert.equal(same, state); assert.equal(noise, state);
  assert.equal(pointerGuideStrength(noise, 100 + POINTER_REST_MS), 0);
});
check('a stopped pointer eases within the lease and becomes exactly zero', () => {
  const state = armedGuide({ x: 500, y: 250 });
  assert.equal(pointerGuideStrength(state, 100 + POINTER_GRACE_MS), 1);
  assert.ok(pointerGuideStrength(state, 100 + POINTER_GRACE_MS + 40) > pointerGuideStrength(state, 100 + POINTER_GRACE_MS + 120));
  for (const now of [100 + POINTER_REST_MS, 1000, 10000]) assert.equal(pointerGuideStrength(state, now), 0);
});
check('brief trackpad repositioning preserves intent instead of repeatedly restarting a walk', () => {
  let state = armedGuide({ x: 500, y: 250 });
  for (let now = 100; now < 1800; now += 220) {
    assert.ok(pointerGuideStrength(state, now) > .93);
    state = movePointerGuide(state, input({ x: state.target.x + 2, y: 250 }), now);
    assert.equal(pointerGuideStrength(state, now + POINTER_GRACE_MS), 1);
  }
  assert.equal(pointerGuideStrength(state, 1800 + POINTER_REST_MS), 0);
});
check('target smoothing reduces small alternating noise without delaying a deliberate reversal', () => {
  let target = { x: 500, y: 250 };
  const offsets = [];
  for (let frame = 0; frame < 120; frame++) {
    target = advancePointerTarget(target, { x: 500 + (frame % 2 ? 3 : -3), y: 250 }, 1 / 120);
    offsets.push(target.x - 500);
  }
  assert.ok(Math.max(...offsets) - Math.min(...offsets) < 1);
  target = { x: 800, y: 250 };
  for (let frame = 0; frame < 3; frame++) target = advancePointerTarget(target, { x: 200, y: 250 }, 1 / 60);
  assert.ok(target.x < 245, `three-frame reversal target was ${target.x}`);
  assert.deepEqual(advancePointerTarget(null, { x: 50, y: 60 }, 1 / 60), { x: 50, y: 60 });
});
check('smoothed target catches up consistently at ordinary desktop frame rates', () => {
  const positions = [30, 60, 120].map(fps => {
    let target = { x: 800, y: 250 };
    for (let frame = 0; frame < fps / 10; frame++) target = advancePointerTarget(target, { x: 200, y: 250 }, 1 / fps);
    return target.x;
  });
  assert.ok(Math.max(...positions) - Math.min(...positions) < 12);
  assert.ok(Math.max(...positions) < 220);
});
check('repeated short strokes maintain stride through finger lifts, then settle within the input lease', () => {
  for (const fps of [30, 60, 120]) {
    let guide = emptyPointerGuide(), filteredTarget = null, nextStrokeAt = 0, stroke = 0;
    let motion = { heading: { x: 1, y: 0 }, speed: 0 }, actor = { x: 0, y: 0, zoom: 1 };
    let minimumCruiseSpeed = Infinity, settled;
    for (let frame = 0; frame < fps * 3; frame++) {
      const now = frame * 1000 / fps;
      if (now < 2000 && now >= nextStrokeAt) {
        guide = movePointerGuide(guide, input({ x: 740 + stroke * 2, y: 400 }), now);
        nextStrokeAt += 220; stroke++;
      }
      if (guide.target) filteredTarget = advancePointerTarget(filteredTarget, guide.target, 1 / fps);
      const desired = groundVelocity(filteredTarget, { x: 500, y: 400 }, { x: 501, y: 400 }, { x: 500, y: 399 });
      const strength = pointerGuideStrength(guide, now);
      motion = steerMeadow(motion.heading, motion.speed, { x: desired.x * strength, y: desired.y * strength }, 1 / fps);
      actor = advanceMeadow(actor, motion.velocity, 1 / fps);
      if (now >= 800 && now < 2000) minimumCruiseSpeed = Math.min(minimumCruiseSpeed, motion.speed);
      if (Number.isFinite(guide.lastMovedAt) && now >= guide.lastMovedAt + POINTER_REST_MS) {
        assert.equal(motion.speed, 0);
        if (!settled) settled = { ...actor };
        assert.deepEqual(actor, settled);
      }
    }
    assert.ok(minimumCruiseSpeed > MEADOW_SPEED * .9, `${fps} fps cruise fell to ${minimumCruiseSpeed}`);
    assert.ok(settled);
  }
});
check('a new diagonal or reverse gesture changes both target axes and renews the lease', () => {
  let state = movePointerGuide(emptyPointerGuide(), input({ x: 500, y: 250 }), 100);
  state = movePointerGuide(state, input({ x: 700, y: 400 }), 250);
  assert.deepEqual(state.target, { x: 700, y: 400 }); assert.equal(pointerGuideStrength(state, 250), 1);
  state = movePointerGuide(state, input({ x: 250, y: 550 }), 280);
  assert.deepEqual(state.target, { x: 250, y: 550 }); assert.equal(pointerGuideStrength(state, 280), 1);
});
check('moving into a control cancels a live lease and stale events cannot restart it', () => {
  let state = movePointerGuide(emptyPointerGuide(), input({ x: 500, y: 250 }), 100);
  state = movePointerGuide(state, input({ x: 500, y: 250 }, { blocked: true }), 120);
  assert.equal(pointerGuideStrength(state, 125), 0);
  state = movePointerGuide(state, input({ x: 500, y: 250 }, { movementX: 0, movementY: 0 }), 140);
  assert.equal(pointerGuideStrength(state, 150), 0);
  state = movePointerGuide(state, input({ x: 505, y: 250 }), 160);
  assert.equal(pointerGuideStrength(state, 160), 1);
});
check('a one-frame timestamp skew stays fresh; invalid input and large clock errors are rejected', () => {
  const good = armedGuide({ x: 500, y: 250 });
  assert.equal(pointerGuideStrength(good, 90), 1);
  assert.equal(pointerGuideStrength(good, 0), 0);
  assert.equal(pointerGuideStrength(good, NaN), 0);
  assert.equal(movePointerGuide(good, input({ x: NaN, y: 1 }), 120).target, null);
  assert.equal(movePointerGuide(good, input({ x: 1, y: 1 }), Infinity).target, null);
});
check('zero-button strokes move the real integrator on both axes, then actor and camera settle', () => {
  const outcomes = [];
  for (const fps of [30, 60, 120]) {
    let guide = emptyPointerGuide(), actor = { x: 0, y: 0, zoom: 1 }, camera = { x: 0, y: 220, zoom: 1 };
    let motion = { heading: { x: .7071, y: .7071 }, speed: 0 };
    let stopped, filteredTarget = null;
    for (let frame = 0; frame < fps * 4; frame++) {
      const now = frame * 1000 / fps;
      if (now < 2000) guide = movePointerGuide(guide, input({ x: 700 + frame * 2, y: 100 - frame }), now);
      const strength = pointerGuideStrength(guide, now);
      if (guide.target) filteredTarget = advancePointerTarget(filteredTarget, guide.target, 1 / fps);
      const desired = groundVelocity(filteredTarget, { x: 500, y: 400 }, { x: 501, y: 400 }, { x: 500, y: 399 });
      motion = steerMeadow(motion.heading, motion.speed, { x: desired.x * strength, y: desired.y * strength }, 1 / fps);
      actor = advanceMeadow(actor, motion.velocity, 1 / fps);
      camera = followMeadowCamera(camera, actor, 1 / fps, motion.speed > 0, motion);
      if (now >= 2000 + POINTER_REST_MS + 50 && !stopped) stopped = { actor: { ...actor }, camera: { ...camera } };
      if (stopped) { assert.deepEqual(actor, stopped.actor); assert.deepEqual(camera, stopped.camera); }
    }
    assert.ok(actor.x > 180 && actor.y > 180);
    outcomes.push(Math.hypot(actor.x, actor.y));
  }
  assert.ok(Math.max(...outcomes) - Math.min(...outcomes) < 15);
});
// Run the actual hook, its DOM listeners, effects, ground projection and RAF loop.
// This deterministic hook host models state/ref/effect commits; it is not a browser
// or a claim about physical trackpad hardware. In particular, RAF timestamps may
// precede an input event delivered earlier in the same rendering frame.
const projectRequire = createRequire(import.meta.url);
const viteRequire = createRequire(projectRequire.resolve('vite/package.json'));
const { build } = viteRequire('esbuild');
const bundled = await build({
  absWorkingDir: fileURLToPath(new URL('..', import.meta.url)),
  entryPoints: ['src/motion/useMeadowJourney.ts'], bundle: true, write: false, format: 'cjs', platform: 'node',
  define: { 'import.meta.env.DEV': 'true' },
  plugins: [{ name: 'deterministic-hook-host', setup(builder) {
    builder.onResolve({ filter: /^(react|gsap)$/ }, args => ({ path: args.path, namespace: 'hook-host' }));
    builder.onLoad({ filter: /.*/, namespace: 'hook-host' }, args => ({ contents: args.path === 'react'
      ? `const host=globalThis.__pointerHookHost; export const useState=(...a)=>host.useState(...a); export const useRef=(...a)=>host.useRef(...a); export const useCallback=(...a)=>host.useCallback(...a); export const useEffect=(...a)=>host.useEffect(...a);`
      : `export default {to(){throw new Error('Unexpected approach tween in pointer-only test')}};` }));
  } }],
});
function withHook(run) {
  class Target {
    listeners = new Map();
    addEventListener(type, listener) { const group = this.listeners.get(type) ?? new Set(); group.add(listener); this.listeners.set(type, group); }
    removeEventListener(type, listener) { this.listeners.get(type)?.delete(listener); }
    dispatch(type, extra = {}) { const event = { type, target: this, preventDefault() {}, stopPropagation() {}, ...extra }; for (const listener of [...(this.listeners.get(type) ?? [])]) listener(event); }
  }
  class Element extends Target {
    style = {}; dataset = {}; inert = false; control = false; worldObject = false;
    closest(selector) { return (this.worldObject && selector.includes('data-world-object')) || (this.control && selector.includes('button')) ? this : null; }
    getBoundingClientRect() { return { left: 0, top: 0, width: 1280, height: 800 }; }
    hasPointerCapture() { return false; }
    setPointerCapture() {} releasePointerCapture() {}
    focus() { document.dispatch('focusin', { target: this }); }
  }
  const surface = new Element(), fakeWindow = new Target(), fakeDocument = new Target();
  fakeDocument.hidden = false;
  let now = 0, nextId = 1, cursor = 0, dirty = true, effects = [], options;
  const scheduled = new Map(), slots = [];
  const equal = (a, b) => a?.length === b?.length && a.every((value, i) => Object.is(value, b[i]));
  const host = {
    result: null,
    useState(initial) {
      const i = cursor++;
      if (!slots[i]) slots[i] = { value: typeof initial === 'function' ? initial() : initial };
      return [slots[i].value, next => { const value = typeof next === 'function' ? next(slots[i].value) : next; if (!Object.is(value, slots[i].value)) { slots[i].value = value; dirty = true; } }];
    },
    useRef(initial) { const i = cursor++; return slots[i] ?? (slots[i] = { current: initial }); },
    useCallback(callback, dependencies) { const i = cursor++; if (!slots[i] || !equal(slots[i].dependencies, dependencies)) slots[i] = { callback, dependencies }; return slots[i].callback; },
    useEffect(callback, dependencies) { const i = cursor++; if (!slots[i] || !equal(slots[i].dependencies, dependencies)) { const previous = slots[i]; slots[i] = { dependencies, cleanup: previous?.cleanup }; effects.push(() => { previous?.cleanup?.(); slots[i].cleanup = callback(); }); } },
  };
  const replacements = { Element, window: fakeWindow, document: fakeDocument, performance: { now: () => now },
    requestAnimationFrame: callback => { const id = nextId++; scheduled.set(id, callback); return id; },
    cancelAnimationFrame: id => scheduled.delete(id), __pointerHookHost: host };
  const saved = Object.fromEntries(Object.keys(replacements).map(key => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  for (const [key, value] of Object.entries(replacements)) Object.defineProperty(globalThis, key, { value, configurable: true, writable: true });
  const module = { exports: {} };
  new Function('module', 'exports', bundled.outputFiles[0].text)(module, module.exports);
  const { useMeadowJourney } = module.exports;
  let enteredCount = 0;
  options = { initialPose: { x: 0, y: -1580, zoom: 1 }, reduced: false, enabled: true, entered: false, width: 1280, height: 800,
    onExplore: () => { enteredCount++; options = { ...options, entered: true }; dirty = true; } };
  const commit = () => {
    for (let attempts = 0; dirty; attempts++) {
      assert.ok(attempts < 25, 'hook commit must settle');
      dirty = false; cursor = 0; host.result = useMeadowJourney(options); host.result.surfaceRef.current = surface;
      const pending = effects; effects = []; for (const effect of pending) effect();
    }
  };
  commit();
  const api = {
    surface, window: fakeWindow, document: fakeDocument,
    get result() { return host.result; }, get enteredCount() { return enteredCount; }, get frames() { return scheduled.size; },
    control: () => { const element = new Element(); element.control = true; return element; },
    worldObject: () => { const element = new Element(); element.control = true; element.worldObject = true; return element; },
    setOptions(next) { options = { ...options, ...next }; dirty = true; commit(); },
    move(time, x, y, type = 'pointermove', extra = {}) { now = time; surface.dispatch(type, { clientX: x, clientY: y, movementX: 0, movementY: 0, pointerType: 'mouse', buttons: 0, ...extra }); commit(); },
    key(time, type, code, extra = {}) { now = time; (type === 'keyup' ? fakeWindow : surface).dispatch(type, { code, repeat: false, ...extra }); commit(); },
    frame(time, timestamp = time) { now = time; const pending = [...scheduled.values()]; scheduled.clear(); for (const callback of pending) callback(timestamp); commit(); },
  };
  try { run(api); }
  finally {
    for (const slot of slots) slot?.cleanup?.();
    for (const [key, descriptor] of Object.entries(saved)) { if (descriptor) Object.defineProperty(globalThis, key, descriptor); else delete globalThis[key]; }
  }
}
check('first keyboard hold survives invitation entry, return to beginning and motion-preference changes', () => withHook(hook => {
  const home = { ...hook.result.pose };
  for (let round = 0; round < 3; round++) {
    if (round) {
      // App.returnToEntry batches jumpTo(HOME) with entered=false, then focuses
      // the surface. It does not reload the hook or require Begin wandering.
      hook.result.jumpTo(home);
      hook.setOptions({ entered: false });
      if (round === 2) {
        hook.setOptions({ reduced: true });
        hook.setOptions({ reduced: false });
      }
    }
    hook.surface.focus();
    const start = { ...hook.result.actor }, enteredBefore = hook.enteredCount;
    const downAt = 100 + round * 4000;
    hook.key(downAt, 'keydown', 'ArrowUp');
    assert.equal(hook.enteredCount, enteredBefore + 1, 'the first keydown must enter the garden');
    assert.equal(hook.frames, 1, 'entry state effects must preserve the first held key');
    for (let elapsed = 16; elapsed <= 2800; elapsed += 16) {
      // Browser repeat events must neither restart nor cancel the held intent.
      if (elapsed % 320 === 0) hook.key(downAt + elapsed, 'keydown', 'ArrowUp', { repeat: true });
      hook.frame(downAt + elapsed, downAt + elapsed - 8);
      assert.equal(hook.frames, 1, `round ${round}, hold cancelled at ${elapsed} ms`);
      const [, vy] = hook.surface.dataset.journeyIntent.split(',').map(Number);
      assert.ok(vy > MEADOW_SPEED * .8, 'held keyboard intention must remain active throughout the first entry');
    }
    assert.ok(hook.result.actor.y - start.y > MEADOW_SPEED * .82 * 2.8 * .6, 'first hold must travel well beyond a single frame');
    assert.equal(hook.enteredCount, enteredBefore + 1, 'repeat events must not re-enter the garden');
    hook.key(downAt + 2816, 'keyup', 'ArrowUp');
    assert.equal(hook.frames, 0);
    const stopped = { actor: { ...hook.result.actor }, pose: { ...hook.result.pose } };
    hook.frame(downAt + 3000);
    assert.deepEqual({ actor: hook.result.actor, pose: hook.result.pose }, stopped);
  }
}));
check('mounted hook survives input delivered after the RAF timestamp, then moves and rests', () => withHook(hook => {
  const start = { ...hook.result.actor };
  hook.move(100, 800, 300);
  hook.move(116, 820, 300);
  assert.equal(hook.enteredCount, 1);
  hook.frame(120, 112); // The callback starts after input; its rendering timestamp is earlier.
  assert.ok(hook.frames > 0, 'fresh intent must not cancel itself on the first RAF');
  for (let i = 1; i <= 30; i++) {
    const time = 120 + i * 16;
    hook.move(time, 820 + i * 2, 300);
    hook.frame(time + 4, time - 4);
  }
  assert.ok(Math.hypot(hook.result.actor.x - start.x, hook.result.actor.y - start.y) > 10, 'real hook must advance the actor');
  for (let time = 620; time <= 600 + POINTER_REST_MS + 50; time += 16) hook.frame(time, time - 8);
  assert.equal(hook.frames, 0);
  const rested = { actor: { ...hook.result.actor }, pose: { ...hook.result.pose } };
  hook.frame(2000, 1992);
  assert.deepEqual({ actor: hook.result.actor, pose: hook.result.pose }, rested);
}));
check('mounted mousemove-only stream works, controls cancel it and fresh motion resumes', () => withHook(hook => {
  const start = { ...hook.result.actor };
  hook.move(100, 800, 300, 'mousemove'); hook.move(116, 820, 300, 'mousemove');
  for (let i = 0; i < 25; i++) { hook.move(132 + i * 16, 824 + i * 2, 300, 'mousemove'); hook.frame(136 + i * 16); }
  assert.ok(Math.hypot(hook.result.actor.x - start.x, hook.result.actor.y - start.y) > 5);
  hook.move(550, 900, 300, 'mousemove', { target: hook.control() });
  assert.equal(hook.frames, 0);
  const stopped = { ...hook.result.actor };
  hook.frame(570); assert.deepEqual(hook.result.actor, stopped);
  hook.move(580, 920, 300, 'mousemove'); hook.move(596, 940, 300, 'mousemove'); hook.frame(610);
  assert.ok(hook.frames > 0);
  hook.surface.inert = true; hook.frame(626); assert.equal(hook.frames, 0);
}));
check('natural rest preserves a baseline for the next stroke; panel restoration still needs fresh travel', () => withHook(hook => {
  hook.move(100, 900, 250); hook.move(116, 920, 250);
  for (let time = 132; time < 116 + POINTER_REST_MS + 100; time += 16) hook.frame(time);
  assert.equal(hook.frames, 0);
  const rested = { ...hook.result.actor };
  hook.move(1100, 920, 250); // A duplicated compatibility event is not a stroke.
  assert.equal(hook.frames, 0);
  hook.move(1116, 924, 250);
  assert.equal(hook.frames, 1, 'first genuinely moved coordinate after rest should resume');
  hook.frame(1132);
  assert.ok(Math.hypot(hook.result.actor.x - rested.x, hook.result.actor.y - rested.y) > 0);
  hook.setOptions({ enabled: false });
  const panelPosition = { ...hook.result.actor };
  hook.setOptions({ enabled: true });
  hook.move(1200, 1000, 200); // A changed layout coordinate after closing is only a baseline.
  hook.frame(1216);
  assert.equal(hook.frames, 0);
  assert.deepEqual(hook.result.actor, panelPosition);
  hook.move(1232, 1005, 200); hook.frame(1248);
  assert.ok(hook.frames > 0);
}));
check('mounted hook passes through world hitboxes continuously and still stops for their click', () => withHook(hook => {
  hook.move(100, 800, 300); hook.move(116, 820, 300);
  for (let i = 0; i < 25; i++) { hook.move(132 + i * 16, 824 + i * 2, 300); hook.frame(136 + i * 16); }
  const object = hook.worldObject(), before = { ...hook.result.actor };
  hook.surface.dispatch('pointerover', { pointerType: 'mouse', target: object });
  assert.ok(hook.frames > 0, 'moving hitbox boundaries must not cancel the walk');
  for (let i = 0; i < 20; i++) { hook.move(550 + i * 16, 900 + i * 2, 300, 'pointermove', { target: object }); hook.frame(554 + i * 16); }
  assert.ok(Math.hypot(hook.result.actor.x - before.x, hook.result.actor.y - before.y) > 20);
  hook.surface.dispatch('pointerdown', { pointerType: 'mouse', target: object, button: 0 });
  assert.equal(hook.frames, 0);
  let clickSuppressed = false;
  hook.surface.dispatch('click', { target: object, detail: 1, preventDefault() { clickSuppressed = true; } });
  assert.equal(clickSuppressed, false, 'the object click must remain available to open its panel');
}));
check('mounted 300 ms trackpad strokes keep full intent and stride, then rest at the lease boundary', () => withHook(hook => {
  hook.move(100, 1080, 120); hook.move(116, 1100, 120);
  let nextStroke = 416, strokes = 0, lastInput = 116, minimumIntent = Infinity, minimumStride = Infinity;
  for (let time = 132; time <= 2200; time += 16) {
    if (time >= nextStroke) { hook.move(time, 1100 + ++strokes * 2, 120); lastInput = time; nextStroke = time + 300; }
    const before = { ...hook.result.actor };
    hook.frame(time + 4, time - 4);
    if (time > 700) {
      const [vx, vy] = hook.surface.dataset.journeyIntent.split(',').map(Number);
      minimumIntent = Math.min(minimumIntent, Math.hypot(vx, vy));
      minimumStride = Math.min(minimumStride, Math.hypot(hook.result.actor.x - before.x, hook.result.actor.y - before.y) / .016);
      assert.equal(hook.result.moving, true);
      assert.ok(hook.frames > 0);
    }
  }
  assert.ok(minimumIntent > MEADOW_SPEED * .99, `300 ms finger lifts reduced intent to ${minimumIntent}`);
  assert.ok(minimumStride > MEADOW_SPEED * .9, `300 ms finger lifts reduced stride to ${minimumStride}`);
  for (let time = 2220; time < lastInput + POINTER_REST_MS; time += 16) hook.frame(time);
  hook.frame(lastInput + POINTER_REST_MS);
  assert.equal(hook.frames, 0);
  const stopped = { actor: { ...hook.result.actor }, pose: { ...hook.result.pose } };
  hook.frame(lastInput + 1000); assert.deepEqual({ actor: hook.result.actor, pose: hook.result.pose }, stopped);
  hook.move(lastInput + 1100, 1140, 120); hook.move(lastInput + 1116, 1160, 120); hook.frame(lastInput + 1120);
  assert.ok(hook.frames > 0);
  hook.surface.dispatch('pointerleave', { pointerType: 'mouse' }); assert.equal(hook.frames, 0);
}));
if (failures) process.exitCode = 1;
