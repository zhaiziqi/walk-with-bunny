import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { CanvasTexture, DoubleSide, Group, Mesh, MeshBasicMaterial, PlaneGeometry, Shape, SRGBColorSpace } from 'three';
import type { Texture } from 'three';
import type { ArtKey } from '../config/art';
import { BILLBOARD_TILT, terrainHeight } from './depthWorld';
import { advanceAtlasInteraction, atlasEncounterSites, emptyAtlasInteraction, flockFlight, sequencePulse } from './atlasInteraction';
import type { AtlasPulse, AtlasSite } from './atlasInteraction';
import type { JourneyFrameRef } from './journeyFrame';
import { gardenWind, type GardenClock } from './gardenWind';
import { createOrchardPetalCanvas, createPondFallbackCanvas, orchardBlossoms, orchardFallenPetals, orchardPetalPose, orchardReveal, pondDriftPetals, pondFootprint, pondGlimpse, pondReveal, pondRipplePose, restoreOrchardPondMemory } from './orchardPond';

type Point = { x: number; y: number };
type Props = { textures: Partial<Record<ArtKey, Texture>>; actor: Point; moving: boolean; heading: Point; reading: boolean; onEvent?: (event: string) => void; pulse?: AtlasPulse; motion?: JourneyFrameRef; clock?: GardenClock; memories?: readonly string[] };
type SiteProps = Props & { site: AtlasSite };
const random = (index: number) => { const n = Math.sin(index * 127.1 + 311.7) * 43758.5453; return n - Math.floor(n); };
const opacity = (mesh: Mesh | null, value: number) => { if (mesh) (mesh.material as MeshBasicMaterial).opacity = value; };

/** Interaction state persists while distant scenery is culled; reading freezes every clock. */
function useSite({ site, actor, moving, reading, pulse, onEvent, motion, memories }: SiteProps) {
  const root = useRef<Group>(null!);
  const encounter = useRef(restoreOrchardPondMemory(emptyAtlasInteraction(), site, actor, memories, pulse));
  const time = useRef(0);
  useFrame((_state, delta) => {
    const liveActor = !reading && motion ? motion.current.actor : actor;
    const liveMoving = !reading && motion ? motion.current.moving : moving;
    const distance = Math.hypot(liveActor.x - site.x, liveActor.y - site.y);
    if (root.current) root.current.visible = distance < 2200 && site.y > liveActor.y - 1100;
    if (reading) return;
    const previous = encounter.current;
    encounter.current = advanceAtlasInteraction(previous, site, distance, delta, liveMoving, false, pulse);
    if (encounter.current.activations > previous.activations) onEvent?.(site.event);
    time.current += Math.min(delta, .05);
  });
  return { root, encounter, time };
}

function Glow({ texture, color = '#fff1c7', size = 140, strength = .25 }: { texture?: Texture; color?: string; size?: number; strength?: number }) {
  return texture ? <mesh><planeGeometry args={[size, size]}/><meshBasicMaterial map={texture} color={color} transparent opacity={strength} depthWrite={false} side={DoubleSide}/></mesh> : <mesh><circleGeometry args={[size / 3, 32]}/><meshBasicMaterial color={color} transparent opacity={strength * .4} depthWrite={false} side={DoubleSide}/></mesh>;
}

function usePaintedPetal() {
  const texture = useMemo(() => {
    const t = new CanvasTexture(createOrchardPetalCanvas()); t.colorSpace = SRGBColorSpace; return t;
  }, []);
  useEffect(() => () => texture.dispose(), [texture]);
  return texture;
}

function Orchard(props: SiteProps) {
  const { site, textures, reading, actor, motion, clock } = props, { root, encounter, time } = useSite(props);
  const petals = useRef<(Mesh | null)[]>([]), stems = useRef<(Group | null)[]>([]);
  const petalTexture = usePaintedPetal(), reveal = useRef(orchardReveal(actor));
  useFrame(() => {
    if (reading) return;
    const liveActor = motion?.current.actor ?? actor;
    reveal.current = orchardReveal(liveActor);
    root.current.visible = reveal.current > .005;
    if (!root.current.visible) return;
    const t = clock?.current ?? time.current, wind = gardenWind(t, site.x, site.y, .15);
    root.current.traverse(node => {
      if (node instanceof Mesh) {
        const material = node.material as MeshBasicMaterial;
        if (material.userData.baseOpacity !== undefined) material.opacity = material.userData.baseOpacity * reveal.current;
      }
    });
    petals.current.forEach((petal, i) => {
      if (!petal) return;
      const flight = orchardPetalPose(t, i, encounter.current.age, wind);
      petal.visible = flight.visible;
      petal.position.set(flight.x, flight.y, terrainHeight(site.x + flight.x, site.y + flight.y) - terrainHeight(site.x, site.y) + flight.z);
      petal.rotation.set(BILLBOARD_TILT, flight.tilt, flight.rotation);
      opacity(petal, flight.opacity * reveal.current);
    });
    stems.current.forEach((stem, i) => {
      if (!stem) return;
      const plant = orchardBlossoms[i], breeze = gardenWind(t, plant.x, plant.y, plant.phase);
      // The group origin stays at the planted foot; only the upper silhouette bends.
      stem.rotation.z = breeze.lean * .027;
    });
  });
  return <group ref={root} position={[site.x, site.y, terrainHeight(site.x, site.y) + 3]} name="atlas-orchard" visible={reveal.current > .005}>
    {textures.glow && <mesh scale={[1, .7, 1]}><planeGeometry args={[520, 410]}/><meshBasicMaterial map={textures.glow} color="#d7b5bf" transparent opacity={.065} userData={{ baseOpacity: .065 }} depthWrite={false}/></mesh>}
    {Array.from({ length: 14 }, (_, i) => <mesh key={i} ref={node => { petals.current[i] = node; }} scale={[17 + i % 4 * 2, 27 + i % 3 * 3, 1]}>
      <planeGeometry args={[1, 1]}/><meshBasicMaterial map={petalTexture} color={['#f2ced7', '#e2adbf', '#f7e7d7'][i % 3]} transparent opacity={0} depthWrite={false} side={DoubleSide} toneMapped={false}/>
    </mesh>)}
    {orchardFallenPetals.map((petal, i) => <mesh key={`fallen-${i}`} position={[petal.x - site.x, petal.y - site.y, terrainHeight(petal.x, petal.y) - terrainHeight(site.x, site.y) + 1]} rotation={[0, 0, petal.rotation]}>
      <planeGeometry args={[petal.w, petal.h]}/><meshBasicMaterial map={petalTexture} color={petal.color} transparent opacity={.67 * reveal.current} userData={{ baseOpacity: .67 }} depthWrite={false} side={DoubleSide} toneMapped={false}/>
    </mesh>)}
    {textures.flower && orchardBlossoms.map((plant, i) => <group key={plant.x} position={[plant.x - site.x, plant.y - site.y, terrainHeight(plant.x, plant.y) - terrainHeight(site.x, site.y)]}>
      {textures.contact && <mesh><planeGeometry args={[plant.w * .55, 17]}/><meshBasicMaterial map={textures.contact} color="#657c75" transparent opacity={.15 * reveal.current} userData={{ baseOpacity: .15 }} depthWrite={false}/></mesh>}
      <group rotation={[BILLBOARD_TILT, 0, 0]}><group ref={node => { stems.current[i] = node; }}><mesh position={[0, plant.h * .46, 0]}>
        <planeGeometry args={[plant.w, plant.h]}/><meshBasicMaterial map={textures.flower} transparent opacity={reveal.current} userData={{ baseOpacity: 1 }} alphaTest={.02} depthWrite={false} side={DoubleSide} toneMapped={false}/>
      </mesh></group></group>
    </group>)}
  </group>;
}

function Pond(props: SiteProps) {
  const { site, reading, actor, moving, motion, textures, clock } = props, { root, encounter, time } = useSite(props);
  const rings = useRef<(Mesh | null)[]>([]), surface = useRef<MeshBasicMaterial>(null!), shimmer = useRef<MeshBasicMaterial>(null!);
  const drifting = useRef<(Mesh | null)[]>([]);
  const rippleAges = useRef([10, 10, 10]), seen = useRef(0), lastRipple = useRef(-10), nextRipple = useRef(0);
  const previousActor = useRef({ ...actor }), reveal = useRef(pondReveal(actor));
  const petalTexture = usePaintedPetal();
  const fallback = useMemo(() => { const t = new CanvasTexture(createPondFallbackCanvas()); t.colorSpace = SRGBColorSpace; return t; }, []);
  const geometry = useMemo(() => {
    const geometry = new PlaneGeometry(pondFootprint.width, pondFootprint.height, 40, 32);
    const position = geometry.attributes.position, base = terrainHeight(site.x, site.y);
    for (let i = 0; i < position.count; i++) position.setZ(i, terrainHeight(site.x + position.getX(i), site.y + position.getY(i)) - base + .4);
    position.needsUpdate = true; return geometry;
  }, [site.x, site.y]);
  useEffect(() => () => { fallback.dispose(); geometry.dispose(); }, [fallback, geometry]);
  useFrame((_state, delta) => {
    if (reading) return;
    const liveActor = motion?.current.actor ?? actor;
    const liveMoving = motion?.current.moving ?? moving;
    const travel = Math.hypot(liveActor.x - previousActor.current.x, liveActor.y - previousActor.current.y);
    previousActor.current = { ...liveActor };
    reveal.current = pondReveal(liveActor);
    const glimpse = pondGlimpse(liveActor);
    root.current.visible = Math.max(reveal.current, glimpse) > .005;
    if (!root.current.visible) return;
    const dt = Math.max(0, Math.min(delta, .05)), activated = encounter.current.activations > seen.current;
    const t = clock?.current ?? time.current, wind = gardenWind(t, site.x, site.y, .35);
    if (surface.current) surface.current.opacity = reveal.current;
    // One soft moving reflection remains after the transient rings have settled.
    if (shimmer.current) shimmer.current.opacity = glimpse * (1 - reveal.current) * .16 + reveal.current * (.045 + wind.gust * .025 + Math.sin(t * .4) * .012);
    const actualStep = liveMoving && travel > .025 && travel < 100;
    if (activated || (encounter.current.inside && actualStep && time.current - lastRipple.current > 1.25)) {
      const i = nextRipple.current++ % 3; rippleAges.current[i] = 0; lastRipple.current = time.current;
      const ring = rings.current[i];
      if (ring) ring.position.set(Math.max(-120, Math.min(120, (liveActor.x - site.x) * .25)), Math.max(-62, Math.min(62, (liveActor.y - site.y) * .19)), 2 + i * .15);
    }
    seen.current = encounter.current.activations;
    rings.current.forEach((ring, i) => {
      if (!ring) return;
      rippleAges.current[i] += dt;
      const wave = pondRipplePose(rippleAges.current[i], i);
      ring.scale.set(wave.radiusX, wave.radiusY, 1); ring.rotation.z = wave.rotation;
      opacity(ring, wave.opacity * reveal.current);
    });
    drifting.current.forEach((petal, i) => {
      if (!petal) return;
      const rest = pondDriftPetals[i];
      petal.position.set(rest.x - site.x + Math.sin(t * .13 + i * 2) * 6, rest.y - site.y + Math.sin(t * .1 + i) * 3, 1.2 + i * .1);
      petal.rotation.z = rest.rotation + Math.sin(t * .18 + i) * .12;
      opacity(petal, .59 * reveal.current);
    });
  });
  return <group ref={root} position={[site.x, site.y, terrainHeight(site.x, site.y) + 3]} name="atlas-lily-pond" visible={pondGlimpse(actor) > .005}>
    {/* Ground paint is drawn before reflection and upright transparent scenery;
        depth testing stays enabled, so foreground terrain still occludes it. */}
    <mesh geometry={geometry} renderOrder={-2}><meshBasicMaterial ref={surface} map={textures.pondPaint ?? fallback} transparent opacity={reveal.current} depthWrite={false} alphaTest={.003} side={DoubleSide} toneMapped={false}/></mesh>
    {textures.glow && <mesh position={[-60, 30, 1]} scale={[1, .32, 1]} renderOrder={-1}><planeGeometry args={[400, 230]}/><meshBasicMaterial ref={shimmer} map={textures.glow} color="#e6ebd9" transparent opacity={.04 * reveal.current} depthWrite={false} toneMapped={false}/></mesh>}
    {[0, 1, 2].map(i => <mesh key={i} ref={node => { rings.current[i] = node; }}>
      <ringGeometry args={[.975, 1, 80, 1, .24, Math.PI * 1.62]}/><meshBasicMaterial color="#e8edda" transparent opacity={0} depthWrite={false} side={DoubleSide} toneMapped={false}/>
    </mesh>)}
    {pondDriftPetals.map((petal, i) => <mesh key={i} ref={node => { drifting.current[i] = node; }} position={[petal.x - site.x, petal.y - site.y, 1.2 + i * .1]} rotation={[0, 0, petal.rotation]}>
      <planeGeometry args={[petal.w, petal.h]}/><meshBasicMaterial map={petalTexture} color={petal.color} transparent opacity={.59 * reveal.current} depthWrite={false} side={DoubleSide} toneMapped={false}/>
    </mesh>)}
  </group>;
}

const mushrooms = [[-175, 40, .85], [-120, -30, 1.1], [-65, 80, .65], [20, 125, .9], [110, 70, 1.2], [175, -15, .78], [220, 55, .64]];
function Hollow(props: SiteProps) {
  const { site, textures, reading } = props, { root, encounter, time } = useSite(props);
  const bodies = useRef<(Group | null)[]>([]), lights = useRef<(Mesh | null)[]>([]);
  const cap = useMemo(() => { const shape = new Shape(); shape.moveTo(-36, 0); shape.bezierCurveTo(-31, 44, 28, 48, 37, 2); shape.quadraticCurveTo(4, -11, -36, 0); return shape; }, []);
  useFrame(() => {
    if (reading || !root.current?.visible) return;
    mushrooms.forEach((_, i) => {
      const pulse = sequencePulse(encounter.current.age, i, .28), body = bodies.current[i], light = lights.current[i];
      if (body) { body.position.y = pulse * 22; body.rotation.z = Math.sin(encounter.current.age * 8 - i) * pulse * .09; body.scale.y = 1 + pulse * .15; }
      opacity(light, .05 + pulse * .65 + Math.sin(time.current * .8 + i) * .015);
    });
  });
  return <group ref={root} position={[site.x, site.y, terrainHeight(site.x, site.y) + 2]} name="atlas-mushroom-hollow">
    {mushrooms.map(([x, y, scale], i) => <group key={i} position={[x, y, terrainHeight(site.x + x, site.y + y) - terrainHeight(site.x, site.y)]} rotation={[BILLBOARD_TILT, 0, 0]} scale={scale}>
      <mesh ref={node => { lights.current[i] = node; }} position={[0, 36, -.5]}><planeGeometry args={[170, 170]}/><meshBasicMaterial map={textures.glow} color="#ede9b9" transparent opacity={.05} depthWrite={false}/></mesh>
      <group ref={node => { bodies.current[i] = node; }}>
        <mesh position={[0, 20, 0]} scale={[7, 23, 1]}><circleGeometry args={[1, 16]}/><meshBasicMaterial color="#d6d6bd"/></mesh>
        <mesh position={[0, 36, .5]}><shapeGeometry args={[cap]}/><meshBasicMaterial color={['#bfa8bd', '#d4b6bc', '#bab9cf'][i % 3]} transparent opacity={.96} side={DoubleSide}/></mesh>
        <mesh position={[0, 36, .7]} scale={[31, 5, 1]}><circleGeometry args={[1, 24]}/><meshBasicMaterial color="#ede3ce" transparent opacity={.78}/></mesh>
        {[[-15, 55, 3], [8, 64, 4], [21, 49, 2.5]].map(([px, py, r], j) => <mesh key={j} position={[px, py, 1]}><circleGeometry args={[r, 9]}/><meshBasicMaterial color="#eee7d7" transparent opacity={.72}/></mesh>)}
      </group>
    </group>)}
    {textures.fern && [-280, 290].map((x, i) => <group key={x} position={[x, 120, terrainHeight(site.x + x, site.y + 120) - terrainHeight(site.x, site.y)]} rotation={[BILLBOARD_TILT, 0, 0]}><mesh position={[0, 70, 0]} scale={[i ? -1 : 1, 1, 1]}><planeGeometry args={[170, 145]}/><meshBasicMaterial map={textures.fern} transparent alphaTest={.02} depthWrite={false} side={DoubleSide}/></mesh></group>)}
  </group>;
}

function Arch(props: SiteProps) {
  const { site, textures, reading } = props, { root, encounter, time } = useSite(props);
  const bell = useRef<Group>(null!), fireflies = useRef<(Group | null)[]>([]);
  useFrame(() => {
    if (reading || !root.current?.visible) return;
    const wake = Math.exp(-encounter.current.age * .28);
    if (bell.current) bell.current.rotation.z = Math.sin(time.current * 2.6) * (.025 + wake * .23);
    fireflies.current.forEach((fly, i) => {
      if (!fly) return;
      const angle = i * 2.39996 + time.current * (.09 + wake * .08), radius = 90 + random(i + 1) * 180;
      fly.position.set(Math.cos(angle) * radius, Math.sin(angle) * radius * .5 + 70, 60 + random(i + 37) * 270 + Math.sin(time.current * .8 + i) * (8 + wake * 30));
      fly.scale.setScalar((.55 + (1 + Math.sin(time.current * 1.4 + i)) * .2) * (1 + wake));
    });
  });
  return <group ref={root} position={[site.x, site.y, terrainHeight(site.x, site.y) + 2]} name="atlas-old-arch">
    <group rotation={[BILLBOARD_TILT, 0, 0]}>
      {textures.arch && <mesh position={[0, 630 * (.5 - .05208333), 0]}><planeGeometry args={[420, 630]}/><meshBasicMaterial map={textures.arch} transparent alphaTest={.025} depthWrite={false} side={DoubleSide}/></mesh>}
      <group ref={bell} position={[0, 390, 4]}>
        <mesh position={[0, -26, 0]}><planeGeometry args={[1.8, 52]}/><meshBasicMaterial color="#adaeab"/></mesh>
        <mesh position={[0, -57, .2]} scale={[19, 12, 1]}><circleGeometry args={[1, 24, 0, Math.PI]}/><meshBasicMaterial color="#c7bca1" side={DoubleSide}/></mesh>
        <mesh position={[0, -77, 0]}><planeGeometry args={[1.4, 42]}/><meshBasicMaterial color="#adaeab"/></mesh>
        <mesh position={[0, -105, .1]} rotation={[0, 0, -.08]}><planeGeometry args={[12, 28]}/><meshBasicMaterial color="#e3d9bd" transparent opacity={.92} side={DoubleSide}/></mesh>
      </group>
    </group>
    {Array.from({ length: 22 }, (_, i) => <group key={i} ref={node => { fireflies.current[i] = node; }}><group rotation={[BILLBOARD_TILT, 0, 0]}><Glow texture={textures.glow} size={48} color="#f5e8ad" strength={.5}/><mesh><circleGeometry args={[2.8, 12]}/><meshBasicMaterial color="#fff0be" transparent opacity={.9} depthWrite={false}/></mesh></group></group>)}
  </group>;
}

function Hill(props: SiteProps) {
  const { site, textures, reading } = props, { root, encounter, time } = useSite(props);
  const birds = useRef<(Group | null)[]>([]), wings = useRef<(Group | null)[]>([]);
  const wing = useMemo(() => { const shape = new Shape(); shape.moveTo(0, 0); shape.lineTo(33, 18); shape.lineTo(20, -8); shape.lineTo(0, -4); shape.closePath(); return shape; }, []);
  useFrame(() => {
    if (reading || !root.current?.visible) return;
    birds.current.forEach((bird, i) => {
      if (!bird) return;
      const flight = flockFlight(encounter.current.age, i), flying = encounter.current.age < 9.2;
      const restingX = i * 40 - 120, restingY = i % 2 * 30;
      const p = Math.min(1, Math.max(0, encounter.current.age - i * .16) / 8);
      const ground = terrainHeight(site.x + restingX, site.y + restingY) - terrainHeight(site.x, site.y);
      bird.position.set(flying ? flight.x + restingX - (i * 24 - 48) : restingX, flying ? flight.y + restingY - p * 150 : restingY, ground + (flying ? flight.z : 24));
      bird.rotation.z = flying ? flight.bank : i * .15 - .4;
      if (wings.current[i]) wings.current[i]!.scale.x = flying ? .48 + Math.abs(Math.sin(time.current * 8 + i)) * .52 : .8;
    });
  });
  return <group ref={root} position={[site.x, site.y, terrainHeight(site.x, site.y) + 2]} name="atlas-paperbird-hill">
    <mesh scale={[1, .55, 1]}><circleGeometry args={[175, 48]}/><meshBasicMaterial color="#e7debe" transparent opacity={.12} depthWrite={false}/></mesh>
    {Array.from({ length: 7 }, (_, i) => <group key={i} ref={node => { birds.current[i] = node; }}><group rotation={[BILLBOARD_TILT, 0, 0]}>
      <group ref={node => { wings.current[i] = node; }}>
        {[-1, 1].map(side => <mesh key={side} scale={[side, 1, 1]}><shapeGeometry args={[wing]}/><meshBasicMaterial color={side < 0 ? '#eee7d5' : '#d3d9d6'} transparent opacity={.94} side={DoubleSide}/></mesh>)}
      </group><mesh position={[0, -1, .3]} scale={[2, 8, 1]}><circleGeometry args={[1, 4]}/><meshBasicMaterial color="#b9c4c4"/></mesh>
    </group></group>)}
    {textures.grass && [-200, 205].map(x => <group key={x} position={[x, 75, terrainHeight(site.x + x, site.y + 75) - terrainHeight(site.x, site.y)]} rotation={[BILLBOARD_TILT, 0, 0]}><mesh position={[0, 42, 0]}><planeGeometry args={[130, 90]}/><meshBasicMaterial map={textures.grass} color="#c9c7a9" transparent opacity={.85} depthWrite={false}/></mesh></group>)}
  </group>;
}

function Moon(props: SiteProps) {
  const { site, textures, reading } = props, { root, encounter, time } = useSite(props);
  const rings = useRef<(Mesh | null)[]>([]), halo = useRef<Group>(null!), stars = useRef<(Mesh | null)[]>([]);
  useFrame(() => {
    if (reading || !root.current?.visible) return;
    const wake = Math.exp(-encounter.current.age * .32);
    rings.current.forEach((ring, i) => {
      if (!ring) return;
      const p = Math.max(0, Math.min(1, (encounter.current.age - i * .65) / 5));
      ring.scale.setScalar(.35 + p * 1.25);
      opacity(ring, Math.sin(p * Math.PI) * .66);
    });
    if (halo.current) halo.current.scale.setScalar(1 + wake * .25 + Math.sin(time.current * .45) * .025);
    stars.current.forEach((star, i) => {
      if (!star) return;
      const angle = i * 2.39996 + time.current * .03, radius = 170 + i % 4 * 30;
      star.position.set(Math.cos(angle) * radius, Math.sin(angle) * radius * .68, 38 + wake * (55 + i % 5 * 12));
      opacity(star, .18 + wake * .62 + Math.sin(time.current + i) * .08);
    });
  });
  return <group ref={root} position={[site.x, site.y, terrainHeight(site.x, site.y) + 4]} name="atlas-moon-clearing">
    <group ref={halo}><Glow texture={textures.glow} size={680} color="#c3d5ed" strength={.32}/></group>
    <mesh scale={[1, .72, 1]}><ringGeometry args={[185, 187, 96]}/><meshBasicMaterial color="#dce3ef" transparent opacity={.35} depthWrite={false} side={DoubleSide}/></mesh>
    {[0, 1, 2].map(i => <group key={i} scale={[1, .72, 1]}><mesh ref={node => { rings.current[i] = node; }} position={[0, 0, 2 + i * .12]}><ringGeometry args={[190, 193, 96]}/><meshBasicMaterial color="#e8e9ee" transparent opacity={0} depthWrite={false} side={DoubleSide}/></mesh></group>)}
    {Array.from({ length: 16 }, (_, i) => <mesh key={i} ref={node => { stars.current[i] = node; }} rotation={[BILLBOARD_TILT, 0, Math.PI / 4]} scale={[1, 1.4, 1]}><circleGeometry args={[3 + i % 3, 4]}/><meshBasicMaterial color="#e4e7f1" transparent opacity={.3} depthWrite={false} side={DoubleSide}/></mesh>)}
    <group position={[0, 170, 400]} rotation={[BILLBOARD_TILT, 0, 0]}>
      <Glow texture={textures.glow} color="#dbe1eb" size={330} strength={.22}/>
      <mesh scale={[1, 1, 1]}><circleGeometry args={[51, 64]}/><meshBasicMaterial color="#e7e7dd" transparent opacity={.82} depthWrite={false}/></mesh>
      <mesh position={[-12, 8, .1]}><circleGeometry args={[48, 64]}/><meshBasicMaterial color="#d1d9df" transparent opacity={.3} depthWrite={false}/></mesh>
    </group>
  </group>;
}

/** Six fixed landmarks share the atlas controller without introducing interface elements. */
export function AtlasEncounters(props: Props) {
  return <>{atlasEncounterSites.map(site => {
    const Component = { orchard: Orchard, pond: Pond, hollow: Hollow, arch: Arch, hill: Hill, moon: Moon }[site.id];
    return <Component key={site.id} {...props} site={site}/>;
  })}</>;
}
