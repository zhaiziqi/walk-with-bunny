import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { CanvasTexture, DoubleSide, Group, Mesh, MeshBasicMaterial, PlaneGeometry, SRGBColorSpace } from 'three';
import type { Texture } from 'three';
import type { ArtKey } from '../config/art';
import { BILLBOARD_TILT, terrainHeight } from './depthWorld';
import { advanceAtlasInteraction, atlasEncounterSites, emptyAtlasInteraction } from './atlasInteraction';
import type { AtlasPulse, AtlasSite } from './atlasInteraction';
import { archComposition, archGroundOffset, archMotes, archMotePose, archReveal, chimeResponse, createArchFallbackCanvas, createChimeCanvas, createMushroomFallbackCanvas, hollowMushrooms, hollowReveal, mushroomResponse, restoreHollowArchMemory } from './hollowArch';
import type { JourneyFrameRef } from './journeyFrame';
import { gardenWind, type GardenClock } from './gardenWind';
import { createOrchardPetalCanvas, createPondFallbackCanvas, orchardBlossoms, orchardFallenPetals, orchardPetalPose, orchardReveal, pondDriftPetals, pondFootprint, pondGlimpse, pondReveal, pondRipplePose, restoreOrchardPondMemory } from './orchardPond';
import { advanceBirdFlight, createMoonGroundCanvas, createPaperBirdCanvas, createPaperMoonCanvas, hillBirds, hillReveal, moonGround, moonLightResponse, moonMotes, moonMotePose, moonOrb, moonReveal, paperBirdPose, restoreHillMoonMemory } from './hillMoon';

type Point = { x: number; y: number };
type Props = { textures: Partial<Record<ArtKey, Texture>>; actor: Point; moving: boolean; heading: Point; reading: boolean; onEvent?: (event: string) => void; pulse?: AtlasPulse; motion?: JourneyFrameRef; clock?: GardenClock; memories?: readonly string[] };
type SiteProps = Props & { site: AtlasSite };
const opacity = (mesh: Mesh | null, value: number) => { if (mesh) (mesh.material as MeshBasicMaterial).opacity = value; };

/** Interaction state persists while distant scenery is culled; reading freezes every clock. */
function useSite({ site, actor, moving, reading, pulse, onEvent, motion, memories }: SiteProps) {
  const root = useRef<Group>(null!);
  const encounter = useRef(restoreHillMoonMemory(restoreHollowArchMemory(restoreOrchardPondMemory(emptyAtlasInteraction(), site, actor, memories, pulse), site, actor, memories, pulse), site, actor, memories, pulse));
  const time = useRef(0);
  useFrame((_state, delta) => {
    const liveActor = !reading && motion ? motion.current.actor : actor;
    const liveMoving = !reading && motion ? motion.current.moving : moving;
    const distance = Math.hypot(liveActor.x - site.x, liveActor.y - site.y);
    if (root.current) root.current.visible = distance < 2200 && site.y > liveActor.y - 1100;
    if (reading) return;
    const previous = encounter.current;
    encounter.current = advanceAtlasInteraction(previous, site, distance, delta, liveMoving, false, pulse);
    if (encounter.current.activations > previous.activations) onEvent?.(site.event);
    time.current += Math.min(delta, .05);
  });
  return { root, encounter, time };
}

function usePaintedPetal() {
  const texture = useMemo(() => {
    const t = new CanvasTexture(createOrchardPetalCanvas()); t.colorSpace = SRGBColorSpace; return t;
  }, []);
  useEffect(() => () => texture.dispose(), [texture]);
  return texture;
}

function Orchard(props: SiteProps) {
  const { site, textures, reading, actor, motion, clock } = props, { root, encounter, time } = useSite(props);
  const petals = useRef<(Mesh | null)[]>([]), stems = useRef<(Group | null)[]>([]);
  const petalTexture = usePaintedPetal(), reveal = useRef(orchardReveal(actor));
  useFrame(() => {
    if (reading) return;
    const liveActor = motion?.current.actor ?? actor;
    reveal.current = orchardReveal(liveActor);
    root.current.visible = reveal.current > .005;
    if (!root.current.visible) return;
    const t = clock?.current ?? time.current, wind = gardenWind(t, site.x, site.y, .15);
    root.current.traverse(node => {
      if (node instanceof Mesh) {
        const material = node.material as MeshBasicMaterial;
        if (material.userData.baseOpacity !== undefined) material.opacity = material.userData.baseOpacity * reveal.current;
      }
    });
    petals.current.forEach((petal, i) => {
      if (!petal) return;
      const flight = orchardPetalPose(t, i, encounter.current.age, wind);
      petal.visible = flight.visible;
      petal.position.set(flight.x, flight.y, terrainHeight(site.x + flight.x, site.y + flight.y) - terrainHeight(site.x, site.y) + flight.z);
      petal.rotation.set(BILLBOARD_TILT, flight.tilt, flight.rotation);
      opacity(petal, flight.opacity * reveal.current);
    });
    stems.current.forEach((stem, i) => {
      if (!stem) return;
      const plant = orchardBlossoms[i], breeze = gardenWind(t, plant.x, plant.y, plant.phase);
      // The group origin stays at the planted foot; only the upper silhouette bends.
      stem.rotation.z = breeze.lean * .027;
    });
  });
  return <group ref={root} position={[site.x, site.y, terrainHeight(site.x, site.y) + 3]} name="atlas-orchard" visible={reveal.current > .005}>
    {textures.glow && <mesh scale={[1, .7, 1]}><planeGeometry args={[520, 410]}/><meshBasicMaterial map={textures.glow} color="#d7b5bf" transparent opacity={.065} userData={{ baseOpacity: .065 }} depthWrite={false}/></mesh>}
    {Array.from({ length: 14 }, (_, i) => <mesh key={i} ref={node => { petals.current[i] = node; }} scale={[17 + i % 4 * 2, 27 + i % 3 * 3, 1]}>
      <planeGeometry args={[1, 1]}/><meshBasicMaterial map={petalTexture} color={['#f2ced7', '#e2adbf', '#f7e7d7'][i % 3]} transparent opacity={0} depthWrite={false} side={DoubleSide} toneMapped={false}/>
    </mesh>)}
    {orchardFallenPetals.map((petal, i) => <mesh key={`fallen-${i}`} position={[petal.x - site.x, petal.y - site.y, terrainHeight(petal.x, petal.y) - terrainHeight(site.x, site.y) + 1]} rotation={[0, 0, petal.rotation]}>
      <planeGeometry args={[petal.w, petal.h]}/><meshBasicMaterial map={petalTexture} color={petal.color} transparent opacity={.67 * reveal.current} userData={{ baseOpacity: .67 }} depthWrite={false} side={DoubleSide} toneMapped={false}/>
    </mesh>)}
    {textures.flower && orchardBlossoms.map((plant, i) => <group key={plant.x} position={[plant.x - site.x, plant.y - site.y, terrainHeight(plant.x, plant.y) - terrainHeight(site.x, site.y)]}>
      {textures.contact && <mesh><planeGeometry args={[plant.w * .55, 17]}/><meshBasicMaterial map={textures.contact} color="#657c75" transparent opacity={.15 * reveal.current} userData={{ baseOpacity: .15 }} depthWrite={false}/></mesh>}
      <group rotation={[BILLBOARD_TILT, 0, 0]}><group ref={node => { stems.current[i] = node; }}><mesh position={[0, plant.h * .46, 0]}>
        <planeGeometry args={[plant.w, plant.h]}/><meshBasicMaterial map={textures.flower} transparent opacity={reveal.current} userData={{ baseOpacity: 1 }} alphaTest={.02} depthWrite={false} side={DoubleSide} toneMapped={false}/>
      </mesh></group></group>
    </group>)}
  </group>;
}

function Pond(props: SiteProps) {
  const { site, reading, actor, moving, motion, textures, clock } = props, { root, encounter, time } = useSite(props);
  const rings = useRef<(Mesh | null)[]>([]), surface = useRef<MeshBasicMaterial>(null!), shimmer = useRef<MeshBasicMaterial>(null!);
  const drifting = useRef<(Mesh | null)[]>([]);
  const rippleAges = useRef([10, 10, 10]), seen = useRef(0), lastRipple = useRef(-10), nextRipple = useRef(0);
  const previousActor = useRef({ ...actor }), reveal = useRef(pondReveal(actor));
  const petalTexture = usePaintedPetal();
  const fallback = useMemo(() => { const t = new CanvasTexture(createPondFallbackCanvas()); t.colorSpace = SRGBColorSpace; return t; }, []);
  const geometry = useMemo(() => {
    const geometry = new PlaneGeometry(pondFootprint.width, pondFootprint.height, 40, 32);
    const position = geometry.attributes.position, base = terrainHeight(site.x, site.y);
    for (let i = 0; i < position.count; i++) position.setZ(i, terrainHeight(site.x + position.getX(i), site.y + position.getY(i)) - base + .4);
    position.needsUpdate = true; return geometry;
  }, [site.x, site.y]);
  useEffect(() => () => { fallback.dispose(); geometry.dispose(); }, [fallback, geometry]);
  useFrame((_state, delta) => {
    if (reading) return;
    const liveActor = motion?.current.actor ?? actor;
    const liveMoving = motion?.current.moving ?? moving;
    const travel = Math.hypot(liveActor.x - previousActor.current.x, liveActor.y - previousActor.current.y);
    previousActor.current = { ...liveActor };
    reveal.current = pondReveal(liveActor);
    const glimpse = pondGlimpse(liveActor);
    root.current.visible = Math.max(reveal.current, glimpse) > .005;
    if (!root.current.visible) return;
    const dt = Math.max(0, Math.min(delta, .05)), activated = encounter.current.activations > seen.current;
    const t = clock?.current ?? time.current, wind = gardenWind(t, site.x, site.y, .35);
    if (surface.current) surface.current.opacity = reveal.current;
    // One soft moving reflection remains after the transient rings have settled.
    if (shimmer.current) shimmer.current.opacity = glimpse * (1 - reveal.current) * .16 + reveal.current * (.045 + wind.gust * .025 + Math.sin(t * .4) * .012);
    const actualStep = liveMoving && travel > .025 && travel < 100;
    if (activated || (encounter.current.inside && actualStep && time.current - lastRipple.current > 1.25)) {
      const i = nextRipple.current++ % 3; rippleAges.current[i] = 0; lastRipple.current = time.current;
      const ring = rings.current[i];
      if (ring) ring.position.set(Math.max(-120, Math.min(120, (liveActor.x - site.x) * .25)), Math.max(-62, Math.min(62, (liveActor.y - site.y) * .19)), 2 + i * .15);
    }
    seen.current = encounter.current.activations;
    rings.current.forEach((ring, i) => {
      if (!ring) return;
      rippleAges.current[i] += dt;
      const wave = pondRipplePose(rippleAges.current[i], i);
      ring.scale.set(wave.radiusX, wave.radiusY, 1); ring.rotation.z = wave.rotation;
      opacity(ring, wave.opacity * reveal.current);
    });
    drifting.current.forEach((petal, i) => {
      if (!petal) return;
      const rest = pondDriftPetals[i];
      petal.position.set(rest.x - site.x + Math.sin(t * .13 + i * 2) * 6, rest.y - site.y + Math.sin(t * .1 + i) * 3, 1.2 + i * .1);
      petal.rotation.z = rest.rotation + Math.sin(t * .18 + i) * .12;
      opacity(petal, .59 * reveal.current);
    });
  });
  return <group ref={root} position={[site.x, site.y, terrainHeight(site.x, site.y) + 3]} name="atlas-lily-pond" visible={pondGlimpse(actor) > .005}>
    {/* Ground paint is drawn before reflection and upright transparent scenery;
        depth testing stays enabled, so foreground terrain still occludes it. */}
    <mesh geometry={geometry} renderOrder={-2}><meshBasicMaterial ref={surface} map={textures.pondPaint ?? fallback} transparent opacity={reveal.current} depthWrite={false} alphaTest={.003} side={DoubleSide} toneMapped={false}/></mesh>
    {textures.glow && <mesh position={[-60, 30, 1]} scale={[1, .32, 1]} renderOrder={-1}><planeGeometry args={[400, 230]}/><meshBasicMaterial ref={shimmer} map={textures.glow} color="#e6ebd9" transparent opacity={.04 * reveal.current} depthWrite={false} toneMapped={false}/></mesh>}
    {[0, 1, 2].map(i => <mesh key={i} ref={node => { rings.current[i] = node; }}>
      <ringGeometry args={[.975, 1, 80, 1, .24, Math.PI * 1.62]}/><meshBasicMaterial color="#e8edda" transparent opacity={0} depthWrite={false} side={DoubleSide} toneMapped={false}/>
    </mesh>)}
    {pondDriftPetals.map((petal, i) => <mesh key={i} ref={node => { drifting.current[i] = node; }} position={[petal.x - site.x, petal.y - site.y, 1.2 + i * .1]} rotation={[0, 0, petal.rotation]}>
      <planeGeometry args={[petal.w, petal.h]}/><meshBasicMaterial map={petalTexture} color={petal.color} transparent opacity={.59 * reveal.current} depthWrite={false} side={DoubleSide} toneMapped={false}/>
    </mesh>)}
  </group>;
}

function useCanvasSheet(create: () => HTMLCanvasElement) {
  const texture = useMemo(() => { const sheet = new CanvasTexture(create()); sheet.colorSpace = SRGBColorSpace; sheet.anisotropy = 4; return sheet; }, [create]);
  useEffect(() => () => texture.dispose(), [texture]);
  return texture;
}
function revealPaint(root: Group, reveal: number) {
  root.traverse(node => {
    if (!(node instanceof Mesh)) return;
    const material = node.material as MeshBasicMaterial;
    if (material.userData.baseOpacity !== undefined) material.opacity = material.userData.baseOpacity * reveal;
  });
}

function Hollow(props: SiteProps) {
  const { site, textures, reading, motion, actor, clock } = props, { root, encounter, time } = useSite(props);
  const bodies = useRef<(Group | null)[]>([]), lights = useRef<(Mesh | null)[]>([]);
  const fallback = useCanvasSheet(createMushroomFallbackCanvas), revealed = hollowReveal(actor);
  useFrame(() => {
    const alpha = hollowReveal(!reading && motion ? motion.current.actor : actor);
    root.current.visible = alpha > .005;
    if (reading || !root.current.visible) return;
    revealPaint(root.current, alpha);
    const t = clock?.current ?? time.current;
    hollowMushrooms.forEach((mushroom, i) => {
      const wind = gardenWind(t, mushroom.x, mushroom.y, mushroom.phase);
      const response = mushroomResponse(encounter.current.age, i, wind.lean);
      const body = bodies.current[i];
      if (body) { body.rotation.z = response.lean; body.scale.y = response.stretch; }
      opacity(lights.current[i], response.glow * alpha);
    });
  });
  return <group ref={root} position={[site.x, site.y, terrainHeight(site.x, site.y) + 3]} name="atlas-mushroom-hollow" visible={revealed > .005}>
    {hollowMushrooms.map((mushroom, i) => <group key={i} position={[mushroom.x - site.x, mushroom.y - site.y, terrainHeight(mushroom.x, mushroom.y) - terrainHeight(site.x, site.y)]}>
      {textures.contact && <mesh><planeGeometry args={[mushroom.w * .70, 25]}/><meshBasicMaterial map={textures.contact} color="#617574" transparent opacity={.19 * revealed} userData={{ baseOpacity: .19 }} depthWrite={false} toneMapped={false}/></mesh>}
      {textures.glow && <mesh ref={node => { lights.current[i] = node; }} position={[0, 0, .6]}><planeGeometry args={[mushroom.w * 1.65, mushroom.w * 1.15]}/><meshBasicMaterial map={textures.glow} color="#e3d8bf" transparent opacity={.025 * revealed} depthWrite={false} toneMapped={false}/></mesh>}
      <group rotation={[BILLBOARD_TILT, 0, 0]}><group ref={node => { bodies.current[i] = node; }}>
        <mesh position={[0, mushroom.h * (mushroom.foot - .5), 0]} scale={[mushroom.flip ? -1 : 1, 1, 1]}>
          <planeGeometry args={[mushroom.w, mushroom.h]}/><meshBasicMaterial map={textures.mushroomPaint ?? fallback} transparent opacity={revealed} userData={{ baseOpacity: 1 }} alphaTest={.015} depthWrite={false} side={DoubleSide} toneMapped={false}/>
        </mesh>
      </group></group>
    </group>)}
  </group>;
}

function Arch(props: SiteProps) {
  const { site, textures, reading, actor, motion, clock } = props, { root, encounter, time } = useSite(props);
  const bell = useRef<Group>(null!), flies = useRef<(Group | null)[]>([]), cores = useRef<(Mesh | null)[]>([]);
  const fallback = useCanvasSheet(createArchFallbackCanvas), chime = useCanvasSheet(createChimeCanvas);
  const groundedArch = useMemo(() => {
    // Twenty vertical rows place one row exactly at the measured .95 foot anchor.
    const geometry = new PlaneGeometry(archComposition.w, archComposition.h, 10, 20);
    const positions = geometry.attributes.position;
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i), y = positions.getY(i);
      const height = y + archComposition.h * (archComposition.foot - .5);
      const delta = archGroundOffset(archComposition.x + x, height);
      // Convert pure world-Z settlement into the billboard's local basis.
      // The rotated Y components cancel, so this never slides the painted foot along the bank.
      positions.setXYZ(i, x, y + delta * Math.sin(BILLBOARD_TILT), delta * Math.cos(BILLBOARD_TILT));
    }
    positions.needsUpdate = true; return geometry;
  }, []);
  useEffect(() => () => groundedArch.dispose(), [groundedArch]);
  const revealed = archReveal(actor);
  useFrame(() => {
    const alpha = archReveal(!reading && motion ? motion.current.actor : actor);
    root.current.visible = alpha > .005;
    if (reading || !root.current.visible) return;
    revealPaint(root.current, alpha);
    const t = clock?.current ?? time.current, wind = gardenWind(t, site.x, site.y, .5);
    if (bell.current) bell.current.rotation.z = chimeResponse(t, encounter.current.age, wind.lean);
    flies.current.forEach((fly, i) => {
      if (!fly) return;
      const p = archMotePose(t, i, encounter.current.age);
      fly.position.set(p.x - site.x, p.y - site.y, terrainHeight(p.x, p.y) - terrainHeight(site.x, site.y) + p.z);
      opacity(cores.current[i], p.opacity * alpha);
    });
  });
  return <group ref={root} position={[site.x, site.y, terrainHeight(site.x, site.y) + 3]} name="atlas-old-arch" visible={revealed > .005}>
    {textures.contact && [-1, 1].map(side => <mesh key={side} position={[side * archComposition.w * .33, 0, terrainHeight(site.x + side * archComposition.w * .33, site.y) - terrainHeight(site.x, site.y)]}>
      <planeGeometry args={[100, 55]}/><meshBasicMaterial map={textures.contact} color="#596b77" transparent opacity={.22 * revealed} userData={{ baseOpacity: .22 }} depthWrite={false} toneMapped={false}/>
    </mesh>)}
    <group rotation={[BILLBOARD_TILT, 0, 0]}>
      <mesh geometry={groundedArch} position={[0, archComposition.h * (archComposition.foot - .5), 0]}>
        <meshBasicMaterial map={textures.archPaint ?? fallback} transparent opacity={revealed} userData={{ baseOpacity: 1 }} alphaTest={.015} depthWrite={false} side={DoubleSide} toneMapped={false}/>
      </mesh>
      <group ref={bell} position={[0, archComposition.chimeHeight, 4]}>
        <mesh position={[0, -archComposition.chimeH * (.5 - archComposition.chimeTop), 0]}>
          <planeGeometry args={[archComposition.chimeW, archComposition.chimeH]}/><meshBasicMaterial map={chime} transparent opacity={.94 * revealed} userData={{ baseOpacity: .94 }} depthWrite={false} side={DoubleSide} toneMapped={false}/>
        </mesh>
      </group>
    </group>
    {archMotes.map((mote, i) => <group key={i} ref={node => { flies.current[i] = node; }} position={[mote.x - site.x, mote.y - site.y, terrainHeight(mote.x, mote.y) - terrainHeight(site.x, site.y) + mote.z]}>
      <group rotation={[BILLBOARD_TILT, 0, 0]}><mesh ref={node => { cores.current[i] = node; }}>
        <circleGeometry args={[mote.size * .5, 12]}/><meshBasicMaterial color="#fff0d2" transparent opacity={.35 * revealed} depthWrite={false} toneMapped={false}/>
      </mesh></group>
    </group>)}
  </group>;
}

const createBirdBody = () => createPaperBirdCanvas('body');
const createBirdLeftWing = () => createPaperBirdCanvas('leftWing');
const createBirdRightWing = () => createPaperBirdCanvas('rightWing');

function Hill(props: SiteProps) {
  const { site, textures, reading, actor, motion, clock } = props, { root, encounter, time } = useSite(props);
  const birds = useRef<(Group | null)[]>([]), rolls = useRef<(Group | null)[]>([]);
  const leftWings = useRef<(Group | null)[]>([]), rightWings = useRef<(Group | null)[]>([]), shadows = useRef<(Mesh | null)[]>([]);
  const body = useCanvasSheet(createBirdBody), left = useCanvasSheet(createBirdLeftWing), right = useCanvasSheet(createBirdRightWing);
  const flightAge = useRef(100), seen = useRef(0), revealed = hillReveal(actor), base = terrainHeight(site.x, site.y);
  useFrame((_state, delta) => {
    const alpha = hillReveal(!reading && motion ? motion.current.actor : actor);
    root.current.visible = alpha > .005;
    if (reading) return;
    // Finish a flight even outside the camera. A repeated click cannot reset airborne birds.
    flightAge.current = advanceBirdFlight(flightAge.current, delta, encounter.current.activations > seen.current);
    seen.current = encounter.current.activations;
    if (!root.current.visible) return;
    revealPaint(root.current, alpha);
    const t = clock?.current ?? time.current;
    hillBirds.forEach((perch, i) => {
      const wind = gardenWind(t, perch.x, perch.y, perch.phase);
      const pose = paperBirdPose(flightAge.current, i, t, wind.lean), bird = birds.current[i];
      if (bird) bird.position.set(pose.x - site.x, pose.y - site.y, terrainHeight(pose.x, pose.y) - base + pose.lift);
      if (rolls.current[i]) rolls.current[i]!.rotation.z = pose.bank;
      if (leftWings.current[i]) leftWings.current[i]!.rotation.y = pose.wingAngle;
      if (rightWings.current[i]) rightWings.current[i]!.rotation.y = -pose.wingAngle;
      const shadow = shadows.current[i];
      if (shadow) {
        shadow.position.set(pose.x - site.x, pose.y - site.y, terrainHeight(pose.x, pose.y) - base + .2);
        shadow.scale.set(1 + (pose.lift - 4) * .002, 1 + (pose.lift - 4) * .003, 1);
        opacity(shadow, .16 * Math.max(.12, 1 - pose.lift / 260) * alpha);
      }
    });
  });
  return <group ref={root} position={[site.x, site.y, base + 3]} name="atlas-paperbird-hill" visible={revealed > .005}>
    {hillBirds.map((bird, i) => <group key={i}>
      {textures.contact && <mesh ref={node => { shadows.current[i] = node; }} position={[bird.x - site.x, bird.y - site.y, terrainHeight(bird.x, bird.y) - base + .2]}>
        <planeGeometry args={[bird.w * .65, 22]}/><meshBasicMaterial map={textures.contact} color="#687b7c" transparent opacity={.16 * revealed} depthWrite={false} toneMapped={false}/>
      </mesh>}
      <group ref={node => { birds.current[i] = node; }} position={[bird.x - site.x, bird.y - site.y, terrainHeight(bird.x, bird.y) - base + 4]}>
        <group rotation={[BILLBOARD_TILT, 0, 0]}><group ref={node => { rolls.current[i] = node; }} scale={[bird.flip ? -1 : 1, 1, 1]}>
          {/* Both wings hinge at the same painted shoulder; the resting foot is the origin. */}
          {[-1, 1].map(side => <group key={side} ref={node => { (side < 0 ? leftWings : rightWings).current[i] = node; }} position={[0, bird.h * (bird.foot - 126 / 224), 0]}>
            <mesh position={[0, bird.h * (126 / 224 - .5), 0]}>
              <planeGeometry args={[bird.w, bird.h]}/><meshBasicMaterial map={side < 0 ? left : right} transparent opacity={revealed} userData={{ baseOpacity: 1 }} alphaTest={.01} depthWrite={false} side={DoubleSide} toneMapped={false}/>
            </mesh>
          </group>)}
          <mesh position={[0, bird.h * (bird.foot - .5), .2]}>
            <planeGeometry args={[bird.w, bird.h]}/><meshBasicMaterial map={body} transparent opacity={revealed} userData={{ baseOpacity: 1 }} alphaTest={.01} depthWrite={false} side={DoubleSide} toneMapped={false}/>
          </mesh>
        </group></group>
      </group>
    </group>)}
  </group>;
}

function Moon(props: SiteProps) {
  const { site, reading, actor, motion, clock, memories } = props, { root, encounter, time } = useSite(props);
  const flies = useRef<(Group | null)[]>([]), cores = useRef<(Mesh | null)[]>([]), groundLight = useRef<MeshBasicMaterial>(null!);
  const groundPaint = useCanvasSheet(createMoonGroundCanvas), moonPaint = useCanvasSheet(createPaperMoonCanvas);
  const revealed = moonReveal(actor), base = terrainHeight(site.x, site.y);
  const geometry = useMemo(() => {
    const surface = new PlaneGeometry(moonGround.w, moonGround.h, 18, 24), positions = surface.attributes.position;
    for (let i = 0; i < positions.count; i++) positions.setZ(i, terrainHeight(moonGround.x + positions.getX(i), moonGround.y + positions.getY(i)) - base + .4);
    positions.needsUpdate = true; return surface;
  }, [base]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  useFrame(() => {
    const alpha = moonReveal(!reading && motion ? motion.current.actor : actor);
    root.current.visible = alpha > .005;
    if (reading || !root.current.visible) return;
    revealPaint(root.current, alpha);
    const t = clock?.current ?? time.current;
    const awake = !!memories?.includes(site.event) || encounter.current.activations > 0;
    if (groundLight.current) groundLight.current.opacity = moonLightResponse(encounter.current.age, awake) * alpha;
    flies.current.forEach((fly, i) => {
      if (!fly) return;
      const pose = moonMotePose(t, i, encounter.current.age);
      fly.position.set(pose.x - site.x, pose.y - site.y, terrainHeight(pose.x, pose.y) - base + pose.z);
      opacity(cores.current[i], pose.opacity * alpha);
    });
  });
  return <group ref={root} position={[site.x, site.y, base + 3]} name="atlas-moon-clearing" visible={revealed > .005}>
    <mesh geometry={geometry} position={[moonGround.x - site.x, moonGround.y - site.y, 0]} renderOrder={-2}>
      <meshBasicMaterial ref={groundLight} map={groundPaint} transparent opacity={moonLightResponse(100, !!memories?.includes(site.event)) * revealed} depthWrite={false} alphaTest={.001} side={DoubleSide} toneMapped={false}/>
    </mesh>
    <group position={[moonOrb.x - site.x, moonOrb.y - site.y, terrainHeight(moonOrb.x, moonOrb.y) - base + moonOrb.lift]} rotation={[BILLBOARD_TILT, 0, 0]}>
      <mesh><planeGeometry args={[moonOrb.w, moonOrb.h]}/><meshBasicMaterial map={moonPaint} transparent opacity={.82 * revealed} userData={{ baseOpacity: .82 }} depthWrite={false} side={DoubleSide} toneMapped={false}/></mesh>
    </group>
    {moonMotes.map((mote, i) => <group key={i} ref={node => { flies.current[i] = node; }} position={[mote.x - site.x, mote.y - site.y, terrainHeight(mote.x, mote.y) - base + mote.z]}>
      <group rotation={[BILLBOARD_TILT, 0, 0]}><mesh ref={node => { cores.current[i] = node; }}>
        <circleGeometry args={[mote.size * .5, 12]}/><meshBasicMaterial color="#f4ead3" transparent opacity={.35 * revealed} depthWrite={false} toneMapped={false}/>
      </mesh></group>
    </group>)}
  </group>;
}

/** Six fixed landmarks share the atlas controller without introducing interface elements. */
export function AtlasEncounters(props: Props) {
  return <>{atlasEncounterSites.map(site => {
    const Component = { orchard: Orchard, pond: Pond, hollow: Hollow, arch: Arch, hill: Hill, moon: Moon }[site.id];
    return <Component key={site.id} {...props} site={site}/>;
  })}</>;
}
