import { cp, mkdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('..', import.meta.url));
const output = path.join(root, 'releases/desktop-preview');
const marker = path.join(output, 'package-info.json');
const kind = 'birthday-garden-desktop-preview';
await stat(path.join(root, 'dist/index.html'));
try {
  await stat(output);
  const existing = JSON.parse(await readFile(marker, 'utf8'));
  if (existing.kind !== kind) throw new Error('The release folder is not a generated garden package.');
  await rm(output, { recursive: true });
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
  // An existing folder without our marker is never replaced.
  try { await stat(output); throw new Error('Release folder has no generated-package marker.'); }
  catch (missing) { if (missing.code !== 'ENOENT') throw missing; }
}
await mkdir(path.join(output, 'scripts'), { recursive: true });
await cp(path.join(root, 'dist'), path.join(output, 'dist'), { recursive: true });
await cp(path.join(root, 'scripts/serve-dist.mjs'), path.join(output, 'scripts/serve-dist.mjs'));
await cp(path.join(root, 'docs/LOCAL_PREVIEW.md'), path.join(output, 'LOCAL_PREVIEW.md'));
const contentBytes = await readFile(path.join(root, 'src/config/content.json'));
const content = JSON.parse(contentBytes);
const info = {
  kind, builtAt: new Date().toISOString(), contentSha256: createHash('sha256').update(contentBytes).digest('hex'),
  status: 'Desktop rehearsal build; see pending content below. Not a final gift delivery.',
  pendingSongIds: content.music.songs.filter(song => song.placeholder).map(song => song.id),
  giftPlaceholder: content.gift.placeholder,
  giftName: content.gift.name,
  giftReasonProvided: !!content.gift.reason.trim(), giftPhotoProvided: !!content.gift.imageSrc,
  recipientNamePending: !content.people.recipientName.trim(), senderNamePending: !content.people.senderName.trim(),
  note: 'Original references, development source, dependencies and QA records are not included. The complete built local assets are retained.',
};
await writeFile(marker, `${JSON.stringify(info, null, 2)}\n`);
await writeFile(path.join(output, 'START_HERE.txt'), `生日花园 · 桌面本地彩排包\n\n${info.giftPlaceholder ? '此包仍含待填曲目和礼物名称。' : '礼物名称已确认，曲目与个人文字仍待补充。'}这不是最终赠送版。\n\n安装好 Node.js 22.12+ 或 24 后，在此目录打开终端：\n\n  node scripts/serve-dist.mjs\n\n浏览器打开 http://127.0.0.1:4173/ ，保持终端运行。\n不需要 npm install，不需要外网；不要直接双击 dist/index.html。\nCtrl+C 停止服务。默认只监听本机，不会发布到互联网。\n\n完整步骤见 LOCAL_PREVIEW.md。若已有服务占用 4173，本包会明确报错，\n不会悄悄换端口；也可明确指定 --port 4181。\n\n本站不是离线 PWA；需本地服务保持运行。\n`);
console.log(`Local desktop package: ${output}`);
console.log(`Pending song titles: ${info.pendingSongIds.join(', ')}; gift placeholder: ${info.giftPlaceholder}`);
