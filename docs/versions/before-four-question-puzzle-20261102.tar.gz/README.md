# 秘密花园生日网站 · A 方案

当前完成 **M0、M1 桌面美术样片、M2 信号谜题、M3 音乐抽取和 M4 礼物解锁／揭晓功能**，并完成 M5 桌面技术彩排与本地备用包。采用用户确认的俯视水粉草坡、独立叶片和奶白绒团；礼物已确认为护照夹和睡眠眼罩，揭晓页英文名称为 `A passport holder & a sleep mask`；九首真实曲名仍待提供，尚非正式赠送版本。原始交接包、参考图片与视频、历史素材全部保留。网站工程位于当前项目根目录。

## 打开预览

- 花园：[http://localhost:5173/#garden](http://localhost:5173/#garden)
- 直接体验第一关：[http://localhost:5173/#puzzle](http://localhost:5173/#puzzle)
- 音乐花圃：[http://localhost:5173/#music](http://localhost:5173/#music)
- 礼物门：[http://localhost:5173/#lock](http://localhost:5173/#lock)；已解锁重看：[http://localhost:5173/#gift](http://localhost:5173/#gift)

本机服务未运行时，在项目目录执行：

```sh
sh scripts/project.sh dev
```

保持服务终端运行；本机重启后需重新启动。这是本地预览，尚未部署。

电脑上移动鼠标／触摸板指针即可引导绒团，无须按住；方向键、WASD 和滚轮也可行走。停下等待、靠近花灯、点击打开内容。阅读期间角色与环境暂停，关闭后恢复角色、镜头、朝向和缩放。声音默认关闭，可主动开启；减少动态使用静态画面与相同内容控件。

最新修正：在同帧驱动基础上增加连续转向和有限停步曲线，让角色与镜头一起收势；原停步时限不延长。用户已确认上一版连续行走顺滑，本轮转向与停步手感仍待复测。9 项转向／停步检查、26 项指针检查、7 项身体检查、类型检查和构建通过，见 [TURN_STOP_QA.md](docs/TURN_STOP_QA.md)。已有页面请刷新以加载 `soft-turn-stop-v3`；上一轮帧同步记录见 [SMOOTH_MOTION_QA.md](docs/SMOOTH_MOTION_QA.md)。

## 本轮 M5 桌面技术彩排

发布包从空进度走通解谜 → 抽曲 → 开门 → 返回，刷新保留结果，跨面板精确恢复位置。补上地面／叶片加载失败替代，拆开静态画面对 Three 的依赖，实际删除图形包的构建副本仍可抽曲与返回。125 项回归、类型检查和构建通过。原美术与运动参数保持。

本地备用包在 `releases/desktop-preview/`（[压缩包](releases/birthday-garden-desktop-preview-20261102.tar.gz)），无需 node_modules，需已安装 Node；解压归档后按 START_HERE.txt 启动。本轮没有发布公网链接。使用方法见 [LOCAL_PREVIEW.md](docs/LOCAL_PREVIEW.md)，礼物和曲目待填位置见 [CONTENT_HANDOFF.md](docs/CONTENT_HANDOFF.md)。

真实截图、采样范围与限制见 [M5_DESKTOP_QA.md](docs/M5_DESKTOP_QA.md)。真实内容、实体触摸板／声音、自然行走探索节奏与现场断网尚待验收，因此不将 M5 整体或正式赠送版本标为完成。

## 已完成 M4

- 单个文本框保留前导零，支持完整粘贴和 Enter。`0305` 开门；`305` 和错误四位不通过，错误保留输入、不限制次数。
- 正确后先保存解锁，再播放 900ms 局部开门反馈。静态／减少动态流程可用；动画中刷新仍已解锁，切页和关闭会取消旧回调。
- 未解锁访问 `#gift` 会回到锁页；生日含义仅在门内显示。直接输入密码只解锁礼物，不完成谜题、不生成密码卡或曲目。
- 揭晓页保留现场交付停顿，提供返回音乐和花园入口；关闭恢复原位置。已解锁者从顶部 `Your gift` 或音乐页直接重看。
- 礼物名称已接入 `A passport holder & a sleep mask`，名称占位标记已关闭；送礼理由、照片和称呼可后补。没有照片时保留中性礼物图示，空理由和称呼不展示。未接入私人音频。

桌面实际检查错误输入、动画中刷新、揭晓刷新、回看密码卡、跨面板返回、历史前进后退、空进度减少动态解锁及焦点循环。23 项礼物检查、49 项谜题／音乐回归、内容校验、类型与构建通过；Three 分包体积提示仍存在。截图与限制见 [M4_GIFT_QA.md](docs/M4_GIFT_QA.md)。

## 已完成 M3 功能

- 九朵花固定编号 01–09；碰触单朵花只作回应，点击抽取按钮才会选歌。
- 每次从九首中独立等权、有放回抽取，允许连续抽到同一首。结果先保存，再播放短暂花朵反馈；刷新、切页或关闭面板不会重抽。
- 曲目卡提供复制点歌文字和手动选择文字；不会替用户发送消息。复制成功后才显示确认，失败则提供可选中的原文。
- 可直接进入音乐页，无须解谜；关闭后恢复原来的角色、镜头、朝向和缩放。音乐不改变谜题或礼物进度。
- 真实曲名尚未收到，暂时明确标为 `Piece N (to be added)`；可选理由为空时省略，不虚构音频或播放器。

桌面 1280×720 已实际检查双击防重复、动画中刷新恢复、复制成功反馈、手动选择文字、切页返回、静态模式与键盘焦点。31 项音乐检查、18 项谜题回归、配置校验、类型检查和生产构建通过。证据和检查范围见 [M3_MUSIC_QA.md](docs/M3_MUSIC_QA.md)。

## 已完成 M2

- 信号 A、B 依次解码。四个输出初始为空，验证灯位后才进入数字输入；错误保留答案。
- 一组完成保存两位片段；两组都完成才出现密码卡和顶部 `My password card`。
- 提示逐层展开。完整示范需要主动选择，再明确确认才能替当前组完成，不会自动填写另一组。
- 保存填写中的灯位、数字和完成状态。刷新继续；存储不可用时可在当前页面内完成。
- 音乐过场为可选内容；谜题、音乐、礼物状态互相独立。页面文案和无障碍标签为英文。
- 原美术、地点、环境反馈及固定谜题规则保持。音乐抽取和礼物揭晓已接入；真实内容待填。

检查记录和真实截图见 [M2_SIGNAL_QA.md](docs/M2_SIGNAL_QA.md)。桌面浏览器实际走通两组谜题、提示、刷新恢复、静态替代、键盘焦点、关闭与历史导航；18 项谜题/存储检查、22 项指针回归、配置检查、类型检查和生产构建通过。Three 分包仍有体积提示。

本轮没有重新验证实体触摸板手感、音频听感、FPS、手机或部署，也没有重新宣称整段自然行走节奏达标。M1 自然行走和返程的历史证据见 [FLOOF_CLEARING_QA.md](docs/FLOOF_CLEARING_QA.md)；背景方向获认可不代表整个美术已最终验收。

## 检查、构建与安装

```sh
sh scripts/project.sh check
sh scripts/project.sh build
sh scripts/project.sh preview
```

`preview` 提供已构建版本，默认 http://127.0.0.1:4173/。不要直接双击 dist/index.html。

本机使用 Node **24.22.1**、pnpm **11.25.0**。React 19、TypeScript、Vite、React Three Fiber、Three.js、GSAP 的精确版本以 pnpm-lock.yaml 为准。另一个常规 Node 22.12+ 或 24 环境可运行：

```sh
pnpm install --frozen-lockfile
pnpm dev
```

本机没有全局 Node，project.sh 自动寻找 Codex 运行时，并跳过不能加载第三方原生模块的 cua_node。直接运行确定性检查使用本机 Node 24 路径：

```sh
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/check-puzzle-progress.mjs
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/check-music-progress.mjs
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/check-song-draw.mjs
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/check-music-copy.mjs
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/check-gift-progress.mjs
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/check-gift-unlock.mjs
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/check-content.mjs
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/check-pointer-guidance.mjs
```

需要重新安装依赖时：

```sh
PATH="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:$PATH" \
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback/pnpm" install --frozen-lockfile --store-dir .pnpm-store
```

## 文件与内容

- 运行时内容与校验：src/config/content.json、content.ts；原交接模板不作为第二份运行时配置。
- 谜题界面：src/ui/SignalPuzzle.tsx、src/styles/puzzle.css。
- 音乐界面／抽取：src/ui/MusicGarden.tsx、src/styles/music.css、src/lib/draw.ts、src/motion/useSongDraw.ts。
- 礼物门／揭晓：src/ui/GiftDoor.tsx、src/styles/gift.css、src/lib/gift.ts、src/motion/useGiftUnlock.ts。
- 业务状态／计算／存储：src/state/experience.ts、useProgress.ts、src/lib/puzzle.ts、storage.ts。
- 当前美术：src/scene/FloofTerrain.tsx、FloofScenery.tsx、RabbitCompanion.tsx、FloofStatic.tsx；本地素材 public/art/floof/。
- 当前角色输入：src/motion/useMeadowJourney.ts、src/scene/pointerGuidance.ts。
- 章节导航与原位置恢复：src/App.tsx；导航历史不写入业务存储。
- 本地 Cormorant Garamond 字体附 SIL OFL 许可，是文学气质的授权替代，不声称是 Wayfinder 原字体。

保存仅使用本应用专用键 `birthday-gift:0305:v1`。开发者确需重置测试数据时，只删除这一键，绝不调用 localStorage.clear()。界面没有清空用户进度按钮。前端密码属于揭晓机关，不是身份认证。

已接入礼物名称：护照夹和睡眠眼罩。待用户提供：九首真实曲名、可选曲目理由、可选送礼理由与照片、称呼和署名。私人语音／演奏未提供时保持 null，不虚构内容或播放器。

## 后续与历史

下一阶段补齐九首曲名与称呼，按需补充礼物说明／照片，并在展示设备验收触摸板手感、声音和自然探索节奏；手机仍按用户要求暂缓。深处区域尚未按当前美术完整重做或验收。

- [M5 技术彩排与本地备用](docs/M5_DESKTOP_QA.md)
- [阶段进度与全部历史](docs/PROGRESS.md)
- [移动顺滑度修正与测量](docs/SMOOTH_MOTION_QA.md)
- [转向与停步修正](docs/TURN_STOP_QA.md)
- [M2 检查](docs/M2_SIGNAL_QA.md)
- [M3 检查与截图](docs/M3_MUSIC_QA.md)
- [M4 检查与截图](docs/M4_GIFT_QA.md)
- [当前美术方向检查](docs/FLOOF_CLEARING_QA.md)
- [本轮前 README，保留历史实现说明](docs/versions/README-before-m2-20261101.md)
- M4 前备份：docs/versions/before-m4-20261102.tar.gz；M3、M2 前备份继续保留。
- 原始计划：birthday-site-handoff/docs/DEVELOPMENT_PLAN.md；原始文档与 reference 未改。
