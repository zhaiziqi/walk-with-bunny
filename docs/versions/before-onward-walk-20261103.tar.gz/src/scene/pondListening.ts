import { pondDriftPetals, pondFootprint } from './orchardPond';

type Point = { x: number; y: number };
export type PondRipple = Point & { age: number; strength: number; rotation: number };
type PetalOffset = Point & { rotation: number };
export type PondListeningState = {
  actor: Point; source: Point; speed: number; engaged: boolean; discovered: boolean;
  quiet: number; time: number; calm: number; presence: number; travel: number; lastEmit: number; serial: number;
  ripples: PondRipple[]; petals: PetalOffset[];
};
export type PondListeningRef = { current: PondListeningState | null };
const clamp = (n: number) => Math.max(0, Math.min(1, n));
const smooth = (n: number) => { const t = clamp(n); return t * t * (3 - 2 * t); };
const ease = (a: number, b: number, dt: number, seconds: number) => a + (b - a) * (1 - Math.exp(-dt / seconds));
const distance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y);
const waveLifetime = 4.2;

/** Closest point on the painted ellipse, slightly inset so a greeting belongs to
 * the water. The companion remains outside the larger walkable-bank ellipse. */
export function pondShoreContact(actor: Point) {
  const { x: cx, y: cy, waterRadiusX: a, waterRadiusY: b } = pondFootprint;
  const dx = actor.x - cx, dy = actor.y - cy;
  let ex: number, ey: number;
  if ((dx / a) ** 2 + (dy / b) ** 2 >= 1) {
    // For an exterior point the Lagrange multiplier is non-negative. Unlike a
    // radial clamp this follows the closest bank naturally around oblique shores.
    let low = 0, high = Math.max(a * Math.abs(dx) + b * Math.abs(dy), 1);
    for (let i = 0; i < 30; i++) {
      const lambda = (low + high) / 2;
      const x = a * dx / (a * a + lambda), y = b * dy / (b * b + lambda);
      if (x * x + y * y > 1) low = lambda; else high = lambda;
    }
    ex = a * a * dx / (a * a + high); ey = b * b * dy / (b * b + high);
  } else {
    // An old or invalid submerged pose gets a finite deterministic bank; this
    // does not alter the existing walkability constraint or move the companion.
    const angle = dx || dy ? Math.atan2(dy / b, dx / a) : -Math.PI / 2;
    ex = a * Math.cos(angle); ey = b * Math.sin(angle);
  }
  return { x: cx + ex * .82, y: cy + ey * .82,
    distance: Math.hypot(dx - ex, dy - ey), bankX: cx + ex, bankY: cy + ey };
}

export function createPondListening(actor: Point, discovered = false): PondListeningState {
  const contact = pondShoreContact(actor);
  return { actor: { ...actor }, source: { x: contact.x, y: contact.y }, speed: 0,
    engaged: false, discovered, quiet: 0, time: 0, calm: 1, presence: 0, travel: 0, lastEmit: -10, serial: 0,
    ripples: Array.from({ length: 4 }, () => ({ x: contact.x, y: contact.y, age: waveLifetime, strength: 0, rotation: 0 })),
    petals: pondDriftPetals.map(() => ({ x: 0, y: 0, rotation: 0 })) };
}

/** Reading is a hard pause. Real passage gives a small local wake, never a cursor
 * trail or a timed repeating show. Water and petals keep settling off screen. */
export function advancePondListening(state: PondListeningState, actor: Point, delta: number, options: { paused?: boolean; speed?: number } = {}): PondListeningState {
  if (options.paused || !Number.isFinite(delta) || delta <= 0 || !Number.isFinite(actor.x) || !Number.isFinite(actor.y)) return state;
  const step = distance(actor, state.actor);
  if (step > 80) return { ...state, actor: { ...actor }, speed: 0, engaged: false, quiet: 0, travel: 0 };
  if (delta > .25) return { ...state, actor: { ...actor } };
  const dt = Math.min(.05, delta), realStep = step > .015;
  const sample = Number.isFinite(options.speed) ? Math.max(0, options.speed!) : step / delta;
  const speed = ease(state.speed, sample, dt, .24), time = state.time + dt;
  const contact = pondShoreContact(actor), near = contact.distance < (state.engaged ? 240 : 185);
  const engaged = near && (state.engaged || realStep);
  const presenceTarget = engaged ? smooth((240 - contact.distance) / 180) : 0;
  const presence = ease(state.presence ?? 0, presenceTarget, dt, presenceTarget > (state.presence ?? 0) ? .5 : .9);
  const quiet = engaged && speed < 24 ? Math.min(12, state.quiet + dt) : 0;
  const calmTarget = engaged ? smooth((quiet - .3) / 3) : 1;
  const calm = ease(state.calm, calmTarget, dt, calmTarget > state.calm ? .65 : .30);
  const source = { x: ease(state.source.x, contact.x, dt, .22), y: ease(state.source.y, contact.y, dt, .22) };
  const ripples = state.ripples.map(ripple => ({ ...ripple, age: Math.min(waveLifetime, ripple.age + dt) }));
  let travel = engaged && realStep && speed > 14 ? Math.min(170, state.travel + step) : engaged ? state.travel : 0;
  let { lastEmit, serial } = state;
  const newlyApproached = engaged && !state.engaged;
  const wantsWave = engaged && realStep && (newlyApproached || speed > 14 && travel >= 85) && time - lastEmit >= .7;
  if (wantsWave) {
    // Never overwrite a visible wave when all four slots are still in use.
    const free = ripples.findIndex(ripple => ripple.age >= waveLifetime);
    if (free >= 0) {
      serial++; lastEmit = time; travel = 0;
      ripples[free] = { x: contact.x, y: contact.y, age: 0,
        strength: (.32 + .60 * presence) * (.65 + .35 * smooth(speed / 170)), rotation: serial * .61 };
    }
  }
  const current = presence * smooth(speed / 125);
  const petals = state.petals.map((previous, index) => {
    const home = pondDriftPetals[index], gap = distance(home, source);
    const local = smooth((290 - gap) / 220) * current;
    const dx = (home.x - source.x) / Math.max(1, gap), dy = (home.y - source.y) / Math.max(1, gap);
    return { x: ease(previous.x, dx * local * 27, dt, .85),
      y: ease(previous.y, dy * local * 21, dt, .85),
      rotation: ease(previous.rotation, dx * local * .20, dt, 1.2) };
  });
  return { actor: { ...actor }, source, speed, engaged, discovered: state.discovered || engaged,
    quiet, time, calm, presence, travel, lastEmit, serial, ripples, petals };
}

/** Switching renderers preserves the same still-water encounter. Rebasing input
 * prevents a fake step; only relocating to another place cancels its engagement. */
export function resumePondListening(state: PondListeningState, actor: Point): PondListeningState {
  const relocated = distance(state.actor, actor) > 80;
  return { ...state, actor: { ...actor }, speed: 0,
    engaged: relocated ? false : state.engaged,
    quiet: relocated ? 0 : state.quiet, travel: relocated ? 0 : state.travel };
}

export function pondRipplePose(ripple: PondRipple) {
  const p = clamp(ripple.age / waveLifetime);
  return { radiusX: 12 + p * 140, radiusY: 9 + p * 95,
    opacity: smooth(p / .12) * (1 - smooth((p - .28) / .72)) * ripple.strength * .42,
    rotation: ripple.rotation };
}

/** Only the original three petals move, a few world units with the common wind.
 * Reduced motion passes time/lean zero; no state is advanced by drawing. */
export function pondPetalPose(state: PondListeningState | null, index: number, time: number, windLean = 0) {
  const home = pondDriftPetals[index], offset = state?.petals[index] ?? { x: 0, y: 0, rotation: 0 };
  const t = Number.isFinite(time) ? time : 0, wind = Number.isFinite(windLean) ? Math.max(-1, Math.min(1, windLean)) : 0;
  return { x: home.x + offset.x + Math.sin(t * .13 + index * 2) * 2.5 * wind,
    y: home.y + offset.y + Math.sin(t * .10 + index) * 1.7 * wind,
    rotation: home.rotation + offset.rotation + Math.sin(t * .18 + index) * .055 * wind };
}

/** Read-only observations shared by both renderers; never used to drive input. */
export function inspectPondListening(state: PondListeningState) {
  return { engaged: state.engaged, discovered: state.discovered,
    quiet: +state.quiet.toFixed(2), calm: +state.calm.toFixed(3), presence: +state.presence.toFixed(3), serial: state.serial,
    source: { x: +state.source.x.toFixed(2), y: +state.source.y.toFixed(2) },
    ripples: state.ripples.map(r => ({ x: +r.x.toFixed(2), y: +r.y.toFixed(2), age: +r.age.toFixed(2), opacity: +pondRipplePose(r).opacity.toFixed(3) })),
    petals: pondDriftPetals.map((_p, i) => { const p = pondPetalPose(state, i, 0); return { x: +p.x.toFixed(2), y: +p.y.toFixed(2) }; }) };
}
