import { hollowMushrooms } from './hollowArch';

type Point = { x: number; y: number };
type Mushroom = { warmth: number; lean: number };
export type MushroomListening = {
  actor: Point; speed: number; resting: boolean; quiet: number;
  focus: number; engaged: boolean; discovered: boolean; replaySerial: number;
  mushrooms: Mushroom[];
};
const clamp = (n: number) => Math.max(0, Math.min(1, n));
const smooth = (n: number) => { const p = clamp(n); return p * p * (3 - 2 * p); };
const ease = (from: number, to: number, dt: number, seconds: number) => from + (to - from) * (1 - Math.exp(-dt / seconds));
const distance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y);

export function createMushroomListening(actor: Point, discovered = false, replaySerial = -1): MushroomListening {
  return { actor: { ...actor }, speed: 0, resting: true, quiet: 12, focus: -1, engaged: false, discovered, replaySerial,
    mushrooms: hollowMushrooms.map(() => ({ warmth: 0, lean: 0 })) };
}

/** A planted response to the companion, independent of pointer events and business progress.
 * Short real steps engage the patch. Stillness spreads one finite response from the nearest
 * cap. Moving transfers attention without resetting any cap's pose; leaving softly releases it.
 */
export function advanceMushroomListening(state: MushroomListening, actor: Point, delta: number, options: {
  paused?: boolean; speed?: number; replaySerial?: number;
} = {}): MushroomListening {
  if (options.paused || !Number.isFinite(delta) || delta <= 0 || !Number.isFinite(actor.x) || !Number.isFinite(actor.y)) return state;
  const dt = Math.min(delta, .05), step = distance(actor, state.actor);
  const discontinuity = step > 80;
  // A stalled frame is not a departure. Rebase the sample but preserve the response;
  // unlike a real map jump, it must not require another movement to wake up again.
  if (delta > .25 && !discontinuity) return { ...state, actor: { ...actor } };
  const distances = hollowMushrooms.map(mushroom => distance(actor, mushroom));
  const closest = distances.indexOf(Math.min(...distances));
  // A generous edge fades the response before the site is culled; there is no hard glowing ring.
  const near = distance(actor, { x: 1400, y: 4300 }) < (state.engaged ? 440 : 370) && distances[closest] < 285;
  const serial = options.replaySerial ?? state.replaySerial;
  const manual = !discontinuity && near && serial !== state.replaySerial;
  const realStep = !discontinuity && step > .015;
  const engaged = !discontinuity && near && (state.engaged || realStep || manual);
  const measuredSpeed = discontinuity ? 0 : Math.max(0, Number.isFinite(options.speed) ? options.speed! : step / delta);
  const speed = ease(state.speed, measuredSpeed, dt, .22);
  // Hysteresis tolerates tiny trackpad corrections and the controller's braking tail.
  const resting = state.resting ? speed < 38 : speed < 20;
  let quiet = engaged ? (resting ? Math.min(12, state.quiet + dt) : Math.max(0, state.quiet - dt * 12)) : 0;
  if (engaged && !state.engaged) quiet = 0;
  if (manual) quiet = .85;
  let focus = state.focus;
  // Crossing a bisector does not switch the lead mushroom back and forth every frame.
  if (focus < 0 || !state.engaged || distances[closest] + 35 < distances[focus]) focus = closest;
  const presence = engaged ? smooth((285 - distances[closest]) / 165) : 0;
  const settled = 1 - smooth((quiet - 6) / 3);
  const source = hollowMushrooms[focus];
  const mushrooms = state.mushrooms.map((previous, index) => {
    const mushroom = hollowMushrooms[index];
    const local = index === focus ? 1 : .13 * Math.exp(-(distances[index] - distances[closest]) / 70);
    const elapsed = quiet - .85 - distance(source, mushroom) / 105;
    const answer = smooth(elapsed / .9) * (1 - smooth((elapsed - 2.1) / 2.5));
    const greeting = .52 * local * (resting ? .12 + .88 * settled : 1);
    const target = presence * Math.max(greeting, resting ? .86 * answer : 0);
    const warmth = ease(previous.warmth, target, dt, target > previous.warmth ? .42 : 1.05);
    // Tilt toward the companion from the fixed foot. No vertical stretch or bouncing.
    const direction = Math.max(-1, Math.min(1, (actor.x - mushroom.x) / 125));
    const lean = ease(previous.lean, -direction * warmth * .052, dt, .55);
    return { warmth, lean };
  });
  return { actor: { ...actor }, speed, resting, quiet, focus, engaged,
    discovered: state.discovered || engaged, replaySerial: serial, mushrooms };
}

/** Rendering is deliberately small: common wind, a few degrees of acknowledgement, warm ground. */
export function listeningMushroomPose(state: MushroomListening, index: number, windLean = 0) {
  const mushroom = state.mushrooms[index];
  return { lean: windLean * .022 + mushroom.lean, stretch: 1, footOffset: 0,
    glow: .018 + mushroom.warmth * .30, warmth: mushroom.warmth };
}
