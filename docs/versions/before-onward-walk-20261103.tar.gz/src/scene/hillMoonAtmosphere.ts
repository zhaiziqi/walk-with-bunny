/** Shared late-garden washes: quiet paper beneath the birds, cooler pigment by the small door. */
export const hillMoonPalette = {
  hill: [.674, .658, .704], moon: [.488, .566, .688],
  hillStrength: .34, moonStrength: .40,
};
export type HillMoonField = { hill: number; moon: number; calm: number };
const smooth = (value: number) => {
  const t = Math.max(0, Math.min(1, value));
  return t * t * (3 - 2 * t);
};

/** Soft finite support leaves the earlier clearings untouched, with no hard colour boundary. */
export function hillMoonField(x: number, y: number): HillMoonField {
  if (!Number.isFinite(x) || !Number.isFinite(y)) return { hill: 0, moon: 0, calm: 0 };
  const wash = (cx: number, cy: number, rx: number, ry: number, falloff = 2) => {
    const radius2 = ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2;
    return Math.exp(-falloff * radius2) * (1 - smooth((Math.sqrt(radius2) - 1.3) / .5));
  };
  const hill = wash(1000, 6800, 900, 700);
  const moon = wash(-200, 8500, 1050, 800);
  // A slightly wider quiet layer keeps the tiny birds and doorway readable
  // while retaining the underlying broad grass colour and terrain shading.
  const hillQuiet = wash(1000, 6800, 900, 700, 1.25);
  const moonQuiet = wash(-200, 8500, 1050, 800, 1.25);
  const passage = wash(580, 7720, 800, 570);
  return { hill, moon, calm: Math.max(hillQuiet * .66, moonQuiet * .76, passage * .28) };
}

export function hillMoonTint(color: number[], field: HillMoonField) {
  return color.map((value, i) => {
    const hill = value + (hillMoonPalette.hill[i] - value) * field.hill * hillMoonPalette.hillStrength;
    return hill + (hillMoonPalette.moon[i] - hill) * field.moon * hillMoonPalette.moonStrength;
  });
}
