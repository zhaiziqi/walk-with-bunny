import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import { extname } from 'node:path';

registerHooks({ resolve(specifier, context, nextResolve) {
  return nextResolve(specifier.startsWith('.') && !extname(specifier) && context.parentURL?.includes('/src/')
    ? `${specifier}.ts` : specifier, context);
} });

const { createMushroomListening, advanceMushroomListening, listeningMushroomPose } = await import('../src/scene/mushroomListening.ts');
const { hollowMushrooms } = await import('../src/scene/hollowArch.ts');
const leftCap = { x: 1215, y: 4350 };
const rightCap = { x: 1625, y: 4435 };
let checks = 0, failures = 0;
const check = (name, run) => {
  checks++;
  try { run(); console.log(`PASS: ${name}`); }
  catch (error) { failures++; console.error(`FAIL: ${name}\n${error.stack}`); }
};
const peak = state => Math.max(...state.mushrooms.map(mushroom => mushroom.warmth));

function hold(state, seconds, { fps = 60, actor = state.actor, speed, observe, ...options } = {}) {
  const frames = Math.ceil(seconds * fps), dt = seconds / frames;
  for (let frame = 0; frame < frames; frame++) {
    const position = typeof actor === 'function' ? actor(frame, dt) : actor;
    state = advanceMushroomListening(state, position, dt, { speed, ...options });
    observe?.(state, frame, dt);
  }
  return state;
}

function walk(state, destination, { fps = 60, speed = 240, observe } = {}) {
  const origin = { ...state.actor }, distance = Math.hypot(destination.x - origin.x, destination.y - origin.y);
  const frames = Math.max(1, Math.ceil(distance / speed * fps)), dt = distance / speed / frames;
  for (let frame = 1; frame <= frames; frame++) {
    const amount = frame / frames;
    state = advanceMushroomListening(state, {
      x: origin.x + (destination.x - origin.x) * amount,
      y: origin.y + (destination.y - origin.y) * amount,
    }, dt, { speed });
    observe?.(state, frame, dt);
  }
  return state;
}

function approach(destination = leftCap, { fps = 60, discovered = false, side = -1 } = {}) {
  return walk(createMushroomListening({ x: destination.x + side * 420, y: destination.y }, discovered), destination, { fps });
}

check('a real approach greets the nearest cap on either side, rather than a fixed first index', () => {
  for (const [target, index, side] of [[leftCap, 0, -1], [rightCap, 4, 1]]) {
    const state = approach(target, { side });
    assert.equal(state.focus, index);
    assert.ok(state.engaged && state.discovered);
    assert.ok(state.mushrooms[index].warmth > .3);
    assert.ok(state.mushrooms.every((mushroom, i) => i === index || mushroom.warmth < .12));
  }
});

check('continued stillness spreads a visible response by spatial distance', () => {
  const arrival = approach(), firstResponse = Array(5).fill(Infinity);
  hold(arrival, 8, { observe(state, frame, dt) {
    state.mushrooms.forEach((mushroom, index) => {
      if (mushroom.warmth > .3 && !Number.isFinite(firstResponse[index])) firstResponse[index] = (frame + 1) * dt;
    });
  } });
  const spatialOrder = hollowMushrooms.map((mushroom, index) => ({ index, distance: Math.hypot(mushroom.x - leftCap.x, mushroom.y - leftCap.y) }))
    .sort((a, b) => a.distance - b.distance).map(item => item.index);
  assert.ok(firstResponse.every(Number.isFinite), 'all existing caps can answer during an unhurried visit');
  for (let index = 1; index < spatialOrder.length; index++) {
    assert.ok(firstResponse[spatialOrder[index]] > firstResponse[spatialOrder[index - 1]], 'further caps must answer later');
  }
  assert.ok(firstResponse[4] - firstResponse[0] > 3, 'the patch must not flash together');
});

check('tiny real-position corrections do not continually cancel stillness', () => {
  const arrival = approach(), calm = hold(arrival, 6);
  const jittered = hold(arrival, 6, {
    speed: undefined,
    actor: frame => ({ x: leftCap.x + Math.sin(frame * .8) * .05, y: leftCap.y + Math.cos(frame * .7) * .05 }),
  });
  assert.ok(jittered.resting && jittered.quiet > 4.5);
  assert.equal(jittered.focus, calm.focus);
  assert.ok(Math.abs(jittered.quiet - calm.quiet) < .15);
  jittered.mushrooms.forEach((mushroom, index) => assert.ok(Math.abs(mushroom.warmth - calm.mushrooms[index].warmth) < .06));
});

check('crossing a nearest-cap bisector by a few pixels does not flicker the focus', () => {
  let state = walk(approach(), { x: 1308, y: 4390 });
  const focus = state.focus;
  assert.equal(focus, 0);
  state = hold(state, 3, {
    actor: frame => ({ x: 1310 + Math.sin(frame * .3) * 2, y: 4390 }),
    observe(current) { assert.equal(current.focus, focus); },
  });
  assert.ok(state.engaged);
});

check('walking to a clearly closer cap transfers attention without resetting poses', () => {
  let state = hold(approach(), 4), previous = state;
  state = walk(state, rightCap, { observe(current) {
    current.mushrooms.forEach((mushroom, index) => {
      assert.ok(Math.abs(mushroom.warmth - previous.mushrooms[index].warmth) < .06);
      assert.ok(Math.abs(mushroom.lean - previous.mushrooms[index].lean) < .006);
    });
    previous = current;
  } });
  assert.equal(state.focus, 4);
  assert.ok(state.mushrooms[4].warmth > .3);
});

check('a fast pass creates only local greetings, not the full stationary response', () => {
  let largestGroup = 0, largestQuiet = 0;
  walk(createMushroomListening({ x: 900, y: 4350 }), { x: 1800, y: 4350 }, { observe(state) {
    largestGroup = Math.max(largestGroup, state.mushrooms.filter(mushroom => mushroom.warmth > .25).length);
    largestQuiet = Math.max(largestQuiet, state.quiet);
    assert.ok(peak(state) < .56, 'walking must not trigger the stronger stationary answer');
  } });
  assert.ok(largestGroup > 0 && largestGroup <= 2);
  assert.ok(largestQuiet < .25);
});

check('departing releases the response, and discovery does not disable a later visit', () => {
  let state = hold(approach(), 5);
  assert.ok(peak(state) > .6);
  state = walk(state, { x: 2200, y: 4350 });
  state = hold(state, 5);
  assert.ok(!state.engaged && peak(state) < .02);
  assert.ok(state.discovered);
  state = walk(state, leftCap);
  state = hold(state, 4);
  assert.ok(state.engaged && peak(state) > .6, 'the same visitor must still receive a new response');
  assert.ok(hold(approach(leftCap, { discovered: true }), 4).mushrooms[0].warmth > .6);
});

check('a long rest settles, and movement afterwards still receives a fresh greeting', () => {
  let state = hold(approach(), 50);
  assert.ok(peak(state) < .11, 'an indefinitely parked character must not run repeated shows');
  assert.ok(state.quiet <= 12.001, 'idle time must not accumulate into a minutes-long recovery');
  state = walk(state, rightCap);
  assert.equal(state.focus, 4);
  assert.ok(state.mushrooms[4].warmth > .3, 'walking after a long rest must still greet the new nearest cap');
});

check('reading freezes everything and returning resumes from the same point', () => {
  const before = hold(approach(), 3.2), snapshot = structuredClone(before);
  let paused = before;
  for (let frame = 0; frame < 240; frame++) {
    paused = advanceMushroomListening(paused, { x: 0, y: 0 }, 1 / 60, { paused: true, speed: 240, replaySerial: 99 });
    assert.equal(paused, before);
  }
  assert.deepEqual(paused, snapshot);
  const resumed = advanceMushroomListening(paused, before.actor, 1 / 60, { speed: 0 });
  const uninterrupted = advanceMushroomListening(before, before.actor, 1 / 60, { speed: 0 });
  assert.deepEqual(resumed, uninterrupted);
});

check('rendering or teleporting into the patch cannot accidentally start a full response', () => {
  let restored = hold(createMushroomListening(leftCap, true, 7), 10, { replaySerial: 7 });
  assert.ok(!restored.engaged && peak(restored) === 0);
  restored = advanceMushroomListening(restored, { x: leftCap.x + 2, y: leftCap.y }, 1 / 60, { speed: 120 });
  assert.ok(restored.engaged);
  let teleported = advanceMushroomListening(createMushroomListening({ x: -1200, y: 3200 }), leftCap, 1 / 60, { speed: 0 });
  teleported = hold(teleported, 8);
  assert.ok(!teleported.engaged && peak(teleported) === 0);
});

check('a replay pulse acts once, remains local, and does not pin the encounter at its start', () => {
  let state = createMushroomListening(leftCap, true, 3);
  state = advanceMushroomListening(state, leftCap, 1 / 60, { replaySerial: 4, speed: 0 });
  assert.ok(state.engaged);
  state = hold(state, 4, { replaySerial: 4 });
  assert.ok(state.quiet > 4 && peak(state) > .6);
  state = hold(state, 20, { replaySerial: 4 });
  assert.ok(peak(state) < .11, 'a consumed serial must not continually replay');
  const distant = advanceMushroomListening(createMushroomListening({ x: 0, y: 0 }), { x: 0, y: 0 }, 1 / 60, { replaySerial: 9 });
  assert.ok(!distant.engaged && peak(distant) === 0);
});

check('the encounter has comparable pacing at 30, 60, and 120 FPS', () => {
  const samples = [30, 60, 120].map(fps => hold(approach(leftCap, { fps }), 5.5, { fps }));
  const reference = samples[1];
  for (const state of samples) {
    assert.equal(state.focus, reference.focus);
    assert.ok(Math.abs(state.quiet - reference.quiet) < .11);
    state.mushrooms.forEach((mushroom, index) => {
      assert.ok(Math.abs(mushroom.warmth - reference.mushrooms[index].warmth) < .07);
      assert.ok(Math.abs(mushroom.lean - reference.mushrooms[index].lean) < .006);
    });
  }
});

check('a suspended or invalid frame cannot skip the quiet period or corrupt state', () => {
  const state = hold(approach(), 2);
  for (const delta of [0, -1, NaN, Infinity]) assert.equal(advanceMushroomListening(state, leftCap, delta), state);
  for (const actor of [{ x: NaN, y: 0 }, { x: 0, y: Infinity }]) assert.equal(advanceMushroomListening(state, actor, 1 / 60), state);
  const resumed = advanceMushroomListening(state, leftCap, 30, { speed: 0 });
  assert.ok(resumed.quiet <= state.quiet, 'elapsed background time must not count as active stillness');
  assert.ok(resumed.engaged, 'a stalled frame must not end an ongoing response');
  assert.ok(hold(resumed, 2).quiet > state.quiet + 1.8, 'standing still after a stall must continue the response');
  resumed.mushrooms.forEach((mushroom, index) => assert.ok(Math.abs(mushroom.warmth - state.mushrooms[index].warmth) < .08));
});

check('invalid optional speed measurements cannot poison the animation', () => {
  const state = approach();
  for (const speed of [NaN, Infinity, -Infinity]) {
    const result = advanceMushroomListening(state, state.actor, 1 / 60, { speed });
    assert.ok(Number.isFinite(result.speed), 'the next valid frame must be able to recover');
    assert.ok(Number.isFinite(result.quiet));
    assert.ok(result.mushrooms.every(mushroom => Number.isFinite(mushroom.warmth) && Number.isFinite(mushroom.lean)));
  }
});

check('all response phases keep planted feet, fixed height, and bounded subtle lean', () => {
  hold(approach(), 16, { observe(state) {
    state.mushrooms.forEach((_mushroom, index) => {
      for (const wind of [-1, 0, 1]) {
        const pose = listeningMushroomPose(state, index, wind);
        assert.equal(pose.footOffset, 0);
        assert.equal(pose.stretch, 1);
        assert.ok(Object.values(pose).every(Number.isFinite));
        assert.ok(pose.warmth >= 0 && pose.warmth <= 1);
        assert.ok(pose.glow >= 0 && pose.glow < .33);
        assert.ok(Math.abs(pose.lean) < .08);
      }
    });
  } });
});

console.log(`${checks - failures}/${checks} mushroom listening checks passed.`);
if (failures) process.exitCode = 1;
