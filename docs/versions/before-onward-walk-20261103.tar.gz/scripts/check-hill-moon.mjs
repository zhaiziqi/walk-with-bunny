import assert from 'node:assert/strict';
import { advanceAtlasInteraction, atlasEncounterSites, emptyAtlasInteraction } from '../src/scene/atlasInteraction.ts';
import { hillBirds, hillReveal, moonGround, moonLightResponse, moonMotes, moonMotePose, moonOrb, moonReveal, restoreHillMoonMemory } from '../src/scene/hillMoon.ts';

let checks = 0;
const check = (name, run) => { run(); checks++; console.log(`PASS: ${name}`); };

check('four paper birds occupy different grounded perches and preserve the painted aspect ratio', () => {
  assert.equal(hillBirds.length, 4);
  assert.equal(new Set(hillBirds.map(p => `${p.x},${p.y}`)).size, 4);
  for (const bird of hillBirds) {
    assert.ok([bird.x,bird.y,bird.w,bird.h,bird.foot,bird.phase].every(Number.isFinite));
    assert.ok(Math.hypot(bird.x - 1000, bird.y - 6800) < 270);
    assert.ok(Math.abs(bird.w / bird.h - 256 / 224) < 1e-12);
    assert.equal(bird.foot, .72);
    assert.ok(bird.w >= 88 && bird.w <= 110);
  }
});
check('both destinations fade gradually from every direction, including when walking back', () => {
  for (const [fade, center] of [[hillReveal,{x:1000,y:6800}],[moonReveal,{x:-200,y:8500}]]) {
    assert.equal(fade(center), 1);
    assert.equal(fade({x:center.x + 1550,y:center.y}), 0);
    let previous = 0;
    for (let radius = 1600; radius >= 0; radius -= 2) {
      const alpha = fade({x:center.x + radius,y:center.y});
      assert.ok(alpha >= previous && alpha - previous < .0038);
      assert.equal(alpha, fade({x:center.x - radius,y:center.y}));
      assert.equal(alpha, fade({x:center.x,y:center.y - radius}));
      previous = alpha;
    }
  }
  assert.equal(hillReveal({x:-1100,y:5400}), 0);
  assert.equal(moonReveal({x:1000,y:6800}), 0);
});
check('moonlight remains a narrow approach to the gift door, with the moon beside and behind it', () => {
  const door = {x:-200,y:8500,w:340};
  assert.equal(moonGround.x, door.x);
  assert.ok(moonGround.y < door.y);
  assert.ok(moonGround.y + moonGround.h / 2 >= door.y);
  assert.ok(moonGround.w <= 450 && moonGround.h <= 550);
  assert.ok(moonOrb.y > door.y + 250 && moonOrb.x - moonOrb.w / 2 > door.x + door.w / 2 + 100);
  assert.ok(moonOrb.w <= 110 && moonOrb.lift <= 270);
  for (let age = 0; age <= 12; age += .01) {
    const light = moonLightResponse(age, true);
    assert.ok(light >= .17 && light <= .331);
    assert.ok(Math.abs(light - moonLightResponse(age + .001, true)) < .0001);
  }
  assert.equal(moonLightResponse(0, true), moonLightResponse(100, true));
});
check('six fixed motes drift locally instead of forming an orbit or an expanding ring', () => {
  assert.equal(moonMotes.length, 6);
  for (let i = 0; i < moonMotes.length; i++) {
    const rest = moonMotes[i];
    assert.ok(rest.size >= 3.5 && rest.size <= 5);
    for (const time of [0,1,7,24,83,1000]) for (const age of [0,2.5,6,100]) {
      const pose = moonMotePose(time, i, age);
      assert.ok(Math.abs(pose.x - rest.x) <= 14 && Math.abs(pose.y - rest.y) <= 9);
      assert.ok(Math.abs(pose.z - rest.z) <= 23);
      assert.ok(pose.opacity >= .28 && pose.opacity <= .601);
      assert.ok([pose.x,pose.y,pose.z,pose.opacity].every(Number.isFinite));
    }
  }
});
check('restoring either encounter consumes the old pulse without replaying, but a new visit or click still works', () => {
  for (const id of ['hill','moon']) {
    const site = atlasEncounterSites.find(s => s.id === id), actor = {x:site.x,y:site.y}, pulse = {id,serial:4};
    let state = restoreHillMoonMemory(emptyAtlasInteraction(), site, actor, [site.event], pulse);
    assert.equal(state.age, 100);
    assert.ok(state.inside && state.fired);
    assert.equal(advanceAtlasInteraction(state, site, 0, .05, false, true, {id,serial:5}), state);
    for (let i = 0; i < 100; i++) state = advanceAtlasInteraction(state, site, 0, .05, false, false, pulse);
    assert.equal(state.activations, 0);
    state = advanceAtlasInteraction(state, site, 0, .05, false, false, {id,serial:5});
    assert.equal(state.activations, 1);
    state = advanceAtlasInteraction(state, site, site.radius + 150, .05, true, false, {id,serial:5});
    for (let i = 0; i < 50; i++) state = advanceAtlasInteraction(state, site, 0, .05, false, false, {id,serial:5});
    assert.equal(state.activations, 2);
  }
});
check('unvisited hill keeps its existing dwell rule and other encounters keep their original state', () => {
  const hill = atlasEncounterSites.find(s => s.id === 'hill');
  assert.equal(hill.dwell, 1.1);
  let state = emptyAtlasInteraction();
  for (let i = 0; i < 20; i++) state = advanceAtlasInteraction(state, hill, 0, .05, false, false);
  assert.equal(state.activations, 0);
  for (let i = 0; i < 3; i++) state = advanceAtlasInteraction(state, hill, 0, .05, false, false);
  assert.equal(state.activations, 1);
  for (const site of atlasEncounterSites) {
    const original = emptyAtlasInteraction(), actor = {x:site.x,y:site.y};
    assert.equal(restoreHillMoonMemory(original, site, actor, []), original);
    if (site.id !== 'hill' && site.id !== 'moon') assert.equal(restoreHillMoonMemory(original, site, actor, [site.event]), original);
    else {
      const distant = restoreHillMoonMemory(original, site, {x:site.x + 2000,y:site.y}, [site.event]);
      assert.ok(!distant.inside && !distant.fired);
    }
  }
});
console.log(`${checks} hill-to-moon checks passed.`);
