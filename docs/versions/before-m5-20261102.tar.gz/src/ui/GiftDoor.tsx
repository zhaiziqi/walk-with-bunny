import { useState } from 'react';
import type { Dispatch, FormEvent } from 'react';
import { art } from '../config/art';
import { content } from '../config/content';
import { useGiftUnlock } from '../motion/useGiftUnlock';
import type { Progress, ProgressAction } from '../state/experience';
import type { StorageStatus } from '../lib/storage';
import '../styles/gift.css';

type Props = {
  progress: Progress;
  dispatch: Dispatch<ProgressAction>;
  storageStatus: StorageStatus;
  reduced: boolean;
  onReveal: () => void;
  onClue: () => void;
  onReturn: () => void;
};

export function GiftDoor({ progress, dispatch, storageStatus, reduced, onReveal, onClue, onReturn }: Props) {
  const { opening, unlock } = useGiftUnlock(dispatch, reduced, onReveal);
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [artFailed, setArtFailed] = useState(false);
  const revisit = progress.giftUnlocked && !opening;
  const submit = (event: FormEvent) => {
    event.preventDefault();
    try {
      const result = unlock(code);
      if (result === 'busy') return;
      setError(result === 'invalid'
        ? progress.puzzleSolved ? 'Not quite. Take another look at your password card.' : 'Not quite. The signal garden holds a clue to all four digits.'
        : '');
    } catch { setError('The door needs another moment. Please try again.'); }
  };
  return <div className={`gift-door ${opening ? 'is-opening' : ''}`} data-gift-phase={opening ? 'opening' : revisit ? 'unlocked' : 'locked'}>
    <div className={`gift-door-picture ${artFailed ? 'art-unavailable' : ''}`} aria-hidden="true">
      <span className="gift-door-shadow"/>
      {!artFailed && <><img className="gift-door-frame" src={art.door} alt="" draggable={false} onError={() => setArtFailed(true)}/><span className="gift-door-light"/><img className="gift-door-leaf" src={art.door} alt="" draggable={false}/></>}
      {artFailed && <span className="gift-door-outline"><span/></span>}
    </div>
    <p className="gift-intro">{revisit ? 'The door is open. Come in whenever you like.' : progress.puzzleSolved ? content.gift.lockHintWithKey : content.gift.lockHintWithoutKey}</p>
    {revisit ? <button type="button" className="gift-primary" onClick={onReveal}>See your gift again <span aria-hidden="true">↗</span></button> : <form onSubmit={submit} noValidate className="gift-code-form">
      <label htmlFor="gift-code">Four-digit code</label>
      <input id="gift-code" name="gift-code" type="text" inputMode="numeric" autoComplete="off" spellCheck={false} maxLength={32} value={code} placeholder="· · · ·" readOnly={opening} aria-invalid={!!error} aria-describedby={`gift-code-help${error ? ' gift-code-error' : ''}`} onChange={event => { setCode(event.target.value); setError(''); }}/>
      <p id="gift-code-help" className="gift-input-help">Keep all four digits, including any zero at the beginning.</p>
      {error && <p id="gift-code-error" role="alert" className="gift-error">{error}</p>}
      <button type="submit" className="gift-primary" disabled={opening}>{opening ? 'The door is opening…' : content.gift.openLabel}<span aria-hidden="true">↗</span></button>
      <span className="sr-only" role="status">{opening ? 'The code fits. Your gift is ready.' : ''}</span>
    </form>}
    <div className="gift-footer"><button type="button" onClick={onReturn}>Return to the garden <span aria-hidden="true">↗</span></button><button type="button" onClick={onClue}>{progress.puzzleSolved ? 'My password card' : 'Look for a clue'} <span aria-hidden="true">→</span></button></div>
    {storageStatus === 'memory' && <p className="gift-storage" role="status">This browser cannot save progress. You can still open the gift during this visit.</p>}
  </div>;
}

export function GiftReveal({ storageStatus, onMusic, onReturn }: { storageStatus: StorageStatus; onMusic: () => void; onReturn: () => void }) {
  const gift = content.gift;
  const [failedSource, setFailedSource] = useState<string | null>(null);
  const hasImage = !!gift.imageSrc && failedSource !== gift.imageSrc;
  return <div className="gift-reveal" data-gift-phase="revealed">
    {content.people.recipientName.trim() && <p className="gift-recipient">For {content.people.recipientName}</p>}
    <figure className={`gift-photograph ${hasImage ? 'has-photo' : 'without-photo'}`}>
      {hasImage ? <img src={gift.imageSrc!} alt={gift.imageAlt} onError={() => setFailedSource(gift.imageSrc)}/> : <>
        <svg width="96" height="80" viewBox="0 0 120 100" fill="none" aria-hidden="true"><path d="M25 42h70v46H25z" fill="#ebe3d4" stroke="#b1ae98"/><path d="M21 33h78v15H21z" fill="#f4ecdf" stroke="#b1ae98"/><path d="M56 34h9v54h-9z" fill="#d2a9ad"/><path d="M60 32C34 34 35 9 47 13c9 3 12 13 13 19Zm1 0c25-1 28-23 15-20-9 2-14 13-15 20Z" stroke="#b99098" strokeWidth="2"/><path d="m60 33-13 9m14-9 12 11" stroke="#b99098" strokeWidth="2"/></svg>
        <figcaption>{gift.placeholder ? 'Your gift · details to follow' : 'A gift to give you in person'}</figcaption>
      </>}
    </figure>
    <h2 className="gift-name">{gift.name}</h2>
    {gift.reason.trim() && <p className="gift-reason">{gift.reason}</p>}
    <p className="gift-code-meaning">{gift.codeMeaning}</p>
    {content.people.senderName.trim() && <p className="gift-signature">— {content.people.senderName}</p>}
    <div className="gift-in-person"><h3>{gift.screenToRealText}</h3><p>{gift.deliveryText}</p></div>
    <p className="gift-ending">{gift.endingText}</p>
    <button type="button" className="gift-primary" onClick={onMusic}>{gift.musicReturnLabel}<span aria-hidden="true">↗</span></button>
    <div className="gift-footer"><button type="button" onClick={onReturn}>Return to the garden <span aria-hidden="true">↗</span></button></div>
    {gift.placeholder && <p className="gift-placeholder-note">Preview · The gift name and personal note are still to be added.</p>}
    {storageStatus === 'memory' && <p className="gift-storage" role="status">The gift is open for this visit. This browser could not save it for next time.</p>}
  </div>;
}
