import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { CanvasTexture, Group, Mesh, MeshBasicMaterial, PlaneGeometry, SRGBColorSpace } from 'three';
import type { Texture } from 'three';
import type { ArtKey } from '../config/art';
import { BILLBOARD_TILT, terrainHeight } from './depthWorld';
import type { MeadowPoint, MeadowGuidance } from './meadowMotion';
import type { JourneyFrameRef } from './journeyFrame';
import { advanceFloof, emptyFloof } from './floofMotion';

type Props = {
  actor: MeadowPoint; moving: boolean; heading: MeadowPoint; reading: boolean;
  textures: Partial<Record<ArtKey, Texture>> & { rabbitAtlas?: Texture };
  attentionTarget?: MeadowPoint; guidance?: MeadowGuidance; motion?: JourneyFrameRef;
};
const SIZE = 120, SHEET = SIZE * 1.45, CENTER = SHEET * .359;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const rand = (n: number) => { const v = Math.sin(n * 127.1 + 19.73) * 43758.5453; return v - Math.floor(v); };

/** An irregular painted edge stays readable at traveller scale; there is no animal atlas. */
export function createFloofCanvas() {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const cx = 256, cy = 263;
  const radius = (a: number) => 174 + Math.sin(a * 7 + 1.4) * 7 + Math.sin(a * 13 - .7) * 4 + Math.sin(a * 21) * 2.5;
  ctx.beginPath();
  for (let i = 0; i <= 240; i++) {
    const a = i / 240 * Math.PI * 2, r = radius(a);
    const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r;
    if (!i) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.closePath();
  const pigment = ctx.createLinearGradient(150, 120, 330, 465);
  pigment.addColorStop(0, '#fff9e6'); pigment.addColorStop(.5, '#fff3d4'); pigment.addColorStop(1, '#e8dfc7');
  ctx.fillStyle = pigment; ctx.fill();
  // Short dry-brush fibres overlap the core, with a soft falloff rather than a halo outline.
  for (let i = 0; i < 1550; i++) {
    const a = rand(i + 2) * Math.PI * 2, r = radius(a), length = 3 + rand(i + 71) * 16;
    const inner = r - 6 - rand(i + 193) * 9, twist = (rand(i + 269) - .5) * .09;
    const base = cy + Math.sin(a) * inner;
    ctx.strokeStyle = base > 345 ? `rgba(240,232,208,${.25 + rand(i + 89) * .48})` : `rgba(255,247,224,${.32 + rand(i + 89) * .55})`;
    ctx.lineWidth = .65 + rand(i + 113) * 1.9; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * inner, base);
    ctx.quadraticCurveTo(cx + Math.cos(a + twist) * r, cy + Math.sin(a + twist) * r,
      cx + Math.cos(a + twist * .6) * (r + length), cy + Math.sin(a + twist * .6) * (r + length));
    ctx.stroke();
  }
  ctx.save(); ctx.globalCompositeOperation = 'source-atop';
  for (let i = 0; i < 6200; i++) {
    const x = rand(i + 177) * 512, y = rand(i + 359) * 512, s = .5 + rand(i + 47) * 2.3;
    ctx.fillStyle = i % 3 ? 'rgba(255,255,245,.075)' : 'rgba(174,164,133,.035)';
    ctx.fillRect(x, y, s, s * .65);
  }
  ctx.restore();
  return canvas;
}

function floofPaint() {
  const texture = new CanvasTexture(createFloofCanvas()); texture.colorSpace = SRGBColorSpace;
  return texture;
}

function softDisc() {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 128;
  const context = canvas.getContext('2d')!;
  const falloff = context.createRadialGradient(64, 64, 4, 64, 64, 63);
  falloff.addColorStop(0, 'rgba(255,255,255,.8)'); falloff.addColorStop(.36, 'rgba(255,255,255,.48)');
  falloff.addColorStop(.68, 'rgba(255,255,255,.12)'); falloff.addColorStop(1, 'rgba(255,255,255,0)');
  context.fillStyle = falloff; context.fillRect(0, 0, 128, 128);
  return new CanvasTexture(canvas);
}

/** The ground anchor follows position exactly; only the soft body has inertia. */
export function RabbitCompanion({ actor, moving, heading, reading, guidance, motion }: Props) {
  const anchor = useRef<Group>(null!);
  const body = useRef<Mesh>(null!), shadow = useRef<Mesh>(null!), glow = useRef<Mesh>(null!);
  const tufts = useRef<(Group | null)[]>([]);
  const flecks = useRef(Array.from({ length: 6 }, () => ({ x: 0, y: 0, age: 10, size: 0 })));
  const last = useRef({ ...actor }), shape = useRef(emptyFloof()), initialized = useRef(false);
  const initialAnchor = useRef<[number, number, number]>([actor.x, actor.y, terrainHeight(actor.x, actor.y) + 3]);
  const clock = useRef(0), distance = useRef(0), fleckIndex = useRef(0);
  const art = useMemo(floofPaint, []), soft = useMemo(softDisc, []);
  const geometry = useMemo(() => new PlaneGeometry(SHEET, SHEET, 18, 18), []);
  const shadowGeometry = useMemo(() => new PlaneGeometry(146, 90, 8, 6), []);
  const original = useMemo(() => new Float32Array(geometry.attributes.position.array), [geometry]);
  useEffect(() => () => { art.dispose(); soft.dispose(); geometry.dispose(); shadowGeometry.dispose(); }, [art, soft, geometry, shadowGeometry]);

  useFrame((_frame, delta) => {
    // The controller advances this sample before drawing. React may publish UI
    // snapshots less often, so neither the anchor nor its gait waits for a commit.
    const sample = reading ? undefined : motion?.current;
    const currentActor = sample?.actor ?? actor, currentHeading = sample?.heading ?? heading;
    const currentGuidance = sample?.guidance ?? guidance, currentMoving = !reading && (sample?.moving ?? moving);
    const foot = terrainHeight(currentActor.x, currentActor.y);
    anchor.current.position.set(currentActor.x, currentActor.y, foot + 3);
    if (reading && initialized.current) { last.current = { ...currentActor }; return; }
    const dt = clamp(Number.isFinite(delta) ? delta : 0, 0, .05); if (!dt) return;
    const travel = Math.hypot(currentActor.x - last.current.x, currentActor.y - last.current.y), jump = travel > 80;
    last.current = { ...currentActor };
    if (!reading) clock.current += dt;
    shape.current = advanceFloof(shape.current, { travel, dt, speed: sample?.speed, moving: currentMoving, headingX: currentHeading.x, intent: currentGuidance?.active ? currentGuidance.strength : 0 });
    const m = shape.current, time = clock.current;
    const quietBreath = Math.sin(time * 1.45) * .009 * (1 - m.speed / 240);
    const stretch = m.stretch + quietBreath;
    const positions = geometry.attributes.position;
    for (let i = 0; i < positions.count; i++) {
      const x = original[i * 3], y = original[i * 3 + 1], height = Math.max(0, y + CENTER);
      const top = clamp(height / SIZE, 0, 1.1);
      // Deformation is zero at the foot; the tuft leans slightly behind its movement.
      const softSway = Math.sin(time * 1.1 + top * 3.2) * .55 * top * top;
      positions.setXYZ(i, x * (1 - stretch * .4) + m.bend * top * top + softSway,
        y + height * stretch, 0);
    }
    positions.needsUpdate = true;
    shadow.current.scale.set(1 + Math.max(0, -stretch) * .6, 1 + Math.max(0, -stretch) * .4, 1);
    (shadow.current.material as MeshBasicMaterial).opacity = .40 - Math.max(0, stretch) * .22;
    const contact = shadowGeometry.attributes.position;
    for (let i = 0; i < contact.count; i++) contact.setZ(i, terrainHeight(currentActor.x + 7 + contact.getX(i), currentActor.y - 4 + contact.getY(i)) - foot + 1);
    contact.needsUpdate = true;
    (glow.current.material as MeshBasicMaterial).opacity = .065 + Math.sin(time * 1.1) * .009;
    if (jump) { distance.current = 0; flecks.current.forEach(f => { f.age = 10; }); }
    else if (currentMoving) distance.current += travel;
    if (distance.current > 54 && currentMoving) {
      distance.current %= 54;
      const index = fleckIndex.current++ % flecks.current.length, seed = fleckIndex.current;
      flecks.current[index] = { x: currentActor.x - currentHeading.x * 27 + (rand(seed) - .5) * 14,
        y: currentActor.y - currentHeading.y * 27 + (rand(seed + 9) - .5) * 14, age: 0, size: 6 + rand(seed + 27) * 5 };
    }
    flecks.current.forEach((fleck, i) => {
      const node = tufts.current[i]; if (!node) return;
      if (!reading) fleck.age += dt;
      node.visible = fleck.age < 2.2;
      if (!node.visible) return;
      const p = fleck.age / 2.2;
      node.position.set(fleck.x + Math.sin(time + i) * p * 4, fleck.y + p * 5, terrainHeight(fleck.x, fleck.y) + 4 + Math.sin(p * Math.PI) * 8);
      node.scale.setScalar(fleck.size * (1 - p * .5));
      const material = (node.children[0] as Mesh).material as MeshBasicMaterial;
      material.opacity = (1 - p) ** 1.4 * .48;
    });
    initialized.current = true;
  });

  return <>
    {flecks.current.map((_, i) => <group key={i} ref={node => { tufts.current[i] = node; }} visible={false} rotation={[BILLBOARD_TILT, 0, 0]}>
      <mesh><planeGeometry args={[1.45, 1.45]}/><meshBasicMaterial map={art} transparent alphaTest={.015} depthWrite={false} toneMapped={false}/></mesh>
    </group>)}
    <group ref={anchor} name="little-floof" position={initialAnchor.current}>
      <mesh ref={shadow} geometry={shadowGeometry} position={[7, -4, 0]}><meshBasicMaterial map={soft} color="#3d6472" transparent opacity={.40} depthWrite={false} toneMapped={false}/></mesh>
      <group rotation={[BILLBOARD_TILT, 0, 0]}>
        <mesh ref={glow} position={[0, CENTER, -.5]}><planeGeometry args={[SIZE * 1.8, SIZE * 1.8]}/><meshBasicMaterial map={soft} color="#fff1d1" transparent opacity={.065} depthWrite={false} toneMapped={false}/></mesh>
        <mesh ref={body} geometry={geometry} position={[0, CENTER, 0]}><meshBasicMaterial map={art} transparent alphaTest={.012} depthWrite={false} toneMapped={false}/></mesh>
      </group>
    </group>
  </>;
}
