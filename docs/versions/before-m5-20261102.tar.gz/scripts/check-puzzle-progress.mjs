import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import { extname } from 'node:path';

// Match the app's TypeScript module resolution without adding a test dependency.
registerHooks({ resolve(specifier, context, nextResolve) {
  if (specifier.startsWith('.') && !extname(specifier) && context.parentURL?.includes('/src/')) {
    return nextResolve(`${specifier}.ts`, context);
  }
  return nextResolve(specifier, context);
} });

const { content } = await import('../src/config/content.ts');
const { createInitialProgress, progressReducer, viewFromHash } = await import('../src/state/experience.ts');
const { expectedOutput, outputComplete, matchesOutput, decimalValue, acceptSegment, isSolvedCard } = await import('../src/lib/puzzle.ts');
const { STORAGE_KEY, normalizeProgress, loadProgress, saveProgress } = await import('../src/lib/storage.ts');

let passed = 0, failed = 0;
const check = (name, run) => {
  try { run(); passed++; console.log(`PASS: ${name}`); }
  catch (error) { failed++; console.error(`FAIL: ${name}\n${error.stack}`); }
};
const clone = value => structuredClone(value);
const act = (state, type, card, extra = {}) => progressReducer(state, { type, card, ...extra });
const fill = (state, card, bits) => bits.reduce((value, bit, index) => act(value, 'set-bit', card, { index, value: bit }), state);
const toDecimal = (state, card) => act(fill(state, card, expectedOutput(card)), 'check-bits', card);
const solve = (state, card, input = String(decimalValue(card))) => act(act(toDecimal(state, card), 'set-decimal', card, { value: input }), 'solve-card', card);
const completed = () => solve(solve(createInitialProgress(), 'A'), 'B');
const memoryStore = (initial = null) => {
  const entries = new Map(initial === null ? [] : [[STORAGE_KEY, initial]]);
  return { entries, getItem: key => entries.get(key) ?? null, setItem: (key, value) => { entries.set(key, value); } };
};
const savedDraw = { songId: 9, drawId: 'existing-draw', drawnAt: '2026-11-01T10:00:00.000Z' };

check('each card starts unanswered; null is never a selected zero', () => {
  const initial = createInitialProgress();
  assert.deepEqual(initial.cards.A.output, [null, null, null, null]);
  assert.deepEqual(initial.cards.B.output, [null, null, null, null]);
  assert.equal(outputComplete(initial.cards.A.output), false);
  assert.equal(outputComplete([0, 0, 0, 0]), true);
  assert.equal(matchesOutput('A', [null, null, 1, 1]), false);
  assert.equal(outputComplete([0, 1, 1]), false);
  assert.equal(outputComplete([0, 1, 1, 1, 1]), false);
  assert.equal(outputComplete([0, 1, 2, 1]), false);
  assert.equal(outputComplete(Array(4)), false);
  assert.equal(outputComplete([0, , 1, 1]), false);
  initial.cards.A.output[0] = 1;
  assert.equal(initial.cards.B.output[0], null);
  assert.equal(createInitialProgress().cards.A.output[0], null);
});

check('configured signals decode independently and preserve the leading-zero segments', () => {
  assert.deepEqual(expectedOutput('A'), [0, 0, 1, 1]);
  assert.deepEqual(expectedOutput('B'), [0, 1, 0, 1]);
  assert.equal(decimalValue('A'), 3);
  assert.equal(decimalValue('B'), 5);
  assert.equal(acceptSegment('3', 3) + acceptSegment('5', 5), content.puzzle.code);
  assert.equal(content.puzzle.code, '0305');
});

check('incomplete and wrong outputs retain every answer without advancing', () => {
  for (const output of [[null, null, null, null], [0, null, 1, 1], [1, 0, 1, 1], [0, 0, 0, 0]]) {
    const state = createInitialProgress(); state.cards.A.output = output;
    const before = clone(state);
    const result = act(state, 'check-bits', 'A');
    assert.deepEqual(result, before);
    assert.equal(result.cards.A.stage, 'bits');
    assert.equal(result.cards.A.segment, null);
    assert.equal(result.puzzleSolved, false);
  }
});

check('decimal answers cannot skip bit verification or unlock B before A', () => {
  const initial = createInitialProgress();
  assert.deepEqual(act(initial, 'set-decimal', 'A', { value: '3' }), initial);
  assert.deepEqual(act(initial, 'solve-card', 'A'), initial);
  for (const event of [
    { type: 'set-bit', card: 'B', index: 0, value: 0 },
    { type: 'check-bits', card: 'B' }, { type: 'set-decimal', card: 'B', value: '5' },
    { type: 'solve-card', card: 'B' }, { type: 'assist-card', card: 'B' }, { type: 'seen-bridge' },
  ]) assert.deepEqual(progressReducer(initial, event), initial);
  const firstBits = toDecimal(initial, 'A');
  assert.equal(firstBits.cards.A.stage, 'decimal');
  assert.equal(firstBits.cards.A.segment, null);
  assert.deepEqual(act(firstBits, 'assist-card', 'B'), firstBits);
});

check('wrong decimal input is kept and never marks a card complete', () => {
  const card = toDecimal(createInitialProgress(), 'A');
  for (const value of ['', '0', '5', '30', '003', '-3', '+3', '3.0', '3e0', '0x3', 'three', '３']) {
    const draft = act(card, 'set-decimal', 'A', { value });
    const after = act(draft, 'solve-card', 'A');
    assert.equal(acceptSegment(value, 3), null, `unexpectedly accepted ${JSON.stringify(value)}`);
    assert.equal(after.cards.A.decimalInput, value);
    assert.equal(after.cards.A.stage, 'decimal');
    assert.equal(after.cards.A.segment, null);
    assert.equal(after.puzzleSolved, false);
  }
});

check('3/03 and 5/05 are accepted; only two validated cards award the key', () => {
  for (const a of ['3', '03', ' 03 ']) for (const b of ['5', '05', ' 05 ']) {
    const first = solve(createInitialProgress(), 'A', a);
    assert.equal(first.cards.A.segment, '03');
    assert.equal(first.puzzleSolved, false);
    assert.equal(first.cards.B.stage, 'bits');
    assert.deepEqual(first.cards.B.output, [null, null, null, null]);
    const result = solve(first, 'B', b);
    assert.equal(result.cards.B.segment, '05');
    assert.equal(result.puzzleSolved, true);
    assert.equal(result.cards.A.segment + result.cards.B.segment, '0305');
    assert.equal(result.giftUnlocked, false);
    assert.equal(result.lastDraw, null);
    assert.equal(result.bridgeSeen, false);
  }
});

check('bit edits are immutable and ignored once verified; solved cards are read-only', () => {
  const initial = createInitialProgress(), before = clone(initial);
  const edited = act(initial, 'set-bit', 'A', { index: 0, value: 0 });
  assert.deepEqual(initial, before);
  assert.notStrictEqual(edited.cards.A.output, initial.cards.A.output);
  const decimal = toDecimal(initial, 'A');
  assert.deepEqual(act(decimal, 'set-bit', 'A', { index: 0, value: 1 }), decimal);
  const result = completed();
  for (const card of ['A', 'B']) for (const event of [
    { type: 'set-bit', card, index: 0, value: 1 }, { type: 'check-bits', card },
    { type: 'set-decimal', card, value: '99' }, { type: 'solve-card', card }, { type: 'assist-card', card },
  ]) assert.deepEqual(progressReducer(result, event), result);
  for (const index of [-1, 4, .5, NaN]) assert.deepEqual(act(initial, 'set-bit', 'A', { index, value: 0 }), initial);
  for (const value of [null, undefined, '0', 2]) assert.deepEqual(act(initial, 'set-bit', 'A', { index: 0, value }), initial);
});

check('explicit assistance writes one complete consistent card, never a bare solved flag', () => {
  let state = fill(createInitialProgress(), 'A', [1, 1, 1, 1]);
  state = act(state, 'assist-card', 'A');
  assert.equal(isSolvedCard('A', state.cards.A), true);
  assert.deepEqual(state.cards.A.output, [0, 0, 1, 1]);
  assert.equal(state.cards.A.segment, '03');
  assert.deepEqual(state.cards.B, createInitialProgress().cards.B);
  assert.equal(state.puzzleSolved, false);
  state = act(state, 'assist-card', 'B');
  assert.equal(isSolvedCard('B', state.cards.B), true);
  assert.equal(state.cards.B.segment, '05');
  assert.equal(state.puzzleSolved, true);
  assert.equal(state.giftUnlocked, false);
});

check('the optional bridge requires both cards and does not change music or gift state', () => {
  const one = solve(createInitialProgress(), 'A');
  assert.deepEqual(progressReducer(one, { type: 'seen-bridge' }), one);
  const initial = { ...createInitialProgress(), giftUnlocked: true, lastDraw: savedDraw };
  const solved = solve(solve(initial, 'A'), 'B');
  const bridge = progressReducer(solved, { type: 'seen-bridge' });
  assert.equal(bridge.bridgeSeen, true);
  assert.equal(bridge.puzzleSolved, true);
  assert.equal(bridge.giftUnlocked, true);
  assert.deepEqual(bridge.lastDraw, savedDraw);
  assert.deepEqual(bridge.cards, solved.cards);
  assert.deepEqual(progressReducer(bridge, { type: 'seen-bridge' }), bridge);
});

check('navigation alone cannot solve the puzzle or unlock a gift', () => {
  const initial = createInitialProgress(), before = clone(initial);
  assert.equal(viewFromHash('#music'), 'music');
  assert.equal(viewFromHash('#puzzle'), 'puzzle');
  assert.equal(viewFromHash('#gift'), 'lock');
  assert.equal(viewFromHash('#gift', true), 'gift');
  assert.equal(viewFromHash('#garbage'), 'overview');
  assert.deepEqual(initial, before);
  const giftOnly = normalizeProgress({ ...initial, giftUnlocked: true, puzzleSolved: true, bridgeSeen: true });
  assert.equal(giftOnly.giftUnlocked, true);
  assert.equal(giftOnly.puzzleSolved, false);
  assert.equal(giftOnly.bridgeSeen, false);
  assert.deepEqual(giftOnly.cards, initial.cards);
});

check('partial, decimal, single-card and complete progress survive a real JSON round trip', () => {
  const partial = act(createInitialProgress(), 'set-bit', 'A', { index: 2, value: 1 });
  const decimal = act(toDecimal(createInitialProgress(), 'A'), 'set-decimal', 'A', { value: '8' });
  const first = solve(createInitialProgress(), 'A', '03');
  const secondPartial = act(first, 'set-bit', 'B', { index: 3, value: 1 });
  const all = progressReducer(completed(), { type: 'seen-bridge' });
  for (const progress of [partial, decimal, first, secondPartial, all]) {
    const storage = memoryStore();
    assert.equal(saveProgress(progress, storage), true);
    assert.deepEqual(loadProgress(storage), { progress, storageStatus: 'saved' });
  }
});

check('corrupt JSON, missing records and unsupported versions safely restore defaults', () => {
  for (const text of ['{broken', 'null', '[]', 'false', '17', '{}', '{"version":2}', '{"version":"1"}']) {
    assert.deepEqual(loadProgress(memoryStore(text)).progress, createInitialProgress(), text);
  }
  assert.deepEqual(loadProgress(memoryStore()).progress, createInitialProgress());
  assert.deepEqual(normalizeProgress(undefined), createInitialProgress());
  assert.deepEqual(normalizeProgress({ ...completed(), version: 0 }), createInitialProgress());
});

check('restoration derives puzzle completion and rejects forged completion flags', () => {
  const forged = { ...createInitialProgress(), puzzleSolved: true, bridgeSeen: true };
  assert.deepEqual(normalizeProgress(forged), createInitialProgress());
  const valid = completed(); valid.puzzleSolved = false;
  const result = normalizeProgress(valid);
  assert.equal(result.puzzleSolved, true);
  assert.equal(result.bridgeSeen, false);
  const outOfOrder = createInitialProgress(); outOfOrder.cards.B = completed().cards.B;
  outOfOrder.puzzleSolved = true; outOfOrder.bridgeSeen = true;
  assert.deepEqual(normalizeProgress(outOfOrder), createInitialProgress());
});

check('invalid solved outputs, numeric answers and segments never create a key', () => {
  const mutations = [
    card => { card.output = [1, 1, 1, 1]; },
    card => { card.output = [null, 0, 1, 1]; },
    card => { card.output = ['0', 0, 1, 1]; },
    card => { card.output = [0, 0, 1]; },
    card => { card.output = Array(4); },
    card => { card.output = [0, , 1, 1]; },
    card => { card.decimalInput = '4'; },
    card => { card.decimalInput = 3; },
    card => { card.segment = '3'; },
    card => { card.segment = '99'; },
    card => { card.stage = 'unknown'; },
  ];
  for (const mutate of mutations) {
    const stored = completed(); mutate(stored.cards.A); stored.bridgeSeen = true;
    const result = normalizeProgress(stored);
    assert.equal(result.puzzleSolved, false);
    assert.equal(result.bridgeSeen, false);
    assert.notEqual(result.cards.A.stage, 'solved');
    assert.equal(result.cards.A.segment, null);
    assert.deepEqual(result.cards.B, createInitialProgress().cards.B);
  }
  const B = completed(); B.cards.B.segment = '5';
  const result = normalizeProgress(B);
  assert.equal(result.cards.A.stage, 'solved');
  assert.equal(result.cards.B.stage, 'decimal');
  assert.equal(result.cards.B.segment, null);
  assert.equal(result.puzzleSolved, false);
});

check('valid bits remain recoverable without auto-promoting an unverified draft', () => {
  const draft = fill(createInitialProgress(), 'A', [0, 0, 1, 1]);
  draft.cards.A.segment = '03'; draft.cards.A.decimalInput = '3';
  const result = normalizeProgress(draft);
  assert.deepEqual(result.cards.A.output, [0, 0, 1, 1]);
  assert.equal(result.cards.A.stage, 'bits');
  assert.equal(result.cards.A.segment, null);
  assert.equal(result.puzzleSolved, false);
});

check('storage contains only business fields and keeps independent valid music/gift progress', () => {
  const initial = { ...createInitialProgress(), giftUnlocked: true, lastDraw: savedDraw,
    view: 'gift', camera: { x: 10, y: 20 }, isDrawing: true, animationPhase: 'opening' };
  const storage = memoryStore(); storage.entries.set('unrelated-user-preference', 'keep-me');
  assert.equal(saveProgress(initial, storage), true);
  const raw = JSON.parse(storage.entries.get(STORAGE_KEY));
  assert.deepEqual(Object.keys(raw).sort(), ['version', 'cards', 'puzzleSolved', 'bridgeSeen', 'giftUnlocked', 'lastDraw'].sort());
  assert.equal(raw.giftUnlocked, true);
  assert.deepEqual(raw.lastDraw, savedDraw);
  assert.equal(raw.puzzleSolved, false);
  assert.equal(storage.entries.get('unrelated-user-preference'), 'keep-me');
  assert.equal(STORAGE_KEY, 'birthday-gift:0305:v1');
  for (const songId of [0, 10, 1.5, '3']) {
    assert.equal(normalizeProgress({ ...initial, lastDraw: { ...savedDraw, songId } }).lastDraw, null);
  }
  assert.equal(normalizeProgress({ ...initial, lastDraw: { ...savedDraw, drawId: '' } }).lastDraw, null);
  assert.equal(normalizeProgress({ ...initial, lastDraw: { ...savedDraw, drawnAt: 'not-a-date' } }).lastDraw, null);
});

check('storage denial and quota failure do not interrupt completing the puzzle in memory', () => {
  const denied = { getItem() { throw new Error('SecurityError'); }, setItem() { throw new Error('QuotaExceededError'); } };
  const loaded = loadProgress(denied);
  assert.equal(loaded.storageStatus, 'memory');
  let state = loaded.progress;
  for (const card of ['A', 'B']) {
    state = solve(state, card);
    const before = clone(state);
    assert.equal(saveProgress(state, denied), false);
    assert.deepEqual(state, before);
  }
  assert.equal(state.puzzleSolved, true);
  assert.equal(loadProgress(null).storageStatus, 'memory');
  assert.equal(saveProgress(state, null), false);
  const readOnly = memoryStore(JSON.stringify(state)); readOnly.setItem = denied.setItem;
  assert.equal(loadProgress(readOnly).progress.puzzleSolved, true);
  assert.equal(saveProgress(state, readOnly), false);
});

check('failure while accessing the browser storage getter is caught before any read', () => {
  const previous = Object.getOwnPropertyDescriptor(globalThis, 'window');
  Object.defineProperty(globalThis, 'window', { configurable: true, value: {
    get localStorage() { throw new Error('Storage access blocked'); },
  } });
  try {
    assert.equal(loadProgress().storageStatus, 'memory');
    assert.equal(saveProgress(completed()), false);
  } finally {
    if (previous) Object.defineProperty(globalThis, 'window', previous); else delete globalThis.window;
  }
});

console.log(`\nPuzzle progress: ${passed} passed, ${failed} failed.`);
if (failed) process.exitCode = 1;
