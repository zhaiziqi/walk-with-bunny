import type { LoadedArt } from './useAssets';
import type { JourneyPose } from './journey';
import type { Place } from './world';
import type { MeadowPoint } from './meadowMotion';
import { FloofStatic } from './FloofStatic';
import type { PaperGuideRef } from './paperGuide';

export type StaticGardenProps = {
  images: LoadedArt; pose: JourneyPose; width: number; height: number; bloom: number; lampOn: boolean;
  entered: boolean; actor: MeadowPoint; heading: MeadowPoint; discovered: Place[];
  reading?: boolean; trailEvents?: readonly string[]; paperGuide?: PaperGuideRef;
};

/** A painted, non-WebGL view preserves the same world anchors and HTML interactions. */
export function StaticGarden(props: StaticGardenProps) {
  return <FloofStatic {...props}/>;
}
