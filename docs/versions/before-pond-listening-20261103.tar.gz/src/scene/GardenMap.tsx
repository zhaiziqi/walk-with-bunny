import { paths, regions } from './gardenAtlas';
import type { GardenRegion, RegionId } from './gardenAtlas';
import type { MeadowPoint } from './meadowMotion';
import '../styles/map-guide.css';

type Props = {
  actor: MeadowPoint;
  visited: RegionId[];
  travel: (region: GardenRegion) => void;
  onClose: () => void;
  puzzleSolved?: boolean;
  puzzleStarted?: boolean;
};

/** Known places can be revisited; the next clue gives direction, never a teleport. */
export function GardenMap({ actor, visited, travel, onClose, puzzleSolved = false, puzzleStarted = false }: Props) {
  const known = regions.filter(region => visited.includes(region.id));
  const desk = regions.find(region => region.id === 'lantern')!;
  const deskVisited = visited.includes(desk.id);
  const showClue = !puzzleSolved;
  const showNextMarker = showClue && !deskVisited;
  // Frame just the first trail and its clue; later destinations stay hidden.
  const firstTrail = paths.find(path => path.id === 'entry-lantern')!;
  const framed = showNextMarker ? [...known, ...firstTrail.points] : known;
  const minY = Math.min(actor.y, ...framed.map(region => region.y)) - 550;
  const maxY = Math.max(actor.y, ...framed.map(region => region.y)) + 850;
  const minX = Math.min(actor.x, ...framed.map(region => region.x)) - 650;
  const maxX = Math.max(actor.x, ...framed.map(region => region.x)) + 650;
  const position = (x: number, y: number) => ({ x: 26 + (y - minY) / (maxY - minY) * 468, y: 24 + (x - minX) / (maxX - minX) * 136 });
  const rabbit = position(actor.x, actor.y);
  const nextMarker = position(desk.x, desk.y);
  const clue = puzzleStarted ? 'Your questions are waiting by the lantern.'
    : deskVisited ? 'Look for the paper beneath the lantern. Click the desk to begin.'
      : 'Follow the pale path to the lantern. Four small questions wait there.';

  return <nav className="garden-map guide-map" aria-label="A little map">
    <div className="map-caption"><span>A little map <small>Places you remember</small></span><button aria-label="Close map" onClick={onClose}>×</button></div>
    <svg viewBox="0 0 520 190" aria-hidden="true">
      <defs><linearGradient id="unseen-path"><stop offset="0" stopColor="#a2a899" stopOpacity=".55"/><stop offset="1" stopColor="#a2a899" stopOpacity="0"/></linearGradient></defs>
      {paths.filter(path => visited.includes(path.from) || visited.includes(path.to) || (showNextMarker && path.id === 'entry-lantern')).map(path => {
        const complete = visited.includes(path.from) && visited.includes(path.to);
        const nextTrail = showNextMarker && path.id === 'entry-lantern';
        const ordered = visited.includes(path.from) || nextTrail ? path.points : [...path.points].reverse();
        const points = complete || nextTrail ? ordered : ordered.slice(0, Math.max(3, Math.round(ordered.length * .28)));
        return <polyline key={path.id} data-map-path={path.id} data-map-path-state={complete ? 'known' : nextTrail ? 'clue' : 'unseen'} points={points.map(point => {
          const mapped = position(point.x, point.y); return `${mapped.x},${mapped.y}`;
        }).join(' ')} fill="none" stroke={complete ? '#a2a899' : nextTrail ? '#aa9e83' : 'url(#unseen-path)'} strokeWidth={complete ? 1.7 : 1.2} strokeDasharray={complete ? undefined : '2 5'} opacity={nextTrail ? .62 : .7}/>;
      })}
      {known.map(region => {
        const point = position(region.x, region.y);
        return <circle key={region.id} data-map-known={region.id} cx={point.x} cy={point.y} r="5" fill={region.color} stroke="#88988d" strokeWidth=".8"/>;
      })}
      {showNextMarker && <g className="map-next-marker" data-map-clue="lantern" transform={`translate(${nextMarker.x} ${nextMarker.y})`}>
        <circle r="11" fill="#f8f5ec" stroke="#9c9178" strokeWidth="1" strokeDasharray="2 3"/>
        <path d="M-3-4H3L4 5H-4ZM-2-4V-7H2V-4" fill="none" stroke="#8d8064" strokeWidth="1" strokeLinejoin="round"/>
        <text y="28" textAnchor="middle">The puzzle desk</text>
      </g>}
      <circle cx={rabbit.x} cy={rabbit.y} r="7" fill="none" stroke="#986d77" strokeWidth="1.5"/>
      <circle cx={rabbit.x} cy={rabbit.y} r="2" fill="#986d77"/>
    </svg>
    {showClue && <section className="map-next-clue" aria-label="Your next clue">
      <span className="map-clue-caption">{deskVisited ? 'At the lantern' : 'Next along the path'}</span>
      <div><h2>The puzzle desk</h2><p>{clue}</p></div>
    </section>}
    <div className="map-places">{known.map(region => <button key={region.id} onClick={() => travel(region)}><small>return to</small>{region.name}</button>)}</div>
    {known.length < regions.length && <p className="map-unseen">There is more beyond the mist.</p>}
  </nav>;
}
