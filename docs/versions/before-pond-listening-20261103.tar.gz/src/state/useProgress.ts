import { useCallback, useEffect, useRef, useState } from 'react';
import { progressReducer } from './experience';
import type { Progress, ProgressAction } from './experience';
import { mergeProgress, sameProgress } from './mergeProgress';
import { loadProgress, loadSharedProgress, saveProgress, STORAGE_KEY } from '../lib/storage';
import type { StorageStatus } from '../lib/storage';

/** Business state loads before navigation and remains usable if saving is unavailable. */
export function useProgress() {
  const [initial] = useState(loadProgress);
  const [progress, setProgress] = useState(initial.progress);
  const current = useRef(initial.progress);
  const observed = useRef(initial.progress);
  const [storageStatus, setStorageStatus] = useState<StorageStatus>(initial.storageStatus);
  const reconcile = useCallback((stored: Progress) => {
    const next = mergeProgress(current.current, stored, observed.current);
    observed.current = stored;
    return next;
  }, []);
  // Rebase on storage before the command: an old tab cannot erase another tab's
  // answers, and a deliberate new draw still wins. Save before animation begins.
  const dispatch = useCallback((action: ProgressAction) => {
    const before = current.current;
    const loaded = loadSharedProgress();
    const base = loaded.progress ? reconcile(loaded.progress) : before;
    const next = progressReducer(base, action);
    current.current = next;
    const changed = next !== base;
    const repair = loaded.progress && !sameProgress(next, loaded.progress);
    if (changed || repair) {
      const saved = saveProgress(next);
      if (saved) observed.current = next;
      setStorageStatus(saved ? 'saved' : 'memory');
    } else if (loaded.storageStatus === 'memory') setStorageStatus('memory');
    if (next !== before) setProgress(next);
  }, [reconcile]);
  useEffect(() => {
    // A late mount effect also rebases; another tab may have progressed since render.
    const loaded = loadSharedProgress();
    const next = loaded.progress ? reconcile(loaded.progress) : current.current;
    current.current = next;
    setProgress(next);
    const saved = saveProgress(next);
    if (saved) observed.current = next;
    setStorageStatus(saved ? 'saved' : 'memory');

    const sync = (event: StorageEvent) => {
      if (event.key !== STORAGE_KEY || event.newValue === null) return;
      try { if (event.storageArea && event.storageArea !== window.localStorage) return; }
      catch { return; }
      // Read the latest value, not a queued event's potentially stale snapshot.
      const incoming = loadSharedProgress();
      if (!incoming.progress) return;
      const merged = reconcile(incoming.progress);
      current.current = merged;
      setProgress(merged);
      // Repair only genuinely missing achievements; equal records never echo.
      if (!sameProgress(merged, incoming.progress)) {
        const persisted = saveProgress(merged);
        if (persisted) observed.current = merged;
        setStorageStatus(persisted ? 'saved' : 'memory');
      } else setStorageStatus('saved');
    };
    window.addEventListener?.('storage', sync);
    return () => window.removeEventListener?.('storage', sync);
  }, [reconcile]);
  return { progress, dispatch, storageStatus };
}
