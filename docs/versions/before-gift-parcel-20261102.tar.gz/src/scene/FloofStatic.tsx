import { useEffect, useMemo, useRef, useState } from 'react';
import type { StaticGardenProps } from './StaticGarden';
import { depthProject, landmarkReveal, terrainHeight } from './depthWorld';
import { createFloofBrushCanvas } from './floofBrushCanvas';
import { createFloofArt } from './floofSceneryArt';
import { floofPlants } from './floofSceneryData';
import { useFloofPaintedLeaves } from './floofPaintedLeaves';
import { sceneAssetUrl } from '../diagnostics/assetQA';
import { loadLocalImage } from './loadLocalImage';
import { createFloofCanvas } from './floofCompanionArt';
import { regionAtmosphere } from './gardenAtlas';
import { objects } from './world';
import { createTrailState, guidePosition, guideVisible, trailPassageBloom, trailSites, trailFlowerOffsets } from './trailState';

const clamp = (n: number, a = 0, b = 1) => Math.max(a, Math.min(b, n));
const smooth = (a: number, b: number, v: number) => { const p = clamp((v - a) / (b - a)); return p * p * (3 - 2 * p); };
const mound = (x: number, y: number, cx: number, cy: number, rx: number, ry: number) => Math.exp(-(((x - cx) / rx) ** 2) - ((y - cy) / ry) ** 2);
const mix = (a: number[], b: number[], t: number) => a.map((value, i) => value + (b[i] - value) * t);
const css = (rgb: number[]) => `rgb(${rgb.map(v => Math.round(clamp(v) * 255)).join(',')})`;
const random = (n: number) => { const p = Math.sin(n * 127.1 + 19.73) * 43758.5453; return p - Math.floor(p); };

function groundColor(x: number, y: number) {
  const twilight = regionAtmosphere(x, y).dusk;
  const sage = mix([.657, .727, .610], [.520, .625, .630], twilight * .85);
  const blue = mix([.600, .660, .764], [.471, .543, .664], twilight * .78);
  const underpaint = mix([.433, .582, .526], [.427, .541, .566], twilight * .75);
  const diagonal = x * .70 + y * .55 + 150 + Math.sin(y * .0014) * 105;
  const edge = Math.sin(x * .021 + y * .017) * 42 + Math.cos(y * .039 - x * .016) * 17;
  const slopeBand = (1 - smooth(180 + edge, 360 + edge, Math.abs(diagonal))) * (1 - smooth(950, 2450, Math.abs(y + 750)));
  const bankPaint = Math.max(slopeBand, mound(x, y, 930, -780, 490, 610) * .46);
  let color = mix(sage, blue, bankPaint * .84);
  const shade = mound(x, y, -340, -910, 650, 180) * .43 + mound(x, y, 1080, -570, 490, 380) * .70;
  color = mix(color, underpaint, shade * 1.1);
  const westBank = mound(x, y, -240, -680, 510, 285);
  color = color.map((value, i) => value + [.017, .024, .017][i] * westBank);
  const lowerShoulder = y + 2040 + .32 * x + 105 * Math.sin(x * .0017);
  const shoulder = (1 - smooth(35 + edge * .3, 150, Math.abs(lowerShoulder))) * (1 - smooth(-350, 360, x));
  color = mix(color, underpaint, shoulder * .32);
  color = color.map((value, i) => value + [.042, .043, .012][i] * mound(x, y, -400, -1830, 950, 120));
  const laterBank = smooth(-.2, .8, Math.sin(x * .0009) * Math.cos(y * .0009));
  color = mix(color, blue, laterBank * smooth(600, 2300, y) * .3);
  const light = mound(x, y, 80, -2050, 650, 570) * .38 + mound(x, y, 320, -1590, 380, 940) * .58 + mound(x, y, -650, 750, 340, 290) * .38;
  return color.map((value, i) => value + [.065, .053, .025][i] * light);
}

function tinted(source: HTMLCanvasElement, color: string) {
  const canvas = document.createElement('canvas'); canvas.width = source.width; canvas.height = source.height;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(source, 0, 0); ctx.globalCompositeOperation = 'multiply';
  ctx.fillStyle = color; ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.globalCompositeOperation = 'destination-in'; ctx.drawImage(source, 0, 0);
  return canvas;
}

let paintedGroundCache: HTMLCanvasElement | null = null;
let paintedGroundRequest: Promise<HTMLCanvasElement | null> | undefined;
function usePaintedGround() {
  const [canvas, setCanvas] = useState(paintedGroundCache);
  useEffect(() => {
    let active = true;
    paintedGroundRequest ??= loadLocalImage(sceneAssetUrl('/art/floof/painted-ground-material-v1.png')).promise.then(image => {
      if (!image) return null;
      try {
        const width = Math.min(1024, image.naturalWidth), height = Math.round(width * image.naturalHeight / image.naturalWidth);
        const tile = document.createElement('canvas'); tile.width = width * 2; tile.height = height * 2;
        const ctx = tile.getContext('2d');
        if (!ctx) return null;
        // Four mirrored copies give the repeated tile identical paint at every edge.
        for (const [sx, sy] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) {
          ctx.save(); ctx.translate(sx < 0 ? width * 2 : 0, sy < 0 ? height * 2 : 0); ctx.scale(sx, sy);
          ctx.drawImage(image, 0, 0, width, height); ctx.restore();
        }
        paintedGroundCache = tile; return tile;
      } catch { return null; }
    });
    void paintedGroundRequest.then(value => { if (active) setCanvas(value); });
    return () => { active = false; };
  }, []);
  return canvas;
}

/** No animation loop: input can move through the same projection while the world stays still. */
export function FloofStatic({ pose, width, height, actor, lampOn, reading = false, trailEvents = [] }: StaticGardenProps) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const groundLayer = useMemo(() => document.createElement('canvas'), []);
  const art = useMemo(createFloofArt, []), floof = useMemo(createFloofCanvas, []);
  const brush = useMemo(createFloofBrushCanvas, []);
  const paintedLeaves = useFloofPaintedLeaves(), paintedGround = usePaintedGround();
  const leaves = useMemo(() => new Map(floofPlants.map(plant => [plant.tint, tinted(art.leaf, plant.tint)])), [art]);
  useEffect(() => {
    const node = canvas.current; if (!node) return;
    const context = node.getContext('2d'); if (!context) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    node.width = Math.round(width * dpr); node.height = Math.round(height * dpr);
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    const project = (x: number, y: number, z?: number) => depthProject(x, y, pose, width, height, z);
    context.fillStyle = css(groundColor(actor.x, actor.y)); context.fillRect(0, 0, width, height);

    // Keep the inexpensive perspective mesh, then soften only its pigment layer.
    // Brushwork and grounded objects are added afterwards at full clarity.
    const padding = 48, paintScale = .5;
    groundLayer.width = Math.ceil((width + padding * 2) * paintScale);
    groundLayer.height = Math.ceil((height + padding * 2) * paintScale);
    const ground = groundLayer.getContext('2d')!;
    ground.setTransform(paintScale, 0, 0, paintScale, padding * paintScale, padding * paintScale);
    ground.fillStyle = css(groundColor(actor.x, actor.y));
    ground.fillRect(-padding, -padding, width + padding * 2, height + padding * 2);
    const step = 105, x0 = Math.floor((pose.x - 3300) / step) * step, y0 = Math.floor((pose.y - 1900) / step) * step;
    const columns = 64, rows = 72;
    const vertices = Array.from({ length: rows + 1 }, (_, row) => Array.from({ length: columns + 1 }, (_, column) => project(x0 + column * step, y0 + row * step)));
    for (let row = rows - 1; row >= 0; row--) for (let column = 0; column < columns; column++) {
      const a = vertices[row][column], b = vertices[row][column + 1], c = vertices[row + 1][column + 1], d = vertices[row + 1][column];
      if (Math.max(a.x, b.x, c.x, d.x) < -padding || Math.min(a.x, b.x, c.x, d.x) > width + padding || Math.max(a.y, b.y, c.y, d.y) < -padding || Math.min(a.y, b.y, c.y, d.y) > height + padding) continue;
      ground.fillStyle = css(groundColor(x0 + (column + .5) * step, y0 + (row + .5) * step));
      ground.beginPath(); ground.moveTo(a.x, a.y); ground.lineTo(b.x, b.y); ground.lineTo(c.x, c.y); ground.lineTo(d.x, d.y); ground.closePath(); ground.fill();
      ground.strokeStyle = ground.fillStyle; ground.lineWidth = 1.2; ground.stroke();
    }
    context.save(); context.filter = `blur(${18 * dpr}px)`;
    context.drawImage(groundLayer, -padding, -padding, width + padding * 2, height + padding * 2);
    context.restore();
    const at = project(actor.x, actor.y), origin = project(0, 0, 0);
    const pattern = context.createPattern(paintedGround ?? brush, 'repeat');
    if (pattern) {
      const scaleX = paintedGround ? 4920 / paintedGround.width : 1.5;
      const scaleY = paintedGround ? 3280 / paintedGround.height * .789 : 1.1;
      pattern.setTransform(new DOMMatrix().translate(origin.x, origin.y).scale(at.scale * scaleX, at.scale * scaleY));
      context.save(); context.globalCompositeOperation = 'soft-light'; context.globalAlpha = paintedGround ? .22 : .40;
      context.fillStyle = pattern; context.fillRect(0, 0, width, height); context.restore();
    }

    type DrawItem = { depth: number; draw: () => void };
    const items: DrawItem[] = [];
    const sprite = (image: HTMLCanvasElement, x: number, y: number, w: number, h: number, foot = .96, alpha = 1, flip = false, lift = 0) => {
      const point = project(x, y, terrainHeight(x, y) + 3 + lift), dw = w * point.scale, dh = h * point.scale;
      if (point.depth < 100 || point.x + dw / 2 < 0 || point.x - dw / 2 > width || point.y + dh * (1 - foot) < 0 || point.y - dh * foot > height) return;
      items.push({ depth: point.depth, draw: () => { context.save(); context.globalAlpha = alpha; context.translate(point.x, point.y); context.scale(flip ? -1 : 1, 1); context.drawImage(image, -dw / 2, -dh * foot, dw, dh); context.restore(); } });
    };
    const shadow = (x: number, y: number, size: number, opacity = .20) => {
      const p = project(x, y, terrainHeight(x, y) + 2), radius = size * p.scale;
      context.save(); context.translate(p.x, p.y); context.scale(1, .52);
      const gradient = context.createRadialGradient(0, 0, 1, 0, 0, radius);
      gradient.addColorStop(0, `rgba(61,85,92,${opacity})`); gradient.addColorStop(1, 'rgba(61,85,92,0)');
      context.fillStyle = gradient; context.fillRect(-radius, -radius, radius * 2, radius * 2); context.restore();
    };
    floofPlants.forEach(plant => {
      if (Math.hypot(plant.x - actor.x, plant.y - actor.y) > 3300 || plant.y < actor.y - 1650) return;
      shadow(plant.x, plant.y, plant.w * .35, plant.small ? .08 : .17);
      const leaf = !plant.small && paintedLeaves ? paintedLeaves[plant.paint ?? 'sage'] : leaves.get(plant.tint)!;
      sprite(leaf, plant.x, plant.y, plant.w, plant.h, .96, 1, plant.flip);
    });
    const memory = createTrailState(actor, trailEvents);
    trailFlowerOffsets.forEach(([dx, dy, size]) => sprite(art.flower, trailSites.flower.x + dx, trailSites.flower.y + dy, 104 * size * (memory.flowerOpen ? 1 : .62), 156 * size));
    trailSites.passages.forEach((point, i) => {
      if (trailPassageBloom(memory, i)) sprite(art.flower, point.x + (i % 2 ? -46 : 46), point.y + 7, 104 * .25, 156 * .25);
    });
    if (guideVisible(memory)) {
      const guide = guidePosition(memory), p = project(guide.x, guide.y, terrainHeight(guide.x, guide.y) + 58 + guide.lift);
      items.push({ depth: p.depth, draw: () => {
        context.save(); context.translate(p.x, p.y); context.scale(p.scale, p.scale); context.fillStyle = '#fff2d8';
        context.beginPath(); context.moveTo(0, 0); context.bezierCurveTo(-28, -26, -29, -2, -4, 5); context.bezierCurveTo(-17, 20, -2, 14, 0, 5); context.bezierCurveTo(13, 21, 22, 12, 5, 3); context.bezierCurveTo(30, -8, 21, -29, 0, 0); context.fill(); context.restore();
      } });
    }
    objects.forEach(object => {
      const alpha = landmarkReveal(object, actor, reading); if (alpha < .005) return;
      shadow(object.x, object.y, object.width * .5, .17 * alpha);
      if (object.id === 'puzzle' && (lampOn || memory.lanternAwake)) {
        const p = project(object.x, object.y), r = 230 * p.scale;
        const glow = context.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
        glow.addColorStop(0, 'rgba(255,216,137,.22)'); glow.addColorStop(1, 'rgba(255,216,137,0)');
        context.fillStyle = glow; context.fillRect(p.x - r, p.y - r, r * 2, r * 2);
      }
      sprite(art[object.id === 'puzzle' ? 'lantern' : object.id === 'music' ? 'flower' : 'door'], object.x, object.y, object.width, object.height, .96, alpha);
    });
    shadow(actor.x + 7, actor.y - 4, 70, .27);
    // WebGL uses the same 174-unit sheet: its painted core is ~120 units and
    // the rest is transparent fur margin. Keep both the size and .359 centre.
    sprite(floof, actor.x, actor.y, 174, 174, .859);
    items.sort((a, b) => b.depth - a.depth).forEach(item => item.draw());

    // Fixed, sparse airborne pigment preserves the atmosphere without running an animation loop.
    for (let i = 0; i < 12; i++) {
      const x = Math.floor(pose.x / 2200) * 2200 - 1000 + random(i + 23) * 3600;
      const y = Math.floor(pose.y / 2200) * 2200 - 1000 + random(i + 91) * 3600;
      const p = project(x, y, terrainHeight(x, y) + 70 + random(i + 41) * 200);
      if (p.x < 0 || p.x > width || p.y < 0 || p.y > height) continue;
      context.fillStyle = 'rgba(255,246,217,.42)'; context.beginPath(); context.arc(p.x, p.y, Math.max(.6, 2 * p.scale), 0, Math.PI * 2); context.fill();
    }
  }, [pose, width, height, actor, lampOn, reading, trailEvents, art, floof, brush, leaves, paintedLeaves, paintedGround, groundLayer]);
  return <canvas ref={canvas} className="static-garden floof-static" aria-hidden="true" style={{ position: 'absolute', inset: 0, width, height, pointerEvents: 'none' }}/>;
}
