import { moonClearingField } from './moonClearing';

/** Shared late-garden washes: quiet paper beneath the birds, cooler pigment by the small door. */
export const hillMoonPalette = {
  hill: [.674, .658, .704], moon: [.488, .566, .688],
  hillStrength: .34, moonStrength: .40,
};
export type HillMoonField = { hill: number; moon: number; calm: number };
const smooth = (value: number) => {
  const t = Math.max(0, Math.min(1, value));
  return t * t * (3 - 2 * t);
};

/** Soft finite support leaves the earlier clearings untouched, with no hard colour boundary. */
export function hillMoonField(x: number, y: number): HillMoonField {
  if (!Number.isFinite(x) || !Number.isFinite(y)) return { hill: 0, moon: 0, calm: 0 };
  const wash = (cx: number, cy: number, rx: number, ry: number, falloff = 2) => {
    const radius2 = ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2;
    return Math.exp(-falloff * radius2) * (1 - smooth((Math.sqrt(radius2) - 1.3) / .5));
  };
  const hill = wash(1000, 6800, 900, 700);
  const moon = wash(-200, 8500, 1050, 800);
  // A slightly wider quiet layer keeps the tiny birds and doorway readable
  // while retaining the underlying broad grass colour and terrain shading.
  const hillQuiet = wash(1000, 6800, 900, 700, 1.25);
  const moonQuiet = wash(-200, 8500, 1050, 800, 1.25);
  const passage = wash(580, 7720, 800, 570);
  return { hill, moon, calm: Math.max(hillQuiet * .66, moonQuiet * .76, passage * .28) };
}

export function hillMoonTint(color: number[], field: HillMoonField) {
  return color.map((value, i) => {
    const hill = value + (hillMoonPalette.hill[i] - value) * field.hill * hillMoonPalette.hillStrength;
    return hill + (hillMoonPalette.moon[i] - hill) * field.moon * hillMoonPalette.moonStrength;
  });
}

/** Only the final clearing receives this restrained blue-grey/sage underpainting. */
export const moonClearingPalette = {
  sage: [.575, .638, .605],
  bank: [.405, .500, .590],
  shadow: [.355, .438, .514],
  ivory: [.879, .898, .883],
  groundStrength: .42,
  bankStrength: .90,
  shadowStrength: .24,
  lightStrength: .22,
};

/** A softly wandering wash edge stays inside the final field, with no hard oval of flat paint. */
export function moonClearingPaintCoverage(x: number, y: number) {
  const coverage = moonClearingField(x, y, 0).coverage;
  const warped = moonClearingField(x + Math.sin(y * .0021) * 145 + Math.sin(x * .0034) * 50,
    y + Math.sin(x * .0018 + y * .0011) * 105, 0).coverage;
  return coverage * (.52 + .48 * warped);
}

/** Broad landform values and one softly broken edge replace the all-over texture. */
export function moonClearingGroundShape(x: number, y: number) {
  if (!Number.isFinite(x) || !Number.isFinite(y)) return { bank: 0, edge: 0 };
  const slope = (x + 200) * .62 + (y - 8340) * .78 + Math.sin((x + 200) * .0018) * 68;
  return {
    bank: 1 - smooth((slope + 230) / 590),
    edge: Math.exp(-(((slope + 70) / 95) ** 2)),
  };
}

/** Keep roughly one quarter of the original pigment, with a little more at the slope edge. */
export function moonClearingTextureCalm(x: number, y: number) {
  return moonClearingPaintCoverage(x, y) * (.74 - moonClearingGroundShape(x, y).edge * .08);
}

/** CPU counterpart of the ground shader, also used by the reduced-motion renderer. */
export function moonClearingTint(color: number[], x: number, y: number, phase = 0) {
  const field = moonClearingField(x, y, phase);
  if (!field.coverage) return color;
  const shape = moonClearingGroundShape(x, y), palette = moonClearingPalette;
  const paintCoverage = moonClearingPaintCoverage(x, y);
  return color.map((value, i) => {
    const bank = palette.sage[i] + (palette.bank[i] - palette.sage[i]) * shape.bank * palette.bankStrength;
    const ground = value + (bank - value) * paintCoverage * palette.groundStrength;
    const shadow = ground + (palette.shadow[i] - ground) * field.shadow * palette.shadowStrength;
    return shadow + (palette.ivory[i] - shadow) * field.light * palette.lightStrength;
  });
}
