import type { JourneyPose } from './journey';

export type MeadowPoint = { x: number; y: number };
export type MeadowGuidance = { active: boolean; heading: MeadowPoint; strength: number };
export const SHARED_RABBIT_FOOT_OFFSET = 220;
export const MEADOW_SPEED = 240;
export const MEADOW_HOLD_DELAY_MS = 90;
export const MEADOW_POINTER_DEAD_ZONE = 14;
export const MEADOW_POINTER_FULL_SPEED = 210;
export const MEADOW_ACCELERATION_TIME = .38;
export const MEADOW_TURN_RATE = 4.8;
export const MEADOW_FOLLOW_TIME = .52;
export const MEADOW_CAMERA_FREE_ZONE = 76;
export const MEADOW_MAX_CAMERA_LEAD = 240;
export const MEADOW_DIRECTIONAL_LEAD = 190;
const clamp = (value:number,min:number,max:number) => Math.max(min,Math.min(max,value));
const smooth = (value:number) => {const t=clamp(value,0,1);return t*t*(3-2*t);};

/** Blank ground responds visually at once; objects retain their short-click behaviour. */
export function meadowPressIntent(elapsedMs:number,worldObject:boolean,moved:boolean) {
 const anticipating=!worldObject||moved;
 return {anticipating,walking:anticipating&&elapsedMs>=MEADOW_HOLD_DELAY_MS};
}

export function meadowScreenFoot(width:number,height:number,scale:number):MeadowPoint {
 return {x:width/2,y:height/2+SHARED_RABBIT_FOOT_OFFSET*scale};
}
/** Nearby pointers allow a careful walk; the outer range asks for a small run. */
export function meadowVelocity(pointer:MeadowPoint|null,foot:MeadowPoint):MeadowPoint {
 if(!pointer)return {x:0,y:0};
 const dx=pointer.x-foot.x,dy=foot.y-pointer.y,distance=Math.hypot(dx,dy);
 if(!Number.isFinite(distance)||distance<=MEADOW_POINTER_DEAD_ZONE)return {x:0,y:0};
 const fraction=clamp((distance-MEADOW_POINTER_DEAD_ZONE)/(MEADOW_POINTER_FULL_SPEED-MEADOW_POINTER_DEAD_ZONE),0,1);
 const speed=MEADOW_SPEED*(.22*fraction+.78*smooth(fraction));
 return {x:dx/distance*speed,y:dy/distance*speed};
}
export function advanceMeadow(current:JourneyPose,velocity:MeadowPoint,deltaSeconds:number,active=true):JourneyPose {
 if(!active||!Number.isFinite(deltaSeconds)||deltaSeconds<=0)return current;
 const dt=Math.min(deltaSeconds,.05),vx=Number.isFinite(velocity.x)?velocity.x:0,vy=Number.isFinite(velocity.y)?velocity.y:0;
 if(!vx&&!vy)return current;
 return {...current,x:current.x+vx*dt,y:current.y+vy*dt};
}
/** Convert the desired screen direction into the actual foreshortened terrain plane. */
export function groundVelocity(pointer:MeadowPoint|null,foot:MeadowPoint,axisX:MeadowPoint,axisY:MeadowPoint):MeadowPoint {
 const screen=meadowVelocity(pointer,foot),speed=Math.hypot(screen.x,screen.y);
 if(!speed)return {x:0,y:0};
 const ax=axisX.x-foot.x,ay=axisX.y-foot.y,bx=axisY.x-foot.x,by=axisY.y-foot.y;
 const determinant=ax*by-ay*bx;
 if(!Number.isFinite(determinant)||Math.abs(determinant)<1e-8)return screen;
 const x=(screen.x*by+screen.y*bx)/determinant,y=(-ax*screen.y-ay*screen.x)/determinant,length=Math.hypot(x,y);
 return length>0?{x:x/length*speed,y:y/length*speed}:{x:0,y:0};
}
export type MeadowLocomotion={heading:MeadowPoint;speed:number;velocity:MeadowPoint};
export function steerMeadow(heading:MeadowPoint,speed:number,target:MeadowPoint,deltaSeconds:number):MeadowLocomotion {
 const dt=clamp(Number.isFinite(deltaSeconds)?deltaSeconds:0,0,.05),desiredSpeed=Math.min(MEADOW_SPEED,Math.hypot(target.x,target.y));
 if(!Number.isFinite(desiredSpeed))return {heading,speed:0,velocity:{x:0,y:0}};
 if(desiredSpeed<.001){
  const nextSpeed=Math.max(0,speed-(MEADOW_SPEED/.24)*dt);
  return {heading,speed:nextSpeed,velocity:{x:heading.x*nextSpeed,y:heading.y*nextSpeed}};
 }
 const from=Math.atan2(heading.y,heading.x),to=Math.atan2(target.y,target.x),turn=Math.atan2(Math.sin(to-from),Math.cos(to-from));
 const turnRate=MEADOW_TURN_RATE+2.6*(1-clamp(speed/MEADOW_SPEED,0,1));
 const step=clamp(turn,-turnRate*dt,turnRate*dt),angle=from+step,nextHeading={x:Math.cos(angle),y:Math.sin(angle)};
 // Ordinary turns keep a stride. A reversal eases into a tight, slow turn,
 // rather than abruptly resetting the gait at a 75-degree threshold.
 const remaining=turn-step;
 const alignment=.16+.84*smooth((Math.cos(remaining)+.45)/1.45);
 const targetSpeed=desiredSpeed*alignment,acceleration=MEADOW_SPEED/MEADOW_ACCELERATION_TIME;
 const nextSpeed=targetSpeed>speed?Math.min(targetSpeed,Math.max(0,speed)+acceleration*dt):Math.max(targetSpeed,speed-acceleration*1.35*dt);
 return {heading:nextHeading,speed:nextSpeed,velocity:{x:nextHeading.x*nextSpeed,y:nextHeading.y*nextSpeed}};
}
/** Common keyboard input for the same walking integrator as the mouse. */
export function keyboardMeadowVelocity(keys:ReadonlySet<string>):MeadowPoint {
 const x=Number(keys.has('ArrowRight')||keys.has('KeyD'))-Number(keys.has('ArrowLeft')||keys.has('KeyA'));
 const y=Number(keys.has('ArrowUp')||keys.has('KeyW')||keys.has('PageUp'))-Number(keys.has('ArrowDown')||keys.has('KeyS')||keys.has('PageDown'));
 const length=Math.hypot(x,y);return length?{x:x/length*MEADOW_SPEED*.82,y:y/length*MEADOW_SPEED*.82}:{x:0,y:0};
}
/** Wheel events request a bounded velocity burst, never a direct change of coordinates. */
export function wheelMeadowVelocity(dx:number,dy:number):MeadowPoint {
 if(!Number.isFinite(dx)||!Number.isFinite(dy))return {x:0,y:0};
 const length=Math.hypot(dx,dy);if(length<.1)return {x:0,y:0};
 const speed=Math.min(MEADOW_SPEED,36+length*2.6);return {x:dx/length*speed,y:dy/length*speed};
}
/** A short wheel gesture must survive its turn before spending the walking part. */
export function wheelMeadowDuration(heading:MeadowPoint,velocity:MeadowPoint):number {
 if(!Number.isFinite(velocity.x)||!Number.isFinite(velocity.y)||Math.hypot(velocity.x,velocity.y)<.001)return 0;
 const from=Math.atan2(heading.y,heading.x),to=Math.atan2(velocity.y,velocity.x);
 const turn=Math.abs(Math.atan2(Math.sin(to-from),Math.cos(to-from)));
 return Math.min(850,260+turn/MEADOW_TURN_RATE*1000);
}
/** Smooth the framing direction independently of body steering, including a planted turn. */
export function advanceMeadowLook(previous:MeadowPoint,heading:MeadowPoint,speed:number,deltaSeconds:number,active=true):MeadowPoint {
 if(!active||!Number.isFinite(deltaSeconds)||deltaSeconds<=0)return previous;
 const distance=MEADOW_DIRECTIONAL_LEAD*smooth(speed/MEADOW_SPEED),amount=1-Math.exp(-Math.min(deltaSeconds,.05)/.34);
 return {x:previous.x+(heading.x*distance-previous.x)*amount,y:previous.y+(heading.y*distance-previous.y)*amount};
}
/** Directional framing and a quiet free zone; release deliberately never advances this. */
export function followMeadowCamera(camera:JourneyPose,actor:MeadowPoint,deltaSeconds:number,active=true,motion?:Pick<MeadowLocomotion,'heading'|'speed'>&{lead?:MeadowPoint}):JourneyPose {
 if(!active||!Number.isFinite(deltaSeconds)||deltaSeconds<=0)return camera;
 const dt=Math.min(.05,deltaSeconds),base={x:actor.x,y:actor.y+SHARED_RABBIT_FOOT_OFFSET};
 const look=motion?MEADOW_DIRECTIONAL_LEAD*smooth(motion.speed/MEADOW_SPEED):0;
 const lead=motion?.lead??{x:(motion?.heading.x??0)*look,y:(motion?.heading.y??0)*look};
 const target={x:base.x+lead.x,y:base.y+lead.y};
 const dx=target.x-camera.x,dy=target.y-camera.y,distance=Math.hypot(dx,dy);
 let x=camera.x,y=camera.y;
 if(distance>MEADOW_CAMERA_FREE_ZONE){
  const excess=distance-MEADOW_CAMERA_FREE_ZONE,amount=1-Math.exp(-dt/MEADOW_FOLLOW_TIME);
  x+=dx/distance*excess*amount;y+=dy/distance*excess*amount;
 }
 const bx=base.x-x,by=base.y-y,lag=Math.hypot(bx,by);
 if(lag>MEADOW_MAX_CAMERA_LEAD){x=base.x-bx/lag*MEADOW_MAX_CAMERA_LEAD;y=base.y-by/lag*MEADOW_MAX_CAMERA_LEAD;}
 return x===camera.x&&y===camera.y?camera:{...camera,x,y};
}
