import { useEffect, useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { CanvasTexture, DoubleSide, Group, Mesh, MeshBasicMaterial, PerspectiveCamera, SRGBColorSpace, Texture } from 'three';
import type { ArtKey } from '../config/art';
import type { GardenProps } from './GardenCanvas';
import { BILLBOARD_TILT, depthCamera, terrainHeight, landmarkReveal } from './depthWorld';
import { objects } from './world';
import { RabbitCompanion } from './RabbitCompanion';
import { FloofTerrain } from './FloofTerrain';
import { FloofScenery } from './FloofScenery';
import { createFloofArt } from './floofSceneryArt';
import { TrailAwakening } from './TrailAwakening';
import { AtlasEncounters } from './AtlasEncounters';
import { GardenAir } from './GardenAir';
import { advanceGardenClock, gardenWind } from './gardenWind';
import type { GardenClock } from './gardenWind';
import type { MeadowPoint } from './meadowMotion';

type Textures = Partial<Record<ArtKey, Texture>>;
function Sprite({ texture, w, h, opacity = 1, color = '#ffffff', position }: {
  texture?: Texture; w: number; h: number; opacity?: number; color?: string; position?: [number, number, number];
}) {
  return texture ? <mesh position={position}><planeGeometry args={[w, h]}/><meshBasicMaterial map={texture} transparent opacity={opacity} color={color} depthWrite={false} alphaTest={.025} side={DoubleSide} toneMapped={false}/></mesh> : null;
}
function Landmark({ object, textures, actor, reading, lampOn, bloom, awake, clock }: {
  object: typeof objects[number]; textures: Textures; actor: MeadowPoint; reading: boolean; lampOn: boolean; bloom: number; awake: boolean; clock: GardenClock;
}) {
  const plant = useRef<Group>(null!), glow = useRef<Mesh>(null!), brightness = useRef(0), pulse = useRef(0), lastBloom = useRef(bloom);
  const reveal = landmarkReveal(object, actor, reading);
  useFrame((_frame, delta) => {
    if (reading) return;
    const dt = Math.min(delta, .05);
    if (bloom !== lastBloom.current) { pulse.current = 1; lastBloom.current = bloom; }
    pulse.current *= Math.exp(-dt * 2.5);
    const wind = gardenWind(clock.current, object.x, object.y, .2);
    plant.current.rotation.z = object.id === 'music' ? wind.lean * .025 + Math.sin(pulse.current * 12) * pulse.current * .06 : 0;
    brightness.current += ((lampOn || awake ? .5 : .12) - brightness.current) * (1 - Math.exp(-dt * 2));
    if (glow.current) (glow.current.material as MeshBasicMaterial).opacity = brightness.current * reveal * (1 + Math.sin(clock.current * .8) * .035);
  });
  return <group visible={reveal > .01} position={[object.x, object.y, terrainHeight(object.x, object.y) + 3]}>
    <Sprite texture={textures.contact} w={object.width * .75} h={38} opacity={.24 * reveal} color="#617476"/>
    {object.id === 'puzzle' && <Sprite texture={textures.glow} w={360} h={250} opacity={(awake || lampOn ? .22 : .04) * reveal} color="#f6dfa3" position={[0, 25, 1]}/>}
    <group rotation={[BILLBOARD_TILT, 0, 0]}>
      <group ref={plant}><Sprite texture={textures[object.art]} w={object.width} h={object.height} opacity={reveal} position={[0, object.height * .46, 0]}/></group>
      {object.id === 'puzzle' && <mesh ref={glow} position={[0, object.height * .61, 2]}><planeGeometry args={[150, 150]}/><meshBasicMaterial map={textures.glow} color="#ffe5a9" transparent opacity={.12} depthWrite={false}/></mesh>}
    </group>
  </group>;
}
/** One continuous painted space from the invitation onward. */
export function ExplorationScene(props: GardenProps) {
  const { images, pose, actor, moving, heading, reading, onReady } = props;
  const { camera, size, gl } = useThree(), ready = useRef(false), clock = useRef(0);
  useFrame((_frame, dt) => { clock.current = advanceGardenClock(clock.current, dt, reading); }, -1);
  const textures = useMemo(() => {
    const result: Textures = {};
    const painted = createFloofArt();
    for (const [key, image] of Object.entries(images)) {
      if (key === 'flower' || key === 'lantern' || key === 'door') continue;
      const t = new Texture(image); t.colorSpace = SRGBColorSpace; t.needsUpdate = true; result[key as ArtKey] = t;
    }
    for (const key of ['flower', 'lantern', 'door'] as const) {
      const t = new CanvasTexture(painted[key]); t.colorSpace = SRGBColorSpace; t.anisotropy = 4; result[key] = t;
    }
    return result;
  }, [images]);
  useEffect(() => () => Object.values(textures).forEach(t => t.dispose()), [textures]);
  useEffect(() => {
    const lose = (e: Event) => { e.preventDefault(); props.onFail(); };
    gl.domElement.addEventListener('webglcontextlost', lose);
    return () => gl.domElement.removeEventListener('webglcontextlost', lose);
  }, [gl, props.onFail]);
  useFrame(() => {
    const c = depthCamera(pose, size.width, size.height), cam = camera as PerspectiveCamera;
    cam.position.set(c.x, c.y, c.z); cam.up.set(0, 0, 1); cam.lookAt(c.x, c.targetY, c.targetZ);
    cam.fov = c.fov; cam.far = 18000; cam.updateProjectionMatrix();
    if (!ready.current) { ready.current = true; onReady(); }
  });
  return <>
    <FloofTerrain actor={actor} reading={reading} clock={clock}/>
    <FloofScenery actor={actor} moving={moving} heading={heading} reading={reading} clock={clock}/>
    {objects.map(object => <Landmark key={object.id} object={object} textures={textures} actor={actor} reading={reading} lampOn={props.lampOn} bloom={props.bloom} awake={props.trailEvents?.includes('trail-lantern-awake') ?? false} clock={clock}/>)}
    <TrailAwakening textures={textures} actor={actor} moving={moving} reading={reading} clock={clock} memories={props.trailEvents} onEvent={props.onWorldEvent}/>
    <GardenAir clock={clock} actor={actor} moving={moving} heading={heading} reading={reading}/>
    {actor.y > 1400 && <AtlasEncounters textures={textures} actor={actor} moving={moving} heading={heading} reading={reading} onEvent={props.onWorldEvent} pulse={props.atlasPulse}/>}
    <RabbitCompanion actor={actor} moving={moving} heading={heading} reading={reading} textures={textures} guidance={props.guidance}/>
  </>;
}
