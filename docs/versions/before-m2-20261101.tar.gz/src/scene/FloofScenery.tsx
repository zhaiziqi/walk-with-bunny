import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { CanvasTexture, DoubleSide, Group, MeshBasicMaterial, PlaneGeometry, SRGBColorSpace } from 'three';
import type { Texture } from 'three';
import { BILLBOARD_TILT, terrainHeight } from './depthWorld';
import { gardenWind } from './gardenWind';
import type { GardenClock } from './gardenWind';
import type { MeadowPoint } from './meadowMotion';
import { advanceLeafBend, canopyContact } from './plantResponse';
import { createFloofArt } from './floofSceneryArt';
import { useFloofPaintedLeaves } from './floofPaintedLeaves';

export { createFloofArt } from './floofSceneryArt';
export type FloofPlant = { x: number; y: number; w: number; h: number; tint: string; small?: boolean; flip?: boolean; paint?: 'blue' | 'sage' };
export const floofPlants: FloofPlant[] = [
  { x: -840, y: -2350, w: 1200, h: 800, tint: '#476b89', paint: 'blue' },
  { x: -540, y: -590, w: 340, h: 245, tint: '#77978d', flip: true },
  { x: -1180, y: 280, w: 540, h: 420, tint: '#587d91', flip: true },
  { x: 440, y: 650, w: 430, h: 300, tint: '#7f9d91' },
  { x: 1550, y: 1750, w: 520, h: 350, tint: '#758d96', flip: true },
  { x: -650, y: 2110, w: 480, h: 330, tint: '#77988e' },
  { x: -1810, y: 3150, w: 650, h: 420, tint: '#567989' },
  { x: 100, y: 3550, w: 410, h: 360, tint: '#738e95', flip: true },
  { x: 1990, y: 4280, w: 540, h: 410, tint: '#5d788b' },
  { x: -1810, y: 5300, w: 570, h: 420, tint: '#627b92', flip: true },
  { x: 130, y: 5630, w: 420, h: 270, tint: '#8296a1' },
  { x: 1660, y: 6720, w: 540, h: 380, tint: '#697e99' },
  { x: -1030, y: 8020, w: 620, h: 470, tint: '#576e91', flip: true },
  { x: 670, y: 8780, w: 420, h: 310, tint: '#8091a8' },
  // Grounded small strokes form occasional clusters; they do not border the entire route.
  { x: 170, y: -2020, w: 64, h: 28, tint: '#94a98a', small: true },
  { x: 660, y: -1510, w: 85, h: 38, tint: '#9aad8b', small: true, flip: true },
  { x: 290, y: -1180, w: 55, h: 27, tint: '#95a581', small: true },
  { x: -150, y: -730, w: 68, h: 28, tint: '#91a68d', small: true },
  { x: -425, y: -130, w: 79, h: 31, tint: '#9aaf95', small: true, flip: true },
  { x: -840, y: 480, w: 58, h: 27, tint: '#97ad90', small: true },
];

type Props = { actor: MeadowPoint; heading: MeadowPoint; moving: boolean; reading: boolean; clock: GardenClock };

function contactArt() {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 128;
  const ctx = canvas.getContext('2d')!, gradient = ctx.createRadialGradient(64, 64, 2, 64, 64, 63);
  gradient.addColorStop(0, 'rgba(55,77,79,.33)'); gradient.addColorStop(.5, 'rgba(55,77,79,.15)'); gradient.addColorStop(1, 'rgba(55,77,79,0)');
  ctx.fillStyle = gradient; ctx.fillRect(0, 0, 128, 128);
  return new CanvasTexture(canvas);
}

function PaintedPlant({ plant, texture, painted, shadow, actor, heading, moving, reading, clock }: Props & { plant: FloofPlant; texture: Texture; painted: boolean; shadow: Texture }) {
  const root = useRef<Group>(null!);
  const previous = useRef({ ...actor }), bend = useRef({ value: 0, velocity: 0 });
  const geometry = useMemo(() => new PlaneGeometry(plant.w, plant.h, 12, 16), [plant.w, plant.h]);
  const original = useMemo(() => new Float32Array(geometry.attributes.position.array), [geometry]);
  const material = useMemo(() => new MeshBasicMaterial({ map: texture, color: painted ? '#ffffff' : plant.tint, transparent: true,
    alphaTest: painted ? .26 : .20, depthWrite: true, side: DoubleSide, toneMapped: false }), [texture, plant.tint, painted]);
  useEffect(() => () => { geometry.dispose(); material.dispose(); }, [geometry, material]);
  useFrame((_state, delta) => {
    const distance = Math.hypot(plant.x - actor.x, plant.y - actor.y);
    root.current.visible = distance < 3300 && plant.y > actor.y - 1650;
    if (reading) { previous.current = { ...actor }; return; }
    if (!root.current.visible) { previous.current = { ...actor }; return; }
    const dt = Math.min(delta, .05), wind = gardenWind(clock.current, plant.x, plant.y, .13);
    const contact = canopyContact(plant, plant.w, plant.h, previous.current, actor);
    const away = plant.x < actor.x ? -1 : 1;
    bend.current = advanceLeafBend(bend.current, contact * (away * .23 + (moving ? heading.x * .16 : 0)), dt);
    previous.current = { ...actor };
    const position = geometry.attributes.position;
    for (let i = 0; i < position.count; i++) {
      const x = original[i * 3], y = original[i * 3 + 1];
      const height = Math.max(0, (y / plant.h + .5 - .055) / .945);
      const flex = height * height, side = x / plant.w;
      const flutter = Math.sin(clock.current * 1.25 + side * 7.1 + height * 3) * wind.flutter;
      position.setX(i, x + flex * plant.h * (wind.lean * .024 + flutter * .012 + bend.current.value * .17));
      position.setY(i, y - flex * Math.abs(bend.current.value) * plant.h * .025);
    }
    position.needsUpdate = true;
  });
  return <group ref={root} position={[plant.x, plant.y, terrainHeight(plant.x, plant.y) + 2]}>
    <mesh position={[0, 1, 0]}><planeGeometry args={[plant.w * .65, Math.max(25, plant.w * .21)]}/><meshBasicMaterial map={shadow} transparent opacity={plant.small ? .25 : .55} depthWrite={false} toneMapped={false}/></mesh>
    <group rotation={[BILLBOARD_TILT, 0, 0]} scale={[plant.flip ? -1 : 1, 1, 1]}>
      <mesh geometry={geometry} material={material} position={[0, plant.h * .46, 0]}/>
    </group>
  </group>;
}

/** Sparse painted silhouettes make distinct overlapping clearings, without a wall of trees. */
export function FloofScenery(props: Props) {
  const painted = useFloofPaintedLeaves();
  const texture = useMemo(() => {
    const texture = new CanvasTexture(createFloofArt().leaf); texture.colorSpace = SRGBColorSpace; texture.anisotropy = 4; return texture;
  }, []);
  const paintedTextures = useMemo(() => {
    if (!painted) return null;
    const make = (canvas: HTMLCanvasElement) => {
      const texture = new CanvasTexture(canvas); texture.colorSpace = SRGBColorSpace; texture.anisotropy = 4; return texture;
    };
    return { blue: make(painted.blue), sage: make(painted.sage) };
  }, [painted]);
  const shadow = useMemo(contactArt, []);
  useEffect(() => () => { texture.dispose(); shadow.dispose(); }, [texture, shadow]);
  useEffect(() => () => { paintedTextures?.blue.dispose(); paintedTextures?.sage.dispose(); }, [paintedTextures]);
  return <group name="painted-floof-scenery">{floofPlants.map((plant, i) => <PaintedPlant key={i} plant={plant}
    texture={!plant.small && paintedTextures ? paintedTextures[plant.paint ?? 'sage'] : texture}
    painted={!plant.small && !!paintedTextures} shadow={shadow} {...props}/>)}</group>;
}
