import { paths, regions } from './gardenAtlas';
import type { GardenRegion, RegionId } from './gardenAtlas';
import type { MeadowPoint } from './meadowMotion';

/** A memory of places already seen. An undiscovered destination is never a shortcut. */
export function GardenMap({actor,visited,travel,onClose}:{actor:MeadowPoint;visited:RegionId[];travel:(region:GardenRegion)=>void;onClose:()=>void}) {
 const known=regions.filter(region=>visited.includes(region.id));
 const minY=Math.min(actor.y,...known.map(r=>r.y))-550,maxY=Math.max(actor.y,...known.map(r=>r.y))+850;
 const minX=Math.min(actor.x,...known.map(r=>r.x))-650,maxX=Math.max(actor.x,...known.map(r=>r.x))+650;
 const position=(x:number,y:number)=>({x:26+(y-minY)/(maxY-minY)*468,y:24+(x-minX)/(maxX-minX)*136});
 const rabbit=position(actor.x,actor.y);
 return <nav className="garden-map" aria-label="A little map">
  <div className="map-caption"><span>A little map <small>Places you remember</small></span><button aria-label="Close map" onClick={onClose}>×</button></div>
  <svg viewBox="0 0 520 190" aria-hidden="true">
   <defs><linearGradient id="unseen-path"><stop offset="0" stopColor="#a2a899" stopOpacity=".55"/><stop offset="1" stopColor="#a2a899" stopOpacity="0"/></linearGradient></defs>
   {paths.filter(path=>visited.includes(path.from)||visited.includes(path.to)).map(path=>{
    const complete=visited.includes(path.from)&&visited.includes(path.to);
    const ordered=visited.includes(path.from)?path.points:[...path.points].reverse();
    const points=complete?ordered:ordered.slice(0,Math.max(3,Math.round(ordered.length*.28)));
    return <polyline key={path.id} points={points.map(p=>{const a=position(p.x,p.y);return `${a.x},${a.y}`;}).join(' ')} fill="none" stroke={complete?'#a2a899':'url(#unseen-path)'} strokeWidth={complete?1.7:1.2} strokeDasharray={complete?undefined:'2 5'} opacity=".7"/>;
   })}
   {known.map(region=>{const p=position(region.x,region.y);return <circle key={region.id} cx={p.x} cy={p.y} r="5" fill={region.color} stroke="#88988d" strokeWidth=".8"/>;})}
   <circle cx={rabbit.x} cy={rabbit.y} r="7" fill="none" stroke="#986d77" strokeWidth="1.5"/>
   <circle cx={rabbit.x} cy={rabbit.y} r="2" fill="#986d77"/>
  </svg>
  <div className="map-places">{known.map(region=><button key={region.id} onClick={()=>travel(region)}><small>return to</small>{region.name}</button>)}</div>
  {known.length<regions.length&&<p className="map-unseen">There is more beyond the mist.</p>}
 </nav>;
}
