# 秘密花园生日网站 · A 方案

当前完成 **M0、M1 桌面美术样片，以及 M2 信号谜题**。采用用户确认的俯视水粉草坡、独立叶片和奶白绒团；原始交接包、参考图片与视频、历史素材全部保留。网站工程位于当前项目根目录。

## 打开预览

- 花园：[http://localhost:5173/#garden](http://localhost:5173/#garden)
- 直接体验第一关：[http://localhost:5173/#puzzle](http://localhost:5173/#puzzle)

本机服务未运行时，在项目目录执行：

```sh
sh scripts/project.sh dev
```

保持服务终端运行；本机重启后需重新启动。这是本地预览，尚未部署。

电脑上移动鼠标／触摸板指针即可引导绒团，无须按住；方向键、WASD 和滚轮也可行走。停下等待、靠近花灯、点击打开内容。阅读期间角色与环境暂停，关闭后恢复角色、镜头、朝向和缩放。声音默认关闭，可主动开启；减少动态使用静态画面与相同内容控件。

最新修正：在同帧驱动基础上增加连续转向和有限停步曲线，让角色与镜头一起收势；原停步时限不延长。用户已确认上一版连续行走顺滑，本轮转向与停步手感仍待复测。9 项转向／停步检查、26 项指针检查、7 项身体检查、类型检查和构建通过，见 [TURN_STOP_QA.md](docs/TURN_STOP_QA.md)。已有页面请刷新以加载 `soft-turn-stop-v3`；上一轮帧同步记录见 [SMOOTH_MOTION_QA.md](docs/SMOOTH_MOTION_QA.md)。

## 本轮 M2

- 信号 A、B 依次解码。四个输出初始为空，验证灯位后才进入数字输入；错误保留答案。
- 一组完成保存两位片段；两组都完成才出现密码卡和顶部 `My password card`。
- 提示逐层展开。完整示范需要主动选择，再明确确认才能替当前组完成，不会自动填写另一组。
- 保存填写中的灯位、数字和完成状态。刷新继续；存储不可用时可在当前页面内完成。
- 音乐过场为可选内容；谜题、音乐、礼物状态互相独立。页面文案和无障碍标签为英文。
- 原美术、地点、环境反馈及固定谜题规则保持。音乐抽取、真实曲目和礼物揭晓属于后续 M3/M4，当前仍明确显示预览状态。

检查记录和真实截图见 [M2_SIGNAL_QA.md](docs/M2_SIGNAL_QA.md)。桌面浏览器实际走通两组谜题、提示、刷新恢复、静态替代、键盘焦点、关闭与历史导航；18 项谜题/存储检查、22 项指针回归、配置检查、类型检查和生产构建通过。Three 分包仍有体积提示。

本轮没有重新验证实体触摸板手感、音频听感、FPS、手机或部署，也没有重新宣称整段自然行走节奏达标。M1 自然行走和返程的历史证据见 [FLOOF_CLEARING_QA.md](docs/FLOOF_CLEARING_QA.md)；背景方向获认可不代表整个美术已最终验收。

## 检查、构建与安装

```sh
sh scripts/project.sh check
sh scripts/project.sh build
sh scripts/project.sh preview
```

`preview` 提供已构建版本，默认 http://localhost:4173/。不要直接双击 dist/index.html。

本机使用 Node **24.22.1**、pnpm **11.25.0**。React 19、TypeScript、Vite、React Three Fiber、Three.js、GSAP 的精确版本以 pnpm-lock.yaml 为准。另一个常规 Node 22.12+ 或 24 环境可运行：

```sh
pnpm install --frozen-lockfile
pnpm dev
```

本机没有全局 Node，project.sh 自动寻找 Codex 运行时，并跳过不能加载第三方原生模块的 cua_node。直接运行确定性检查使用本机 Node 24 路径：

```sh
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/check-puzzle-progress.mjs
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/check-content.mjs
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/check-pointer-guidance.mjs
```

需要重新安装依赖时：

```sh
PATH="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:$PATH" \
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback/pnpm" install --frozen-lockfile --store-dir .pnpm-store
```

## 文件与内容

- 运行时内容与校验：src/config/content.json、content.ts；原交接模板不作为第二份运行时配置。
- 谜题界面：src/ui/SignalPuzzle.tsx、src/styles/puzzle.css。
- 业务状态／计算／存储：src/state/experience.ts、useProgress.ts、src/lib/puzzle.ts、storage.ts。
- 当前美术：src/scene/FloofTerrain.tsx、FloofScenery.tsx、RabbitCompanion.tsx、FloofStatic.tsx；本地素材 public/art/floof/。
- 当前角色输入：src/motion/useMeadowJourney.ts、src/scene/pointerGuidance.ts。
- 章节导航与原位置恢复：src/App.tsx；导航历史不写入业务存储。
- 本地 Cormorant Garamond 字体附 SIL OFL 许可，是文学气质的授权替代，不声称是 Wayfinder 原字体。

保存仅使用本应用专用键 `birthday-gift:0305:v1`。开发者确需重置测试数据时，只删除这一键，绝不调用 localStorage.clear()。界面没有清空用户进度按钮。前端密码属于揭晓机关，不是身份认证。

待用户提供：九首真实曲名、可选曲目理由、真实礼物名称与介绍、可选照片、称呼和署名。私人语音／演奏未提供时保持 null，不虚构内容或播放器。

## 后续与历史

下一阶段按原计划推进 **M3：九首独立等权、有放回的曲目抽取**，含重复抽取、结果保存和复制；再做 M4 礼物、M5 彩排。深处区域尚未按当前美术完整重做或验收。

- [阶段进度与全部历史](docs/PROGRESS.md)
- [移动顺滑度修正与测量](docs/SMOOTH_MOTION_QA.md)
- [转向与停步修正](docs/TURN_STOP_QA.md)
- [M2 检查](docs/M2_SIGNAL_QA.md)
- [当前美术方向检查](docs/FLOOF_CLEARING_QA.md)
- [本轮前 README，保留历史实现说明](docs/versions/README-before-m2-20261101.md)
- 本轮前 src 备份：docs/versions/before-m2-20261101.tar.gz。
- 原始计划：birthday-site-handoff/docs/DEVELOPMENT_PLAN.md；原始文档与 reference 未改。
