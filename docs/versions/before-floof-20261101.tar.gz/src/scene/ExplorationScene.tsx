import { useEffect, useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { DoubleSide, Fog, Group, Mesh, MeshBasicMaterial, PerspectiveCamera, PlaneGeometry, SRGBColorSpace, Texture, Vector2 } from 'three';
import type { ArtKey } from '../config/art';
import type { GardenProps } from './GardenCanvas';
import { BILLBOARD_TILT, depthCamera, depthProject, depthTrees, terrainHeight, landmarkReveal, depthFogColor } from './depthWorld';
import { objects } from './world';
import { LivingWorld } from './LivingWorld';
import { RabbitCompanion } from './RabbitCompanion';
import { AtlasTerrain } from './AtlasTerrain';
import { AtlasEncounters } from './AtlasEncounters';
import { TrailAwakening } from './TrailAwakening';
import { GardenAir } from './GardenAir';
import { ResponsiveUnderstory } from './ResponsiveUnderstory';
import { advanceGardenClock, gardenWind } from './gardenWind';
import type { GardenClock } from './gardenWind';
import { regionAtmosphere } from './gardenAtlas';
import type { MeadowPoint } from './meadowMotion';
import type { JourneyPose } from './journey';

type Textures=Partial<Record<ArtKey,Texture>>;

function Sprite({texture,w,h,opacity=1,color='#ffffff',...props}:{texture?:Texture;w:number;h:number;opacity?:number;color?:string;position?:[number,number,number]}) {
  return texture?<mesh {...props}><planeGeometry args={[w,h]}/><meshBasicMaterial map={texture} transparent opacity={opacity} color={color} depthWrite={false} alphaTest={.025} side={DoubleSide} toneMapped={false}/></mesh>:null;
}
function ForegroundMeadow({texture,actor,reading,clock}:{texture?:Texture;actor:MeadowPoint;reading:boolean;clock:GardenClock}) {
  const width=2350,height=780,root=useRef<Group>(null!);
  const geometry=useMemo(()=>new PlaneGeometry(width,height,28,8),[]);
  const original=useMemo(()=>new Float32Array(geometry.attributes.position.array),[geometry]);
  useEffect(()=>()=>geometry.dispose(),[geometry]);
  useFrame(()=>{
    root.current.visible=!!texture&&actor.y<-780;
    if(!root.current.visible||reading)return;
    const wind=gardenWind(clock.current,-40,-2320,.1),positions=geometry.attributes.position;
    for(let i=0;i<positions.count;i++){
      const x=original[i*3],y=original[i*3+1],rise=Math.max(0,y/height+.5),tips=rise*rise*rise;
      positions.setXYZ(i,x+tips*(wind.lean*18+wind.flutter*5+Math.sin(clock.current*.75+x*.011)*2.5),y,original[i*3+2]);
    }
    positions.needsUpdate=true;
  });
  return <group ref={root} position={[-40,-2320,terrainHeight(-40,-2320)+4]} visible={!!texture}>
    <group rotation={[BILLBOARD_TILT,0,0]}>
      <mesh geometry={geometry} position={[0,height/2-18,0]} renderOrder={9000}>
        <meshBasicMaterial map={texture} transparent alphaTest={.025} opacity={.92} depthWrite={false} side={DoubleSide} toneMapped={false}/>
      </mesh>
    </group>
  </group>;
}
function Tree({item,textures,actor,reading,pose,clock}:{item:typeof depthTrees[number];textures:Textures;actor:MeadowPoint;reading:boolean;pose:JourneyPose;clock:GardenClock}) {
  const root=useRef<Group>(null!),crown=useRef<Group>(null!),shade=useRef<Mesh>(null!),alpha=useRef(1);
  const {size,gl}=useThree();
  const cutout=useMemo(()=>({rabbitScreen:{value:new Vector2(-1000,-1000)},rabbitRadius:{value:new Vector2(1,1)},rabbitReveal:{value:0}}),[]);
  const material=useMemo(()=>{
    const material=new MeshBasicMaterial({map:textures[item.art]??textures.tree,color:item.tint,transparent:true,alphaTest:.025,depthWrite:false,toneMapped:false});
    material.onBeforeCompile=shader=>{
      Object.assign(shader.uniforms,cutout);
      shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nuniform vec2 rabbitScreen; uniform vec2 rabbitRadius; uniform float rabbitReveal;');
      shader.fragmentShader=shader.fragmentShader.replace('#include <alphatest_fragment>',`float revealDistance=length((gl_FragCoord.xy-rabbitScreen)/rabbitRadius);
        diffuseColor.a *= 1. - rabbitReveal * (1. - smoothstep(.25,1.,revealDistance));
        #include <alphatest_fragment>`);
    };
    material.customProgramCacheKey=()=> 'tree-local-rabbit-reveal-v1';
    return material;
  },[textures,item.art,item.tint,cutout]);
  useEffect(()=>()=>material.dispose(),[material]);
  const geometry=useMemo(()=>new PlaneGeometry(item.w,item.h,14,18),[item.w,item.h]);
  const original=useMemo(()=>new Float32Array(geometry.attributes.position.array),[geometry]);
  useEffect(()=>()=>geometry.dispose(),[geometry]);
  useFrame((_s,dt)=>{
    const delta=Math.min(dt,.05);
    root.current.visible=Math.abs(item.x-actor.x)<3300&&item.y>actor.y-650&&item.y<actor.y+3500;
    if(!root.current.visible)return;
    if(!reading){
      const points=geometry.attributes.position;
      const wind=gardenWind(clock.current,item.x,item.y,.32);
      for(let i=0;i<points.count;i++){
        const x=original[i*3],y=original[i*3+1],branch=Math.max(0,y/item.h+.5-.22);
        const tips=branch*branch,leafPhase=clock.current*1.15+x*.021+y*.008;
        // The base stays still; branches follow the breeze and outer leaves catch up.
        points.setX(i,x+tips*(wind.lean*23+wind.flutter*8+Math.sin(leafPhase)*(1.8+wind.gust*3)));
        points.setY(i,y+tips*Math.sin(leafPhase*.73+x*.013)*(1+wind.gust*2));
      }points.needsUpdate=true;
    }
    const tree=depthProject(item.x,item.y,pose,size.width,size.height),rabbit=depthProject(actor.x,actor.y,pose,size.width,size.height);
    const overlaps=actor.y>item.y&&Math.abs(tree.x-rabbit.x)<item.w*tree.scale*.43&&rabbit.y>tree.y-item.h*tree.scale&&rabbit.y-80<tree.y;
    const near=Math.hypot(item.x-actor.x,item.y-actor.y)<140;
    const fade=Math.max(0,Math.min(1,(tree.depth-80)/200));
    const rear=Math.max(0,Math.min(1,(item.y-actor.y+650)/250));
    const horizon=Math.max(0,Math.min(1,(3500-(item.y-actor.y))/950));
    const target=(near?.88:1)*fade*rear*rear*(3-2*rear)*horizon*horizon*(3-2*horizon);
    // Only a soft window around the companion yields; the surrounding tree still encloses the path.
    const dpr=gl.getPixelRatio();
    cutout.rabbitScreen.value.set(rabbit.x*dpr,(size.height-rabbit.y+75*rabbit.scale)*dpr);
    cutout.rabbitRadius.value.set(Math.max(30,100*rabbit.scale)*dpr,Math.max(48,165*rabbit.scale)*dpr);
    if(!reading)cutout.rabbitReveal.value+=((overlaps?.76:0)-cutout.rabbitReveal.value)*(1-Math.exp(-delta*8));
    if(!reading)alpha.current+=(target-alpha.current)*(1-Math.exp(-delta*7));
    if(shade.current)(shade.current.material as MeshBasicMaterial).opacity=.29*alpha.current;
    crown.current.traverse(child=>{if(child instanceof Mesh)(child.material as MeshBasicMaterial).opacity=alpha.current;});
  });
  return <group ref={root} position={[item.x,item.y,terrainHeight(item.x,item.y)+1]}>
    <mesh ref={shade}><planeGeometry args={[item.w*.85,125]}/><meshBasicMaterial map={textures.contact??null} transparent opacity={.29} color="#647b70" depthWrite={false}/></mesh>
    <group rotation={[BILLBOARD_TILT,0,0]}><group ref={crown} scale={[Math.sin(item.x*.017+item.y*.013)>0?-1:1,1,1]}><mesh geometry={geometry} material={material} position={[0,item.h*(.5-item.footInset),0]}/></group></group>
  </group>;
}

function Landmark({object,textures,reading,bloom,lampOn,discovered,actor,trailAwake,clock}:{object:typeof objects[number];textures:Textures;reading:boolean;bloom:number;lampOn:boolean;discovered:boolean;actor:MeadowPoint;trailAwake:boolean;clock:GardenClock}) {
  const flowers=useRef<Group>(null!),growth=useRef(0);
  const plant=useRef<Group>(null!),time=useRef(0),pulse=useRef(0),lastBloom=useRef(bloom),light=useRef<Mesh>(null!),lampStrength=useRef(trailAwake?.3:.035);
  useFrame((_s,dt)=>{
    if(!reading){time.current+=Math.min(dt,.05);growth.current+=(Number(discovered)-growth.current)*(1-Math.exp(-Math.min(dt,.05)*2));if(flowers.current)flowers.current.scale.setScalar(Math.max(.001,growth.current));}
    if(lastBloom.current!==bloom){lastBloom.current=bloom;pulse.current=1;}
    pulse.current*=Math.exp(-Math.min(dt,.05)*2.5);
    plant.current.rotation.z=object.id==='music'?gardenWind(clock.current,object.x,object.y,.16).lean*.035+Math.sin(pulse.current*15)*pulse.current*.12:0;
    if(!reading)lampStrength.current+=((trailAwake?.3:.035)-lampStrength.current)*(1-Math.exp(-Math.min(dt,.05)*1.8));
    if(light.current)(light.current.material as MeshBasicMaterial).opacity=(lampOn?.65:lampStrength.current)*(1+Math.sin(time.current)*.025)*landmarkReveal(object,actor,reading);
  });
  const reveal=landmarkReveal(object,actor,reading);
  return <group visible={reveal>.01} position={[object.x,object.y,terrainHeight(object.x,object.y)+2]}>
    <Sprite texture={textures.contact} w={object.width} h={55} opacity={.28*reveal} color="#667e69"/>
    <group ref={flowers}>{[[-85,-32,30],[90,-20,36],[65,55,25]].map(([x,y,w],i)=><group key={i} position={[x,y,terrainHeight(object.x+x,object.y+y)-terrainHeight(object.x,object.y)]} rotation={[BILLBOARD_TILT,0,0]}><Sprite texture={textures.flower} w={w} h={w*1.5} position={[0,w*.65,0]}/></group>)}</group>
    {object.id==='lock'&&<mesh position={[0,-30,1]}><planeGeometry args={[130,90]}/><meshBasicMaterial color="#cecdb8" transparent opacity={.4}/></mesh>}
    <group rotation={[BILLBOARD_TILT,0,0]}>
      <group ref={plant}><Sprite texture={textures[object.art]} opacity={reveal} w={object.width} h={object.height} position={[0,object.height/2-object.footInset,0]}/></group>
      <Sprite texture={textures.grass} w={object.width*.6} h={40} position={[0,7,2]} color="#849b86" opacity={.7*reveal}/>
      {object.id==='puzzle'&&<mesh ref={light} position={[0,object.height*.68,3]}><planeGeometry args={[240,240]}/><meshBasicMaterial map={textures.glow} transparent opacity={.09} depthWrite={false}/></mesh>}
    </group>
  </group>;
}
export function ExplorationScene(props:GardenProps) {
  const {images,pose,actor,moving,heading,reading,discovered,onReady}=props;
  const {camera,size,gl,scene}=useThree(),ready=useRef(false);
  const windClock=useRef(0);
  useFrame((_frame,dt)=>{windClock.current=advanceGardenClock(windClock.current,dt,reading);},-1);
  const sceneryActor=reading?{x:pose.x,y:pose.y-220}:actor;
  const textures=useMemo(()=>{const result:Textures={};for(const [key,image] of Object.entries(images)){const t=new Texture(image);t.colorSpace=SRGBColorSpace;t.needsUpdate=true;t.anisotropy=4;result[key as ArtKey]=t;}return result;},[images]);
  useEffect(()=>()=>Object.values(textures).forEach(t=>t.dispose()),[textures]);
  useEffect(()=>{const lose=(e:Event)=>{e.preventDefault();props.onFail();};gl.domElement.addEventListener('webglcontextlost',lose);return()=>gl.domElement.removeEventListener('webglcontextlost',lose);},[gl,props.onFail]);
  useFrame(()=>{const c=depthCamera(pose,size.width,size.height),cam=camera as PerspectiveCamera;cam.position.set(c.x,c.y,c.z);cam.up.set(0,0,1);cam.lookAt(c.x,c.targetY,c.targetZ);cam.fov=c.fov;cam.far=18000;cam.updateProjectionMatrix();if(scene.fog instanceof Fog){const c=depthFogColor(regionAtmosphere(sceneryActor.x,sceneryActor.y).fog);scene.fog.color.setRGB(...c,SRGBColorSpace);}if(!ready.current){ready.current=true;onReady();}});
  return <>
    <fog attach="fog" args={['#d1dedb',2000,4900]}/>
    <AtlasTerrain texture={textures.meadow} actor={sceneryActor} reading={reading} clock={windClock}/>
    {depthTrees.map((tree,i)=><Tree key={i} item={tree} textures={textures} actor={sceneryActor} reading={reading} pose={pose} clock={windClock}/>)}
    {objects.map(object=><Landmark key={object.id} object={object} textures={textures} actor={actor} reading={reading} bloom={props.bloom} lampOn={props.lampOn} discovered={discovered.includes(object.id)} trailAwake={props.trailEvents?.includes('trail-lantern-awake')??false} clock={windClock}/>)}
    <ResponsiveUnderstory textures={textures} actor={actor} moving={moving} heading={heading} reading={reading} clock={windClock}/>
    <AtlasEncounters textures={textures} actor={sceneryActor} moving={moving} heading={heading} reading={reading} onEvent={props.onWorldEvent} pulse={props.atlasPulse}/>
    <LivingWorld textures={textures} actor={actor} moving={moving} heading={heading} reading={reading} discovered={discovered} onEvent={props.onWorldEvent} clock={windClock}/>
    <TrailAwakening textures={textures} actor={actor} moving={moving} reading={reading} clock={windClock} memories={props.trailEvents} onEvent={props.onWorldEvent}/>
    <GardenAir clock={windClock} actor={actor} moving={moving} heading={heading} reading={reading}/>
    <RabbitCompanion actor={actor} moving={moving} heading={heading} reading={reading} textures={textures} guidance={props.guidance}/>
    <ForegroundMeadow texture={textures.meadowFrame} actor={actor} reading={reading} clock={windClock}/>
  </>;
}
