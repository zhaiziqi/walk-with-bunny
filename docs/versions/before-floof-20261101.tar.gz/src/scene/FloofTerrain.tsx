import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Float32BufferAttribute, PlaneGeometry, ShaderMaterial, Vector2 } from 'three';
import type { Texture } from 'three';
import { groundExtent, regionAtmosphere } from './gardenAtlas';
import { terrainHeight } from './depthWorld';
import type { MeadowPoint } from './meadowMotion';
import type { GardenClock } from './gardenWind';
import { createFloofBrushTexture } from './floofTerrainPaint';

type Props = { texture?: Texture; actor: MeadowPoint; reading: boolean; clock?: GardenClock };

const vertexShader = `
attribute float dusk;
varying vec3 ground;
varying vec3 groundNormal;
varying float twilight;
varying float eyeDistance;
void main() {
  ground = position;
  groundNormal = normal;
  twilight = dusk;
  vec4 view = modelViewMatrix * vec4(position, 1.);
  eyeDistance = -view.z;
  gl_Position = projectionMatrix * view;
}`;

const fragmentShader = `
uniform sampler2D brush;
uniform float time;
uniform vec2 companion;
uniform float wake;
varying vec3 ground;
varying vec3 groundNormal;
varying float twilight;
varying float eyeDistance;

float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 345.45));
  p += dot(p, p + 34.345);
  return fract(p.x * p.y);
}
float noise21(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  f = f * f * (3. - 2. * f);
  return mix(mix(hash21(i), hash21(i + vec2(1., 0.)), f.x),
    mix(hash21(i + vec2(0., 1.)), hash21(i + vec2(1., 1.)), f.x), f.y);
}
float mound(vec2 p, vec2 center, vec2 radius) {
  vec2 q = (p - center) / radius;
  return exp(-dot(q, q));
}

void main() {
  vec2 p = ground.xy;
  // The differently scaled passes share direction but do not reveal a repeating landscape tile.
  float broadBrush = texture2D(brush, p / 1793.).r;
  float dryBrush = texture2D(brush, (p + vec2(729., -541.)) / 603.).r;
  float pigment = (broadBrush - .5) * .34 + (dryBrush - .5) * .17;
  float brokenEdge = (broadBrush - .5) * 155. + (dryBrush - .5) * 42.;
  float slowWash = noise21(p * .0015);
  vec3 sage = mix(vec3(.670, .740, .614), vec3(.520, .625, .630), twilight * .85);
  vec3 blue = mix(vec3(.623, .678, .748), vec3(.471, .543, .664), twilight * .78);
  vec3 underpaint = mix(vec3(.552, .656, .572), vec3(.427, .541, .566), twilight * .75);
  vec3 color = sage + (slowWash - .5) * vec3(.045, .040, .030);

  // Broad bands follow the existing entry banks, rather than drawing a separate beige road.
  float diagonal = p.x * .70 + p.y * .55 + 150. + sin(p.y * .0014) * 105.;
  float slopeBand = 1. - smoothstep(130. + brokenEdge, 470. + brokenEdge, abs(diagonal));
  float entryLimit = 1. - smoothstep(950., 2450., abs(p.y + 750.));
  float eastBank = mound(p, vec2(930., -780.), vec2(490., 610.));
  float westBank = mound(p, vec2(-240., -680.), vec2(510., 285.));
  float bankPaint = max(slopeBand * entryLimit, eastBank * .46);
  color = mix(color, blue, bankPaint * .69);

  // Lower edges of actual landforms carry a soft darker pigment, exposing their overlap.
  float bankShade = mound(p, vec2(-340., -910.), vec2(540., 165.)) * .18
    + mound(p, vec2(905., -1120.), vec2(410., 225.)) * .14;
  color = mix(color, underpaint, bankShade * (1. + broadBrush * .2));
  color += westBank * vec3(.017, .024, .017);

  // Later areas remain connected but gradually become lavender and blue through their own washes.
  float later = smoothstep(600., 2300., p.y);
  float laterBank = smoothstep(.49, .75, noise21((p + vec2(640., 810.)) * .0009));
  color = mix(color, blue, laterBank * later * .30);

  float clearing = mound(p, vec2(80., -2050.), vec2(650., 570.));
  float light = mound(p, vec2(320., -1590.), vec2(380., 940.)) * .58
    + mound(p, vec2(-650., 750.), vec2(340., 290.)) * .38;
  color += vec3(.065, .053, .025) * (clearing * .38 + light);
  color += pigment * mix(vec3(.70, .78, .62), vec3(.68, .72, .82), bankPaint);

  // A wind front moves across the brushwork. It changes pigment very slightly, never the land height.
  float gustPhase = (time - p.x / 520. - p.y / 850.);
  float phase = mod(gustPhase + 19000., 19.);
  float gust = smoothstep(3., 5., phase) * (1. - smoothstep(6., 8., phase));
  color += vec3(.012, .014, .008) * gust * smoothstep(.47, .64, dryBrush);

  float nearby = exp(-dot((p - companion) / 165., (p - companion) / 165.));
  color += vec3(.010, .012, .006) * nearby * wake * (dryBrush + .2);

  float lighting = .94 + .06 * max(0., dot(normalize(groundNormal), normalize(vec3(-.45, -.25, 1.))));
  color *= lighting;
  // Keep distant pigment in the same colour family; a mist veil must not flatten the focal clearing.
  float far = smoothstep(3900., 7200., eyeDistance);
  color = mix(color, mix(vec3(.70, .76, .71), vec3(.59, .65, .73), twilight), far * .45);
  gl_FragColor = vec4(color, 1.);
}`;

/** The approved painted clearing extends through world coordinates; it is never a camera-facing background. */
export function FloofTerrain({ actor, reading, clock }: Props) {
  const time = useRef(0);
  const previous = useRef({ ...actor });
  const wake = useRef(0);
  const brush = useMemo(createFloofBrushTexture, []);
  const geometry = useMemo(() => {
    const width = groundExtent.maxX - groundExtent.minX;
    const height = groundExtent.maxY - groundExtent.minY;
    const geometry = new PlaneGeometry(width, height, 200, 264);
    const position = geometry.attributes.position;
    const dusk: number[] = [];
    for (let i = 0; i < position.count; i++) {
      const x = position.getX(i) + (groundExtent.minX + groundExtent.maxX) / 2;
      const y = position.getY(i) + (groundExtent.minY + groundExtent.maxY) / 2;
      position.setXYZ(i, x, y, terrainHeight(x, y));
      dusk.push(regionAtmosphere(x, y).dusk);
    }
    geometry.setAttribute('dusk', new Float32BufferAttribute(dusk, 1));
    geometry.computeVertexNormals();
    return geometry;
  }, []);
  const material = useMemo(() => new ShaderMaterial({
    uniforms: { brush: { value: brush }, time: { value: 0 }, companion: { value: new Vector2() }, wake: { value: 0 } },
    vertexShader, fragmentShader, toneMapped: false,
  }), [brush]);
  useFrame((_frame, delta) => {
    if (reading) return;
    const dt = Math.max(0, Math.min(delta, .05));
    time.current = clock?.current ?? time.current + dt;
    const travelled = Math.hypot(actor.x - previous.current.x, actor.y - previous.current.y);
    const moving = travelled > .01 && travelled < 100;
    wake.current += (Number(moving) - wake.current) * (1 - Math.exp(-dt * 2.2));
    material.uniforms.time.value = time.current;
    material.uniforms.companion.value.set(actor.x, actor.y);
    material.uniforms.wake.value = wake.current;
    previous.current = { ...actor };
  });
  useEffect(() => () => { geometry.dispose(); material.dispose(); brush.dispose(); }, [geometry, material, brush]);
  return <mesh name="painted-floof-ground" geometry={geometry} material={material} renderOrder={-1000}/>;
}
